# R5 next: source/time-flow coupling after universal time-only obstruction

## Immutable input and completed frontier

Frozen GLOBAL_KNOWLEDGE_V1 main `a8ac2ca67df02b5e1050370145c00ea19607b4d4` and Enterprise Math main `cd0d692a5510dddcc42991b056ed032933e0b164`; P000 original blob `770e1b157fc10aab7b25d80c2cd52d6fcd07c9dc` matches the frozen startup projection. Use the two newly pinned R5 author-side evidence packages: moving-J minimax at Git commit `f65859b0f989e442d9df16c55a65401d8e06102e` and the present `RESEARCH.md/VERIFY.py/EXACT_OUTPUT.txt`. Both are portable author proofs, unreviewed and not Source-admitted.

Do not redo: the moving-J support gap for all common L error changes is uniformly >=3/16; **more strongly**, the error-independent H=13 T_P−14 T_Q has gap exactly 5/32 at `(α0,α1)=(1/4,1/8)` for *all* admissible source/path-dependent terminal error kernels, with fixed source-natural transition and timing graph. Its general signed-gap formula is the two-point Jensen defect of `φ(α)=max(−1,−2+11α/2)` and is strictly positive iff α0 and α1 strictly straddle `2/11`.

## Single next mathematical unit

Construct the smallest modified strictly positive two-origin P/Q stop/continue process with a **genuine changed natural time-flow** (for example, allow the C route a source/history-preserving positive transition to the same L stage, with explicitly transported LR and redefined stopping times) or an upstream information/action coupling. Keep source labels and path/provenance until final observations. Formalize the new finite stochastic kernel and require exact normalization of both P and Q at every action.

First compute the whole *two-dimensional time observation* polytope and explicitly test whether FULL and seedless LR convex hulls coincide, by exact rational mixtures (or a signed separating hyperplane). Do not infer equality from one H direction attaining zero. Require if time hulls match: **four-dimensional** full-polytope equality with rational convex coefficients using at most five LR vertices per FULL vertex in R^4, or a Farkas separation certificate; and full four-dimensional affine rank. Only then test whether an actual real FULL observation stays outside all real seedless LR behavioral images (even though hulls agree). State finite-model vs native-X6 limits honestly.

Reuse BRC source→route→action positive-rational path mass and LR transport, with signed observers applied after the typed positive carrier. No Eulerian geometry, π, classical trigonometry or native heartbeats used in this finite stop model. Native X6 correspondence is a separate open task. Persist complete proof, exact input/prog/output and next successor in existing Draft PR #1663 and complete valid readback; request genuine native owner/claim/Driver authority only if service actually grants it.
