# R5 — Error-kernel invariant time-only separator; exact all-real source-threshold classification

**Date:** 2026-10-31, Asia/Shanghai. **Status:** `AUTHOR_PROVED / EXACT_FRACTION_CHECKED / UNREVIEWED / NOT_ADMITTED / PORTABLE_ONLY / REGISTER_PENDING`. The result concerns a specified finite source-labelled P/Q stopping model, not a native X6 theorem or an accepted Source Result.

## 1. Fixed source and objective

Freeze GLOBAL_KNOWLEDGE_V1 `main@a8ac2ca67df02b5e1050370145c00ea19607b4d4`, P000 canonical blob `770e1b157fc10aab7b25d80c2cd52d6fcd07c9dc` (equal to the frozen P000_STARTUP.json pointer), ACTIVE `我眼中的世界.md`, and Enterprise Math `main@cd0d692a5510dddcc42991b056ed032933e0b164`. Initial model at immutable Enterprise Math research commit `e7916482f44a925e11ece98e406309f4655fb1f1`; preceding exact moving-FULL J theorem at `f65859b0f989e442d9df16c55a65401d8e06102e`. P000 and worldview are immutable inputs here; no changes to protected source.

The question is whether **any source/history-sensitive terminal error response changes** can make the four-observer FULL and seedless LR convex hulls equal, when natural transitions, actions, information keys and stopping times remain fixed. Previous J-support work allowed all eight shared L-response probabilities to vary and still found a positive support gap. This work introduces an *error-independent time observer* that covers arbitrary terminal-error kernels at **every terminal leaf**, not only L.

## 2. Complete finite model and BRC typing

Two equally weighted hidden origins `i∈{0,1}` each begin at A, stage `t=1`, likelihood ratio P/Q = 1, source Q mass 1/2. At A, STOP terminates at t=1. CONTINUE produces at t=2 branches D,C,Y with conditional Q probabilities `(α_i, 1−2α_i, α_i)` and likelihood ratios `(1/2,1,3/2)`, where `0<α_i<1/2` are arbitrary real source parameters. C must STOP at t=2. D STOP at t=2; D CONTINUE at t=3 splits into residual (conditional Q share 2/3, LR 1/4) and common key L (Q share 1/3, LR 1). Y STOP at t=2; Y CONTINUE at t=3 splits into residual (Q share 1/2, LR 2) and L (Q share 1/2, LR 1). L STOP terminates at t=3; L CONTINUE terminates at t=4. All corresponding P mass on a labelled terminal cylinder is its Q mass multiplied by that cylinder's likelihood ratio. These conditional splits obey the P/Q martingale transport constraints:

- D: `(2/3)(1/4)+(1/3)(1)=1/2`;
- Y: `(1/2)(2)+(1/2)(1)=3/2`;
- D,C,Y: `α_i/2+(1−2α_i)+3α_i/2=1`.

For every `α_i∈(0,1/2)`, Q/P total mass is one and every allowed natural branch has strictly positive mass. A FULL strategy may depend on i and complete D/Y history. A seedless LR behavioral strategy shares action probabilities on the four keys A,D,Y,L (no persistent correlated random seed). Its random decisions are fresh behavioral Bernoulli parameters. Each key is visited at most once on any path, so all expected coordinates are multi-affine in behavioral controls, and both strategy classes attain linear-observer maxima at their deterministic vertices.

Each terminal cylinder may carry an **arbitrary admissible P/Q error response probability**, possibly source/path/action-dependent; the same response kernel is used when comparing FULL and LR. The proof does not assume any specific baseline error, common-error box ε, or source-independence. Its only terminal-response condition is that altering an error label does not change its Q/P terminal mass, information key or stopping time. For the four-observer output `O=(error_P,error_Q,T_P,T_Q)` define the **time-only linear observer**

`H(O)=13 T_P − 14 T_Q`.

This is a positive weighted BRC source/route carrier with Q→P likelihood transport, not an operation on signed/complex BRC amplitudes; subtraction occurs only in the signed *observer*. Every cylinder's positive mass and provenance is retained before readout. The time coordinates here are declared stopping times of this auxiliary process, not P000's native time dynamics.

## 3. All-real theorem

For arbitrary `0<α_0,α_1<1/2`, define

`φ(α)=max(−1,−2+(11/2)α)`.

Then for **every terminal error kernel** meeting the unchanged-path condition, the support maxima are exactly

`sup_FULL H = [φ(α_0)+φ(α_1)]/2`,

`sup_seedless_LR H = φ((α_0+α_1)/2)`.

Thus the complete exact signed time-support gap is

`Δ_H(α_0,α_1) = [φ(α_0)+φ(α_1)]/2 − φ((α_0+α_1)/2) ≥ 0`.

It is strictly positive **if and only if** `(α_0−2/11)(α_1−2/11)<0`; equality otherwise. This is a complete *classification for this one H direction*, not a classification of all four-dimensional convex hulls when Δ_H=0.

At the original `α_0=1/4,α_1=1/8`, the exact support values are

`sup_FULL H=−13/16`, `sup_LR H=−31/32`, `Δ_H=5/32`.

For **every** legal terminal response, including arbitrary source/history-dependent errors at A, C, D, Y, L and all residual leaves, the four-dimensional convex hulls are strictly unequal. A maximizing FULL observation has L∞ distance to the *entire* LR hull at least

`(5/32)/(abs(13)+abs(−14)) = 5/864`.

The stronger exclusion remains true even when changing terminal errors makes the former signed `J=41error_Q−12T_Q` observer unable to separate FULL from LR. The previous suggestion to vary upstream C error alone can therefore be closed: it cannot change this time-only obstruction. To seek four-observer hull equality in this model lineage, the next construction must alter source-conditioned natural **time flow**, the stop/continue timing map, or the decision-information coupling itself.

## 4. Complete proof by exact Bellman comparison

Write the contribution of Q unit mass at a terminal node of likelihood ratio `λ` and time `t` as `r(λ,t)=(13λ−14)t`. This is an algebraic identity from P/Q likelihood transport; terminal error labels are absent.

At A STOP the reward is `r(1,1)=−1`; at C STOP `r(1,2)=−2`. For D STOP `r(1/2,2)=−15`. At any L, STOP yields `r(1,3)=−3`, CONTINUE yields `r(1,4)=−4`; hence L STOP is always the unique maximizing action at the H-support Bellman stage.

For D CONTINUE, the two Q-conditional branches, using optimal L STOP, give

`(2/3) r(1/4,3)+(1/3)r(1,3)=(2/3)(−129/4)+(1/3)(−3)=−45/2`.

Therefore D STOP with `−15` strictly dominates D CONTINUE with `−45/2`. For Y STOP, `r(3/2,2)=11`. For Y CONTINUE, the residual and L split gives

`(1/2)r(2,3)+(1/2)r(1,3)=(1/2)(36)+(1/2)(−3)=33/2>11`.

Consequently Y CONTINUE strictly dominates Y STOP. These choices maximize both source-specific FULL policies and the shared LR policy at D/Y/L; they do not depend on α, source, terminal error, or previous action. There is no information conflict in them.

At the stage-1 A CONTINUE, the conditional optimized value for source i is therefore

`V_i=α_i(−15)+(1−2α_i)(−2)+α_i(33/2)=−2+(11/2)α_i`.

At A STOP the value is `−1`. A FULL policy can independently choose A STOP/CONTINUE for each source, so with source prior 1/2 its optimal support is `[max(−1,V_0)+max(−1,V_1)]/2`. A seedless LR policy shares one A decision; stopping gives `−1` and continuing gives `(V_0+V_1)/2=−2+(11/2)(α_0+α_1)/2`. Its support is their maximum. A randomized behavioral policy cannot exceed these deterministic values because expectation is affine in its only remaining A coin (and every other decision has already been optimized).

These expressions equal the asserted `φ` formulas. Since `φ` is a maximum of affine functions it is convex, giving Δ_H≥0 by elementary Jensen inequality. Its only hinge occurs at `α=2/11`, and equality in the two-point midpoint Jensen inequality holds precisely when both arguments lie in the same affine region or one is on the hinge. The strict condition is exactly `(α_0−2/11)(α_1−2/11)<0`.

For `(α_0,α_1)=(1/4,1/8)`, `V_0=−5/8>−1`, `V_1=−21/16<−1`. FULL continues A for source0 and stops for source1, while LR continues A for both, so

`S_FULL=[−5/8+(−1)]/2=−13/16`,

`S_LR=[−5/8−21/16]/2=−31/32`;

subtracting gives `5/32`. In the coordinates `(error_P,error_Q,T_P,T_Q)`, H has coefficient vector `(0,0,13,−14)` with l1 norm 27, and the duality inequality `|H(x−y)|≤27||x−y||∞` proves the stated distance bound. Because H ignores error coordinates, the proof covers *every* admissible shared terminal-error response with fixed flows and stop times. □

## 5. Verification and explicit witnesses

`VERIFY.py` uses standard-library `fractions.Fraction` and directly constructs Q paths, transports each terminal Q mass via its LR into P, and checks P/Q normalization for every enumerated strategy. For the fixed original α pair, it enumerates the 1024 FULL and 16 LR deterministic control vectors; it finds the explicit FULL witness bits `1001000000` with `(T_P,T_Q)=(27/16,13/8)` and H=`−13/16`, and LR maximizing bits `1010` with `(T_P,T_Q)=(73/32,35/16)` and H=`−31/32`. Across all 25 ordered pairs of `α∈{1/16,1/8,2/11,1/4,3/8}`, it enumerates 26,000 deterministic controls total, checking both formulae and the strict positivity condition (eight strict, seventeen zero cases). The actual output is `EXACT_OUTPUT.txt`, ending with `PASS_EXACT_R5_TIME_ONLY_TERMINAL_ERROR_NO_GO`.

The exact all-real classification and invariance under arbitrary terminal errors follows from Section 4's analytic argument; the 25-pair enumeration is a reproducible finite regression, not an inference to the continuum. The preceding J theorem and its verification are preserved unchanged in their immutable earlier commit; the present research strengthens the **search exclusion scope** and corrects the *next-task direction*.

## 6. Authorization and unresolved research

This is author-side portable scientific evidence, not independent mathematical review, canonical Result or native X6 embedding. On 2026-10-31 at this round's service inquiry, native status returned `research_authority_granted=false`, `executor_binding_configured=false`; owner inventory yielded `CONTROL_QUOTA`, so a canonical owner/CLAIM is not verified. No authorization or sharing permissions are inferred from GitHub authorship.

The original parent mother question, seeking four-observer hull equality while actual real seedless LR image differs, remains open. The narrowed necessary construction change is **time-flow or information-state coupling**, not terminal error responses on the original transition/time graph. See `NEXT_TASK.md` for an exact next small model and required certificates.
