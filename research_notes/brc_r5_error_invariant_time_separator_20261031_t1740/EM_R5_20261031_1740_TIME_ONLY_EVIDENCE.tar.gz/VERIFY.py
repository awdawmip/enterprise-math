#!/usr/bin/env python3
"""Exact independent R5 time-only support separator verification.

Finite strategy enumerations supplement an analytic all-real Bellman proof.
No classic trigonometry, geometric evolution, or native X6 experiment.
"""
from fractions import Fraction as F
from itertools import product

MERGE_Q = {-1: F(1, 3), 1: F(1, 2)}
LR_BRANCH = {-1: F(1, 2), 0: F(1), 1: F(3, 2)}
LR_RESIDUAL = {-1: F(1, 4), 1: F(2)}


def evaluate_time(bits, seedless, alpha):
    """Return (E_P[T],E_Q[T]), with P=LR*Q at every terminal leaf."""
    assert len(alpha) == 2 and all(F(0) < x < F(1,2) for x in alpha)
    assert len(bits) == (4 if seedless else 10)
    a = {i: bits[0] if seedless else bits[i] for i in (0, 1)}
    stage2 = {(i,j): bits[1+(j == 1)] if seedless
              else bits[2+2*i+(j == 1)]
              for i in (0,1) for j in (-1,1)}
    last = {(i,j): bits[3] if seedless else bits[6+2*i+(j == 1)]
            for i in (0,1) for j in (-1,1)}
    tp, tq, pmass, qmass = (F(0) for _ in range(4))

    def finish(q, lr, t):
        nonlocal tp, tq, pmass, qmass
        p = q * lr
        tp += p*t
        tq += q*t
        pmass += p
        qmass += q

    for i, x in enumerate(alpha):
        if a[i] == 0:
            finish(F(1,2), F(1), 1)
            continue
        for branch, qstep in ((-1,x), (0,1-2*x), (1,x)):
            q = qstep/2
            if branch == 0:
                finish(q,F(1),2)
            elif stage2[i,branch] == 0:
                finish(q,LR_BRANCH[branch],2)
            else:
                cont_q = MERGE_Q[branch]
                finish(q*(1-cont_q),LR_RESIDUAL[branch],3)
                finish(q*cont_q,F(1),3+last[i,branch])
    assert (pmass,qmass) == (1,1), (alpha,bits,pmass,qmass)
    return tp,tq


def H(time):
    return 13*time[0]-14*time[1]


def phi(x):
    return max(F(-1),-2+F(11,2)*x)


def theoretical_support(alpha):
    a0,a1 = alpha
    f = (phi(a0)+phi(a1))/2
    l = phi((a0+a1)/2)
    return f,l,f-l


def exact_enumeration(alpha):
    full = max(H(evaluate_time(b,False,alpha)) for b in product((0,1),repeat=10))
    lr = max(H(evaluate_time(b,True,alpha)) for b in product((0,1),repeat=4))
    return full,lr,full-lr


def main():
    a0,a1=F(1,4),F(1,8)
    alpha=(a0,a1)
    expected=(F(-13,16),F(-31,32),F(5,32))
    assert theoretical_support(alpha) == expected
    assert exact_enumeration(alpha) == expected
    full_bits=(1,0,0,1,0,0,0,0,0,0)
    lr_bits=(1,0,1,0)
    tw=evaluate_time(full_bits,False,alpha)
    tl=evaluate_time(lr_bits,True,alpha)
    assert H(tw)==expected[0],(tw,H(tw))
    assert H(tl)==expected[1],(tl,H(tl))
    assert tw==(F(27,16),F(13,8)),tw
    assert tl==(F(73,32),F(35,16)),tl

    # Exhaust all deterministic policies for each ordered pair in a rational grid,
    # including exactly critical alpha=2/11, strictly straddling and same-side cases.
    grid=(F(1,16),F(1,8),F(2,11),F(1,4),F(3,8))
    seen=(0,0)
    strict=0
    zero=0
    for alpha in product(grid,repeat=2):
        exact=exact_enumeration(alpha)
        analytic=theoretical_support(alpha)
        assert exact==analytic,(alpha,exact,analytic)
        opposite = ((alpha[0]-F(2,11))*(alpha[1]-F(2,11)) < 0)
        assert (exact[2]>0) == opposite,(alpha,exact)
        if opposite: strict+=1
        else: zero+=1
    assert strict==8 and zero==17,(strict,zero)

    # Error kernels do not enter this computation: arbitrary terminal error
    # responses cannot change time observables if stopping time/flows fixed.
    assert expected[2]/27 == F(5,864)
    print('FROZEN_ALPHA',alpha if False else (a0,a1))
    print('FULL_TIME_WITNESS',tw,'H',H(tw),'bits',''.join(map(str,full_bits)))
    print('LR_MAX_TIME_WITNESS',tl,'H',H(tl),'bits',''.join(map(str,lr_bits)))
    print('FULL_H_SUPPORT',expected[0])
    print('SEEDLESS_LR_H_SUPPORT',expected[1])
    print('UNIFORM_SUPPORT_GAP',expected[2])
    print('UNIFORM_LINF_TO_LR_HULL_DISTANCE_AT_LEAST',expected[2]/27)
    print('GENERAL_PHI(alpha)=max(-1,-2+11*alpha/2)')
    print('GENERAL_GAP=1/2*(phi(alpha0)+phi(alpha1))-phi((alpha0+alpha1)/2)')
    print('STRICT_POSITIVITY_IFF_alpha0_and_alpha1_strictly_straddle_2/11')
    print('EXACT_ALPHA_PAIR_GRID',len(grid)**2,'FULL_POLICIES_PER_PAIR',2**10,
          'LR_POLICIES_PER_PAIR',2**4,'STRICT',strict,'ZERO',zero)
    print('PASS_EXACT_R5_TIME_ONLY_TERMINAL_ERROR_NO_GO')


if __name__=='__main__':
    main()
