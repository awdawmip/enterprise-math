#!/usr/bin/env python3
"""Stage445-B exact equal-length one-mismatch X6/BRC support and populations.
No floating point or physical heartbeat evolution. Positive unit branch multiplicity.
"""
import json, hashlib
from itertools import combinations
from collections import Counter, defaultdict
from functools import lru_cache

# Pair bits P_B,Q_B; matching A/A, B/B, or Q-only B.
SYMBOLS=((0,0),(0,1),(1,1))


def compatible(a,b):
    return not (a[0] and b[0]) and not (a[1] and b[1])


def prefix_table(g):
    """Count possible prefixes of length g, first site fixed A/A, by (P B count, mismatch count, last pair)."""
    if g==0: return {(0,0,(0,0)):1}  # virtual left A/A
    dp={(0,0,(0,0)):1}
    for _ in range(2,g+1):
        nd=defaultdict(int)
        for (a,d,prev),multiplicity in dp.items():
            for z in SYMBOLS:
                if d+int(z==(0,1))>1 or not compatible(prev,z): continue
                nd[(a+z[0],d+int(z==(0,1)),z)]+=multiplicity
        dp=nd
    return dp


def suffix_alg(L,k,p):
    """Count DISTINCT suffix pair-words of length p+1 admitting a full fiber completion.

    Current fiber: |P|=|Q|=L, A endpoints, P has k B defects, Q has k+1,
    both nonadjacent B, exactly one differing position. p POP operations each.
    """
    if L<3 or not 0<=p<L or k<0:raise ValueError((L,k,p))
    s=L-p # 1-based starting site of visible suffix
    g=s-1
    pref=prefix_table(g)
    states=0; transitions=0; maximum=0

    def mass_from_tail(suffix):
        a=sum(x for x,y in suffix)
        d=sum(x!=y for x,y in suffix)
        if d>1 or any(not compatible(z,w) for z,w in zip(suffix,suffix[1:])):return 0
        if suffix[-1]!=(0,0) or (s==1 and suffix[0]!=(0,0)):return 0
        if any(z not in SYMBOLS for z in suffix):return 0
        need_a=k-a;need_d=1-d
        if need_a<0 or need_d<0:return 0
        return sum(m for (b,di,last),m in pref.items() if b==need_a and di==need_d and compatible(last,suffix[0]))

    @lru_cache(None)
    def rec(index,a,d,previous,first):
        """Count completions of VISIBLE tail given emitted prefix. index is number emitted."""
        nonlocal states,transitions,maximum
        states+=1
        if index==p+1:
            if a>k or d>1:return 0
            need_a=k-a;need_d=1-d
            return int(any(b==need_a and di==need_d and compatible(last,first) for (b,di,last),m in pref.items()))
        total=0
        for z in SYMBOLS:
            if (index==0 and s==1 and z!=(0,0)) or (index==p and z!=(0,0)):continue
            if index and not compatible(previous,z):continue
            aa=a+z[0];dd=d+int(z==(0,1))
            if aa>k or dd>1:continue
            transitions+=1
            total+=rec(index+1,aa,dd,z,z if index==0 else first)
        return total

    q=rec(0,0,0,(-1,-1),(-1,-1))

    def rank(tail):
        if len(tail)!=p+1 or mass_from_tail(tail)==0:raise ValueError('infeasible tail')
        i=0;a=d=0;prev=(-1,-1);first=(-1,-1);r=0
        for chosen in tail:
            for z in SYMBOLS:
                if z>chosen:break
                if (i==0 and s==1 and z!=(0,0)) or (i==p and z!=(0,0)) or (i and not compatible(prev,z)):continue
                aa=a+z[0];dd=d+int(z==(0,1))
                if aa>k or dd>1:continue
                nxt=rec(i+1,aa,dd,z,z if i==0 else first)
                if z==chosen:
                    if nxt==0:raise ValueError('invalid tail')
                    a,d,prev,first=aa,dd,z,z if i==0 else first
                    break
                r+=nxt
            else:raise ValueError('letter not found')
            i+=1
        return r

    def unrank(r):
        if not 0<=r<q:raise ValueError('rank range')
        a=d=0;prev=(-1,-1);first=(-1,-1);tail=[]
        for i in range(p+1):
            for z in SYMBOLS:
                if (i==0 and s==1 and z!=(0,0)) or (i==p and z!=(0,0)) or (i and not compatible(prev,z)):continue
                aa=a+z[0];dd=d+int(z==(0,1))
                if aa>k or dd>1:continue
                count=rec(i+1,aa,dd,z,z if i==0 else first)
                if r>=count:r-=count
                else:
                    tail.append(z);a,d,prev,first=aa,dd,z,z if i==0 else first
                    break
            else:raise AssertionError('unrank failed')
        return tuple(tail)

    def sample_population(rank_number):
        return mass_from_tail(unrank(rank_number))

    def prefix_code(tail):
        if mass_from_tail(tail)==0:raise ValueError('infeasible class')
        needed_a=k-sum(z[0] for z in tail)
        needed_d=1-sum(z==(0,1) for z in tail)
        next_pair=tail[0]
        @lru_cache(None)
        def count(i,a,d,previous):
            if i==g:
                return int(a==needed_a and d==needed_d and compatible(previous,next_pair))
            total=0
            for z in SYMBOLS:
                if (i==0 and z!=(0,0)) or not compatible(previous,z):continue
                aa=a+z[0];dd=d+int(z==(0,1))
                if aa<=needed_a and dd<=needed_d:
                    total+=count(i+1,aa,dd,z)
            return total
        return count

    def unrank_history(class_number,within_class):
        tail=unrank(class_number)
        mass=mass_from_tail(tail)
        if not 0<=within_class<mass:raise ValueError('within-class index')
        count=prefix_code(tail)
        prefix=[];a=d=0;previous=(0,0)
        for i in range(g):
            for z in SYMBOLS:
                if (i==0 and z!=(0,0)) or not compatible(previous,z):continue
                aa=a+z[0];dd=d+int(z==(0,1))
                c=count(i+1,aa,dd,z)
                if within_class>=c: within_class-=c
                else:
                    prefix.append(z);a,d,previous=aa,dd,z
                    break
            else:raise AssertionError('history unranking failed')
        pairs=prefix+list(tail)
        return tuple(z[0] for z in pairs),tuple(z[1] for z in pairs)

    def rank_history(P,Q):
        if len(P)!=L or len(Q)!=L:raise ValueError('history length')
        tail=tuple(zip(P[s-1:],Q[s-1:]))
        class_number=rank(tail)
        prefix=tuple(zip(P[:s-1],Q[:s-1]))
        count=prefix_code(tail)
        v=0;a=d=0;previous=(0,0)
        for i,chosen in enumerate(prefix):
            if chosen not in SYMBOLS:raise ValueError('history symbol')
            for z in SYMBOLS:
                if z>=chosen:break
                if (i==0 and z!=(0,0)) or not compatible(previous,z):continue
                v+=count(i+1,a+z[0],d+int(z==(0,1)),z)
            if (i==0 and chosen!=(0,0)) or not compatible(previous,chosen):raise ValueError('history adjacency')
            a+=chosen[0];d+=int(chosen==(0,1));previous=chosen
        if count(g,a,d,previous)==0:raise ValueError('history completion')
        return class_number,v

    info=rec.cache_info()
    return {'L':L,'kP':k,'kQ':k+1,'p':p,'q':q,'dp_states':info.currsize,'transitions':transitions,
            'population':mass_from_tail,'rank':rank,'unrank':unrank,'sample_population':sample_population,'rank_history':rank_history,'unrank_history':unrank_history}


def raw_histories(L,k):
    def configurations(cnt):
        for loc in combinations(range(1,L-1),cnt):
            if all(b-a>1 for a,b in zip(loc,loc[1:])):
                yield frozenset(loc)
    for pset in configurations(k):
        for qset in configurations(k+1):
            if len(pset^qset)==1:
                P=tuple(int(i in pset) for i in range(L))
                Q=tuple(int(i in qset) for i in range(L))
                yield (P,Q)


def slots(L,p,rp,rq):
    c=L-p
    z=[('P',i) for i in range(L-p,L+1)]+[('Q',i) for i in range(L-p,L+1)]
    if rq:z += [('P',i) for i in range(L-p+1,L+1)]
    if rp:z += [('Q',i) for i in range(L-p+1,L+1)]
    z += [('E',i) for i in range(c+1,L+1)]
    return z


def repair_key(P,Q,L,p,rp,rq):
    return tuple(P[i-1] if z=='P' else Q[i-1] if z=='Q' else int(P[i-1]==Q[i-1]) for z,i in slots(L,p,rp,rq))


def native_obs(P,Q):
    def vk(W):return (sum(1 if b==0 else -1 for b in W),0,0,0,0,0)
    def J(W):return tuple(sorted(Counter(zip(W,W[1:])).items()))
    return len(P),len(Q),vk(P),vk(Q),J(P),J(Q),sum(a==b for a,b in zip(P,Q))


def all_future_signatures(raw,p,r=1):
    # Use all 12 signed X6 append directions, independent of A/B raw labels.
    @lru_cache(None)
    def dfs(P,Q,ap,aq,rp,rq):
        branches=[]
        if ap<p and len(P)>1:branches.append(('P_POP',dfs(P[:-1],Q,ap+1,aq,rp,rq)))
        if aq<p and len(Q)>1:branches.append(('Q_POP',dfs(P,Q[:-1],ap,aq+1,rp,rq)))
        if rp<r:
            for z in range(12):branches.append((('P_APPEND',z),dfs(P+(z,),Q,ap,aq,rp+1,rq)))
        if rq<r:
            for z in range(12):branches.append((('Q_APPEND',z),dfs(P,Q+(z,),ap,aq,rp,rq+1)))
        val=(native_obs_general(P,Q),tuple(branches))
        return hash_intern(val)
    unique={}
    def hash_intern(x):
        if x not in unique:unique[x]=len(unique)
        return unique[x]
    ids=tuple(dfs(P,Q,0,0,0,0) for P,Q in raw)
    return ids,dfs.cache_info().currsize,len(unique)


def native_obs_general(P,Q):
    def vk(W):
        v=[0]*6
        for z in W:v[z//2] += (1 if z%2==0 else -1)
        return tuple(v)
    def J(W):return tuple(sorted(Counter(zip(W,W[1:])).items()))
    return len(P),len(Q),vk(P),vk(Q),J(P),J(Q),sum(a==b for a,b in zip(P,Q))


def run():
    cases=0;nonempty=0;raw_total=0;support_total=0;tested_pop=0;tested_codes=0;tested_histories=0
    digest=hashlib.sha256();sample=[];independent=[]
    for L in range(4,12):
        for k in range((L-2)//2+1):
            raw=list(raw_histories(L,k))
            for p in range(L):
                d=suffix_alg(L,k,p)
                groups=Counter((P[L-p-1:],Q[L-p-1:]) for P,Q in raw)
                nkeys=len({repair_key(P,Q,L,p,1,1) for P,Q in raw})
                assert nkeys==len(groups)==d['q'],(L,k,p,nkeys,len(groups),d['q'])
                assert sum(groups.values())==len(raw)
                for P,Q in raw:
                    code=d['rank_history'](P,Q)
                    assert d['unrank_history'](*code)==(P,Q), (L,k,p,code)
                    tested_histories+=1
                for (P,Q), mass in groups.items():
                    tail=tuple(zip(P,Q));idx=d['rank'](tail)
                    assert d['unrank'](idx)==tail
                    assert d['sample_population'](idx)==mass,(L,k,p,tail,mass,d['sample_population'](idx))
                    tested_pop+=1;tested_codes+=1
                for idx in range(d['q']):
                    assert d['rank'](d['unrank'](idx))==idx
                    tested_codes+=1
                cases+=1;nonempty+=int(d['q']>0);raw_total+=len(raw);support_total+=d['q']
                digest.update(f'{L},{k},{p},{len(raw)},{d["q"]}\n'.encode())
                if (L,k,p) in ((8,1,2),(10,2,3),(11,2,4)):
                    sample.append({'L':L,'k':k,'p':p,'raw_histories':len(raw),'future_classes':d['q'],'population_histogram':dict(sorted(Counter(groups.values()).items())),'dp_states':d['dp_states']})
    for L,k,p in ((5,0,1),(6,0,1),(6,1,1),(7,1,1)):
        raw=list(raw_histories(L,k))
        ids,states,subtrees=all_future_signatures(raw,p,1)
        tail_ids=[(P[L-p-1:],Q[L-p-1:]) for P,Q in raw]
        assert all((ids[i]==ids[j])==(tail_ids[i]==tail_ids[j]) for i in range(len(raw)) for j in range(i)),(L,k,p)
        independent.append({'L':L,'k':k,'p':p,'raw_histories':len(raw),'all_twelve_direction_future_states':states,'distinct_observation_subtrees':subtrees,'pair_comparisons':len(raw)*(len(raw)-1)//2})
    large=[]
    for L,k,p in ((32,8,10),(64,15,32),(128,30,60)):
        d=suffix_alg(L,k,p)
        # First/last rank are always feasible when positive, and matched by mass.
        large.append({'L':L,'k':k,'p':p,'q':d['q'],'dp_states':d['dp_states'],'transitions':d['transitions'],
                      'first_class_population':d['sample_population'](0) if d['q'] else 0,
                      'last_class_population':d['sample_population'](d['q']-1) if d['q'] else 0})
    out={'marker':'STAGE445B_EQUAL_LENGTH_ONE_MISMATCH_TAIL_DP_PASS','model':'native_X6_A_B_nonadjacent_one_mismatch_positive_integer_BRC',
         'sweep':{'parameter_cases':cases,'nonempty_cases':nonempty,'raw_history_instances':raw_total,
                  'sum_support_classes':support_total,'classes_population_checked':tested_pop,
                  'rank_unrank_checks':tested_codes,'history_recovery_checks':tested_histories,'digest':digest.hexdigest()},
         'examples':sample,'independent_full_future':independent,'large':large,'all_checked':True}
    print(json.dumps(out,sort_keys=True,separators=(',',':')))

if __name__=='__main__':run()
