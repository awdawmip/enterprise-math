#!/usr/bin/env python3
"""Exact finite-probability observer certificate; NOT native Heartbeat/BRC physical computation.

No floating-point scientific steps; only Fraction and complete 2**6 observer controllers.
"""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
import json

TIME_COST = F(1, 7)
N = {}
def node(name, time, lr, children=()):
    assert name not in N
    N[name] = {"t": time, "r": F(lr), "children": tuple(children)}

node("root", 0, 1, [("a", F(1, 2)), ("b", F(1, 2))])
node("a", 1, F(3, 4), [("al", F(1, 2)), ("am", F(1, 2))])
node("b", 1, F(5, 4), [("bm", F(1, 2)), ("bh", F(1, 2))])
node("al", 2, F(1, 2), [("al3", F(1))])
node("am", 2, 1, [("aml", F(1, 4)), ("amm", F(1, 2)), ("amh", F(1, 4))])
node("bm", 2, 1, [("bml", F(1, 8)), ("bmm", F(3, 4)), ("bmh", F(1, 8))])
node("bh", 2, F(3, 2), [("bh3", F(1))])
for nm, lr in (("al3", F(1, 2)), ("aml", F(1, 2)), ("amh", F(3, 2)),
               ("bml", F(1, 2)), ("bmh", F(3, 2)), ("bh3", F(3, 2))):
    node(nm, 3, lr, [(nm + "4", F(1))])
    node(nm + "4", 4, lr)
node("amm", 3, 1, [("ammL", F(1, 2)), ("ammH", F(1, 2))])
node("bmm", 3, 1, [("bmmL", F(1, 2)), ("bmmH", F(1, 2))])
node("ammL", 4, F(1, 2)); node("ammH", 4, F(3, 2))
node("bmmL", 4, F(3, 4)); node("bmmH", 4, F(5, 4))

for nm, v in N.items():
    if v["t"] == 4:
        assert not v["children"]
    else:
        assert v["children"] and all(p > 0 and child in N for child, p in v["children"])
        assert sum((p for _, p in v["children"]), F(0)) == 1
        assert sum((p * N[ch]["r"] for ch, p in v["children"]), F(0)) == v["r"]

reach = {"root": F(1)}
for t in range(4):
    for nm, v in N.items():
        if v["t"] == t:
            for ch, p in v["children"]:
                assert ch not in reach
                reach[ch] = reach[nm] * p
assert len(reach) == len(N)
assert sum(reach[nm] for nm, v in N.items() if v["t"] == 4) == 1
assert sum(reach[nm] * v["r"] for nm, v in N.items() if v["t"] == 4) == 1
assert reach["am"] == reach["bm"] == F(1, 4)
assert reach["amm"] == F(1, 8) and reach["bmm"] == F(3, 16)
assert N["am"]["r"] == N["bm"]["r"] == N["amm"]["r"] == N["bmm"]["r"] == 1

# The observer knows only (t,lr), and must use one common random kernel for P and Q.
# Stopping is allowed only at t=2,3,4. All final binary decision choices are Bayes-optimal.
@lru_cache(None)
def full_value(nm):
    v = N[nm]; t = v["t"]; lr = v["r"]
    stop = min(lr, F(1)) + TIME_COST * t
    if t == 4:
        return stop, "STOP"
    cont = sum((p * full_value(ch)[0] for ch, p in v["children"]), F(0))
    if t < 2:
        return cont, "CONTINUE"
    return (stop, "STOP") if stop <= cont else (cont, "CONTINUE")

states = sorted({(v["t"], v["r"]) for v in N.values() if v["t"] in (2, 3)})
assert len(states) == 6

def compressed_value(policy):
    @lru_cache(None)
    def value(nm):
        v = N[nm]; t = v["t"]; lr = v["r"]
        if t == 4 or (t >= 2 and not policy[(t, lr)]):
            return min(lr, F(1)) + TIME_COST * t
        return sum((p * value(ch) for ch, p in v["children"]), F(0))
    return value("root")

all_values=[]
for flags in product((False, True), repeat=6):
    pol=dict(zip(states,flags))
    all_values.append(compressed_value(pol))
assert len(all_values)==64
C = min(all_values)
F_full = full_value("root")[0]
assert F_full == F(129,112) and C == F(65,56) and C-F_full == F(1,112)
assert full_value("am")[1] == "CONTINUE" and full_value("bm")[1] == "STOP"
assert full_value("amm")[1] == "CONTINUE" and full_value("bmm")[1] == "STOP"

# All observer states at r=1/2 or 3/2 can stop at once without loss (same LR persists).
# Thus four choices of the two (t,lr=1) actions exhaust the optimum up to dominance.
four={}
for x,y in product((False,True),repeat=2):
    pol=dict.fromkeys(states,False);pol[(2,F(1))]=x;pol[(3,F(1))]=y
    four[(x,y)]=compressed_value(pol)
assert four == {(False,False):F(65,56), (False,True):F(65,56),
                (True,False):F(531,448), (True,True):F(1053,896)}
assert C == min(four.values())

def terminal_law(kind):
    result={}
    pol=dict.fromkeys(states,False) # a deterministic compression minimizer
    def walk(nm, q):
        v=N[nm];t=v["t"];r=v["r"]
        stop=(t == 4 or (t>=2 and (full_value(nm)[1] == "STOP" if kind == "full" else not pol[(t,r)])))
        if stop:
            decision="DQ" if r < 1 else "DP"  # choose DP at r=1 tie
            key=(t,decision)
            q_old,p_old=result.get(key,(F(0),F(0)))
            result[key]=(q_old+q,p_old+q*r)
        else:
            for child,prob in v["children"]:
                walk(child,q*prob)
    walk("root",F(1))
    assert sum(q for q,p in result.values()) == sum(p for q,p in result.values()) == 1
    err_P=sum((p for (t,d),(q,p) in result.items() if d == "DQ"),F(0))
    err_Q=sum((q for (t,d),(q,p) in result.items() if d == "DP"),F(0))
    et_Q=sum((t*q for (t,d),(q,p) in result.items()),F(0))
    return result, (err_P,err_Q,et_Q),err_P+err_Q+TIME_COST*et_Q

full_dist,full_obs,full_J=terminal_law("full")
comp_dist,comp_obs,comp_J=terminal_law("compressed")
assert full_J==F_full and comp_J==C
assert full_obs==(F(3,16),F(5,8),F(19,8))
assert comp_obs==(F(1,8),F(3,4),F(2))

def tv(component):
    keys=set(full_dist)|set(comp_dist)
    ix={"Q":0,"P":1}[component]
    return sum((abs(full_dist.get(k,(F(0),F(0)))[ix]-comp_dist.get(k,(F(0),F(0)))[ix]) for k in keys),F(0))/2
assert tv("Q")==tv("P")==F(1,4)
# TV_P + (1+2/7) TV_Q bounds objective difference: minmax >= gap/(1+9/7)=1/256.
assert (C-F_full) / (F(1)+F(9,7)) == F(1,256)

def fmt(x):return str(x)
report={
 "status":"PASS_EXACT_FRACTION_N4_TWO_COLLISIONS",
 "scope":"finite external Q/P likelihood-ratio martingale, forced continuation to t=2; t in {2,3,4}",
 "positive_nodes":len(N),"compressed_observer_states":len(states),"exhaustive_deterministic_compressed_policies":len(all_values),
 "full_Bellman_min":fmt(F_full),"compressed_min":fmt(C),"signed_support_gap":fmt(C-F_full),
 "objective":"J=P(D=Q)+Q(D=P)+E_Q[T]/7",
 "dominance_reduced_values":{f"t2_r1_continue={x},t3_r1_continue={y}":fmt(v) for (x,y),v in four.items()},
 "two_collisions":{"t2_r1_Q_masses":[fmt(reach['am']),fmt(reach['bm'])],"t3_r1_Q_masses":[fmt(reach['amm']),fmt(reach['bmm'])]},
 "full_witness_observables":{"P_error":fmt(full_obs[0]),"Q_error":fmt(full_obs[1]),"EQ_stop":fmt(full_obs[2])},
 "compressed_minimizer_observables":{"P_error":fmt(comp_obs[0]),"Q_error":fmt(comp_obs[1]),"EQ_stop":fmt(comp_obs[2])},
 "full_witness_joint_laws":{f"t={t},d={d}":{"Q":fmt(q),"P":fmt(p)} for (t,d),(q,p) in sorted(full_dist.items())},
 "compressed_minimizer_joint_laws":{f"t={t},d={d}":{"Q":fmt(q),"P":fmt(p)} for (t,d),(q,p) in sorted(comp_dist.items())},
 "TV_minimizer_P_Q":[fmt(tv('P')),fmt(tv('Q'))],
 "all_compressed_strategies_minimax_TV_lower_bound_for_full_witness":fmt(F(1,256)),
 "formal_admission":"UNREVIEWED_NOT_ADMITTED",
 "native_X6_correspondence":"NOT_ESTABLISHED"
}
if __name__ == "__main__":print(json.dumps(report,sort_keys=True,ensure_ascii=False,indent=2))
