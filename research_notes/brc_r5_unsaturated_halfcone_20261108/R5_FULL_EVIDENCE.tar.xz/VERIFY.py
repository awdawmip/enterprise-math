"""Standalone exact Fraction checker for the R5 42-certificate complete b<=a unsaturated half-cone theorem."""
from fractions import Fraction as F
from pathlib import Path
import json
from itertools import product

R=list(map(F,['1/10','1/2','3/4','1','5/4','3/2','19/10']))
E0=[F(0)]*7
E1=[F(1),F(0),F(0),F(0),F(0),F(0),F(0)]

def source(eta,theta,p,q,g=F(1),s=F(1),kappa=F(1)):
    eta,theta,p,q,g,s,kappa=map(F,(eta,theta,p,q,g,s,kappa))
    return [g,s,s*eta,s*(F(13,40)+eta/80)*p,
            s*(F(9,40)*eta*kappa+theta/10),s*(F(3,40)+F(21,80)*eta)*q,s*theta/10]

def mass(x):
    g,a,b,u,v,w,z=x
    return [F(509,900)*u+F(47,180)*z+F(67,162)*(v-z)+w/100,
            F(13,40)*a+b/80-u,
            (g-a)/2,
            1-g+a/10+F(9,40)*b-v+F(191,450)*(u+w)+F(43,90)*z+F(14,81)*(v-z),
            (g-b)/2,
            F(3,40)*a+F(21,80)*b-w,
            u/100+F(47,180)*z+F(67,162)*(v-z)+F(509,900)*w]

def times(x):
    g,a,b,u,v,w,z=x
    return (1+g+F(3,8)*a+F(5,8)*b+u/2+v+F(3,2)*w,
            1+g+(a+b)/2+u+v+w)

def lawful(x):
    g,a,b,u,v,w,z=x
    return (0<=g<=1 and 0<=a<=g and 0<=b<=g and
            0<=u<=F(13,40)*a+b/80 and
            0<=w<=F(3,40)*a+F(21,80)*b and
            0<=z<=a/10 and z<=v<=z+F(9,40)*b)

def diag(x):
    mm=mass(x)
    return [[mm[i] if i==j else F(0) for j in range(7)] for i in range(7)]

def check(x,y,Q,face=None):
    assert lawful(x),('SOURCE_LAW',x)
    assert lawful(y),('TARGET_LAW',y)
    assert 9*y[2]*y[6]==4*y[1]*(y[4]-y[6]),('SEEDLESS',y)
    if face=='G':assert y[2]==0 and y[4]==y[6]
    if face=='F':assert y[6]==y[1]/10 and y[4]-y[6]==F(9,40)*y[2]
    assert times(x)==times(y),('TIME',times(x),times(y))
    mx,my=mass(x),mass(y)
    assert min(mx+my)>=0
    assert sum(mx)==sum(my)==1
    assert sum(R[j]*mx[j] for j in range(7))==sum(R[i]*my[i] for i in range(7))==1
    assert len(Q)==7 and all(len(row)==7 for row in Q)
    assert all(e>=0 for row in Q for e in row)
    for i in range(7):assert sum(Q[i])==my[i],('ROW',i)
    for j in range(7):
        assert sum(Q[i][j] for i in range(7))==mx[j],('COL',j)
        assert sum(R[i]*Q[i][j] for i in range(7))==R[j]*mx[j],('P_COL',j)
    # Declaration stochasticity and exact P/Q error preservation for three nonconstant D samples.
    for d in [[F(1),0,F(1,3),F(2,5),1,F(1,7),0],
              [0,F(1,2),F(2,3),F(3,4),F(4,5),F(5,6),1]]:
        dd=[sum(Q[i][j]*d[j] for j in range(7))/my[i] if my[i]>0 else F(0) for i in range(7)]
        assert all(0<=v<=1 for v in dd)
        assert sum(mx[j]*d[j] for j in range(7))==sum(my[i]*dd[i] for i in range(7))
        assert sum(R[j]*mx[j]*d[j] for j in range(7))==sum(R[i]*my[i]*dd[i] for i in range(7))

def mix(parts):
    # parts: iterable of (weight, (x,y,Q)) on the same seedless affine face
    parts=[(F(w),tr) for w,tr in parts if F(w)!=0]
    assert sum(w for w,tr in parts)==1 and all(w>=0 for w,tr in parts)
    x=[sum(w*tr[0][k] for w,tr in parts) for k in range(7)]
    y=[sum(w*tr[1][k] for w,tr in parts) for k in range(7)]
    Q=[[sum(w*tr[2][i][j] for w,tr in parts) for j in range(7)] for i in range(7)]
    return x,y,Q

def identity(x):return (x,x,diag(x))

def load():
    raw=json.loads((Path(__file__).parent/'CERTIFICATES.json').read_text())
    dic={}
    for c in raw['certificates']:
        eta,theta,k,p,q,face=c['eta'],c['theta'],c['kappa'],c['p'],c['q'],c['face']
        x=[F(v) for v in c['source']];y=[F(v) for v in c['target']]
        Q=[[F(0)]*7 for _ in range(7)]
        for i,j,t in c['Q_nonzero']:
            assert Q[i][j]==0
            Q[i][j]=F(t)
        assert x==source(eta,theta,p,q,kappa=k)
        check(x,y,Q,face)
        key=(eta,theta,k,p,q,face)
        assert key not in dic
        dic[key]=(x,y,Q)
    assert len(dic)==42
    return dic


D=load()

G_VERT=[('0','0'),('1','0'),('1','1/2')]
F_QUAD=[('0','0'),('0','1'),('1','1'),('1','1/2')]
F_SQUARE=[('0','0'),('0','1'),('1','0'),('1','1')]

def fquad_zero(p,q):
    t=(q-p/2)/(1-p/2)
    weights=[(1-t)*(1-p),t*(1-p),t*p,(1-t)*p]
    return mix(zip(weights,[D[('0','0','0',a,b,'F')] for a,b in F_QUAD]))

def g_triangle_tenth(k,p,q):
    w=[1-p,p-2*q,2*q]
    return mix([
        (w[idx]*weight,D[('1/10','0',key,a,b,'G')])
        for idx,(a,b) in enumerate(G_VERT) for key,weight in [('0',1-k),('1',k)]])

def f_square(e,th,k,p,q):
    w=[(1-p)*(1-q),(1-p)*q,p*(1-q),p*q]
    return mix([(w[idx]*weight,D[(e,th,key,a,b,'F')])
                for idx,(a,b) in enumerate(F_SQUARE) for key,weight in [('0',1-k),('1',k)]])

def normalized(eta,theta,k,p,q):
    eta,theta,k,p,q=map(F,(eta,theta,k,p,q))
    assert 0<=eta<=1 and 0<=theta<=1 and 0<=k<=1 and 0<=p<=1 and 0<=q<=1
    if eta<=F(1,10):
        lam=10*eta
        T=1-lam
        if theta<=T:
            face='G' if q<=p/2 else 'F'
            src0=identity(source(0,0,p,q,kappa=k)) if face=='G' else fquad_zero(p,q)
            src1=g_triangle_tenth(k,p,q) if face=='G' else f_square('1/10','0',k,p,q)
            lin0=identity(source(0,1,p,q,kappa=k))
            lin1=src1
            base=mix([(1-lam,src0),(lam,src1)])
            top=mix([(1-lam,lin0),(lam,lin1)])
            triple=mix([(1-theta/T,base),(theta/T,top)]) if T>0 else base
        else:
            face='F'
            lin0=identity(source(0,1,p,q,kappa=k))
            lin1=f_square('1/10','0',k,p,q)
            top0=identity(source(0,1,p,q,kappa=k))
            top1=f_square('1/10','1',k,p,q)
            line=mix([(1-lam,lin0),(lam,lin1)])
            top=mix([(1-lam,top0),(lam,top1)])
            triple=mix([((1-theta)/(1-T),line),((theta-T)/(1-T),top)])
    else:
        face='F'
        lam=(eta-F(1,10))*F(10,9)
        lo=mix([(1-theta,f_square('1/10','0',k,p,q)),(theta,f_square('1/10','1',k,p,q))])
        hi=mix([(1-theta,f_square('1','0',k,p,q)),(theta,f_square('1','1',k,p,q))])
        triple=mix([(1-lam,lo),(lam,hi)])
    assert triple[0]==source(eta,theta,p,q,kappa=k)
    check(*triple,face)
    return triple,face

def scaled(eta,theta,k,p,q,s,g,h):
    (x,y,Q),face=normalized(eta,theta,k,p,q)
    triple=mix([(s,(x,y,Q)),(g-s,identity(E1)),(1-g,identity(E0))])
    xx,yy,QQ=triple
    assert xx==source(eta,theta,p,q,g,s,k)
    check(*triple,face)
    source_h=[(1-h)*xx[i]+h*yy[i] for i in range(7)]
    qid=diag(yy)
    Q_h=[[(1-h)*QQ[i][j]+h*qid[i][j] for j in range(7)] for i in range(7)]
    check(source_h,yy,Q_h,face)

if __name__=='__main__':
    print('EXACT_ANCHORS_PASS',len(D),'Q_EDGES',sum(sum(1 for v in row if v) for x,y,Q in D.values() for row in Q))
    c=0
    for eta,theta,k,p,q in product(['0','1/100','1/40','1/20','1/10','1/5','1/2','1'],
                                   ['0','1/8','1/4','1/2','3/4','1'],
                                   ['0','1/4','1/2','3/4','1'],
                                   ['0','1/2','1'],['0','1/2','1']):
        normalized(eta,theta,k,p,q)
        c+=1
    print('EXACT_NORMALIZED_PARAMETER_GRID_PASS',c)
    c=0
    for eta,theta,k,p,q,s,g,h in product(['0','1/30','1/10','1/2','1'],
                                         ['0','1/3','2/3','1'],
                                         ['0','1/2','1'],
                                         ['0','1/2','1'],['0','1/2','1'],
                                         ['0','1/3','1'],['1'],['0','1/2','1']):
        scaled(eta,theta,k,p,q,F(s),F(g),F(h))
        c+=1
    print('EXACT_SCALED_INTERPOLATED_GRID_PASS',c)
    print('PASS_R5_UNSATURATED_ALL_REAL_B_LE_A_COMPLETE_FIVE_PARAMETER_PRISM_42_RATIONAL_CERTS')
