#!/usr/bin/env python3
"""Exact exhaustive finite-state quotient of three ordered readouts at horizon 4.
No floating point, no external dependencies. Work of author; does not confer native EM authority.
"""
import itertools, json, hashlib
from collections import defaultdict, Counter
from pathlib import Path

A='012'; N=4
W={t:[''.join(x) for x in itertools.product(A,repeat=t)] for t in range(N+1)}

def readout(w):
    return [int('01' in w), int('10' in w), int(len(w)>=2 and w[-1]==w[-2])]

def counts(w):
    return [w.count(s) for s in A]

def suffixes(n):
    return [''.join(x) for r in range(n+1) for x in itertools.product(A,repeat=r)]

# Method I. Raw future-readout profiles: all suffixes, including empty.
profiles={}
for t in range(N+1):
    ss=suffixes(N-t)
    profiles[t]={w:tuple(tuple(readout(w+z)) for z in ss) for w in W[t]}

# Method II. Bottom-up right-congruence refinement; class labels determined
# independently of exhaustive suffix profiles by local output and children.
ids={}; classes={}; transitions={}; data=[]
for t in reversed(range(N+1)):
    sigs={}
    for w in W[t]:
        sigs[w] = (tuple(readout(w)), tuple(ids[t+1][w+a] for a in A) if t<N else ())
    keys=sorted(set(sigs.values()))
    key2id={s:i for i,s in enumerate(keys)}
    ids[t]={w:key2id[sigs[w]] for w in W[t]}
    groups=defaultdict(list)
    for w in W[t]:groups[ids[t][w]].append(w)
    classes[t]=dict(sorted(groups.items()))
    for i,ws in classes[t].items():
        assert ws==sorted(ws), (t,i)
        assert len({profiles[t][w] for w in ws})==1
    assert len({profiles[t][w] for w in W[t]})==len(classes[t])
    for x,y in itertools.combinations(W[t],2):
        assert (ids[t][x]==ids[t][y]) == (profiles[t][x]==profiles[t][y]), (t,x,y)
    if t<N:
        transitions[t]={i:{a:ids[t+1][ws[0]+a] for a in A} for i,ws in classes[t].items()}
        for i,ws in classes[t].items():
            for w in ws:
                for a in A:
                    assert ids[t+1][w+a]==transitions[t][i][a]
    data.append({'depth':t,'words':len(W[t]),'raw_classes':len(classes[t])})

# Minimal distinguishing suffixes between any pair of raw right-congruence states.
witnesses={}
for t in range(N+1):
    rep={i:ws[0] for i,ws in classes[t].items()}
    wit=[]
    for i,j in itertools.combinations(sorted(rep),2):
        x,y=rep[i],rep[j]
        z=next((z for z in suffixes(N-t) if readout(x+z)!=readout(y+z)),None)
        assert z is not None
        wit.append({'states':[i,j],'reps':[x,y], 'suffix':z,
                    'readouts':[readout(x+z),readout(y+z)]})
    assert len(wit)==len(rep)*(len(rep)-1)//2
    witnesses[t]=wit

# Additional count-conditioned quotient: same-count, same future-readout profile.
# Its transitions may depend on (count, state, letter), not just (state, letter).
count_classes={};count_updates={}
for t in range(N+1):
    fibers=defaultdict(list)
    for w in W[t]:fibers[tuple(counts(w))].append(w)
    cc={}; state_id={}
    for k in sorted(fibers):
        g=defaultdict(list)
        for w in fibers[k]:g[profiles[t][w]].append(w)
        gg=sorted([sorted(q) for q in g.values()],key=lambda q:q[0])
        cc[','.join(map(str,k))]=gg
        for j,arr in enumerate(gg):
            for w in arr:state_id[w]=j
    count_classes[t]=cc
    count_updates[t]=state_id
# Determinism is checked after all depth-indexed partitions have been constructed.
for t in range(N):
    for u,v in itertools.combinations(W[t],2):
        if counts(u)==counts(v) and count_updates[t][u]==count_updates[t][v]:
            for a in A:
                assert count_updates[t+1][u+a]==count_updates[t+1][v+a]

rows=[]
for t in range(N+1):
    max_per=max(map(len,count_classes[t].values()))
    n_distinct=sum(map(len,count_classes[t].values()))
    rows.append({'t':t,'n_words':len(W[t]),'raw_monitor_states':len(classes[t]),
        'joint_count_monitor_states':n_distinct,
        'max_count_conditional_monitor_labels':max_per,
        'n_count_fibers':len(count_classes[t])})

out={'schema':'R1_N14_MONITOR_MIN_V1','alphabet':list(A),'horizon':N,
 'readouts':['has01','has10','lastTwoEqual'],
 'rows':rows,
 'raw_monitor_classes':{str(t):[{'state':i,'representative':ws[0],
          'readout':readout(ws[0]),'members':ws,
          'next':transitions[t][i] if t<N else None} for i,ws in classes[t].items()]
          for t in range(N+1)},
 'distinguishing_suffix_witnesses':{str(t):v for t,v in witnesses.items()},
 'count_conditional_classes':{str(t):v for t,v in count_classes.items()},
 'validation':{'bruteforce_profile_vs_independent_backward_partition':True,
      'all_words_and_transitions_enumerated':True,
      'all_class_pairs_have_distinguishing_suffixes':True,
      'unambiguous_count_conditioned_transitions':True}}

if __name__=='__main__':
    file=Path(__file__).resolve().parent/'RESULT.json'
    file.write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print('PASS: independent exhaustive suffix profile matches backward partition')
    for x in rows:print(x)
    for t in range(N+1):
        print('t',t,'class reps', [(i,ws[0],len(ws)) for i,ws in classes[t].items()])
    print('pairs with distinguishing suffix:',sum(map(len,witnesses.values())))
    print('result_sha256:', hashlib.sha256(file.read_bytes()).hexdigest())
