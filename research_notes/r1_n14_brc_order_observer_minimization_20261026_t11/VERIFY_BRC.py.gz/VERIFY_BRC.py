#!/usr/bin/env python3
"""Independent exact BRC flow test for the finite-horizon minimized monitor."""
from fractions import Fraction as F
from collections import defaultdict
from itertools import product
from pathlib import Path
import json

A='012'; N=4
P={'0':F(1,8),'1':F(1,24),'2':F(5,6)}
Q={'0':F(1,12),'1':F(1,12),'2':F(5,6)}
raw=json.loads((Path(__file__).resolve().parent/'RESULT.json').read_text())
words={t:[''.join(x) for x in product(A,repeat=t)] for t in range(N+1)}
classes={t:{w:it['state'] for it in raw['raw_monitor_classes'][str(t)] for w in it['members']} for t in range(N+1)}
trans={t:{int(it['state']):it['next'] for it in raw['raw_monitor_classes'][str(t)]} for t in range(N)}

def k(w):return tuple(w.count(a) for a in A)
def act(w):
    t=len(w); s=sum((i+1)*int(a) for i,a in enumerate(w))
    if t==N:
        a=F(1+((s+t)%5),6);return (a,1-a,F(0))
    a=F(1+((s+2*t)%3),12)
    b=F(1+((2*s+t)%4),12)
    return a,b,1-a-b

def lprob(w,law):
    out=F(1)
    for a in w:out*=law[a]
    return out

survival={'':F(1)}
orig=defaultdict(lambda:F(0))
flow=defaultdict(lambda:[F(0),F(0),F(0),F(0)])
for t in range(N+1):
    for w in words[t]:
        u=survival.get(w,F(0))
        a,b,c=act(w)
        x=(t,k(w),classes[t][w])
        d=flow[x]
        for j,q in enumerate((u,u*a,u*b,u*c)):d[j]+=q
        for dec,qt in [('P',a),('Q',b)]:
            for model,law in [('P',P),('Q',Q)]:
                orig[(model,t,k(w),classes[t][w],dec)]+=u*qt*lprob(w,law)
        if t<N:
            for sym in A:survival[w+sym]=u*c

compressed={(0,(0,0,0),classes[0]['']):F(1)}
for t in range(N+1):
    for x in [x for x in flow if x[0]==t]:
        v=compressed.get(x,F(0))
        u,a,b,c=flow[x]
        assert u>0 and u==v, (x,u,v)
        if t<N:
            tk,kk,sid=x
            for sym in A:
                nk=list(kk);nk[int(sym)]+=1
                nx=(t+1,tuple(nk),trans[t][sid][sym])
                compressed[nx]=compressed.get(nx,F(0))+v*c/u

compressed_terminal=defaultdict(lambda:F(0))
for (t,kk,sid),v in compressed.items():
    u,a,b,c=flow[(t,kk,sid)]
    for model,law in [('P',P),('Q',Q)]:
        weight=F(1)
        for ai,ki in zip(A,kk):weight*=law[ai]**ki
        compressed_terminal[(model,t,kk,sid,'P')]+=a*weight
        compressed_terminal[(model,t,kk,sid,'Q')]+=b*weight

assert orig==compressed_terminal
for model in ('P','Q'):
    assert sum((v for (m,t,kk,sid,d),v in orig.items() if m==model),F(0))==1

def metrics(dist):
    ret={}
    for model in ('P','Q'):
        ret['e'+model]=sum((v for (m,t,k,sid,d),v in dist.items() if m==model and d!=model),F(0))
        ret['t'+model]=sum((t*v for (m,t,k,sid,d),v in dist.items() if m==model),F(0))
    return {key:f'{v.numerator}/{v.denominator}' for key,v in ret.items()}

out={'model':{'P':['1/8','1/24','5/6'],'Q':['1/12','1/12','5/6']},
  'policy':'positive history-specific rational stopP/stopQ/continue actions, forced terminate at t=4',
  'all_ordered_prefixes':sum(map(len,words.values())),
  'reachable_joint_count_monitor_states':len(flow),
  'terminal_joint_support':len(orig),
  'P_and_Q_terminal_laws_exact_match':True,
  'unweighted_positive_branch_flow_exact_match':True,
  'metrics':metrics(orig)}
p=(Path(__file__).resolve().parent/'BRC_RESULT.json');p.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('PASS BRC exact count+monitor flow & two-law joint terminal distribution')
print(json.dumps(out,indent=2))
