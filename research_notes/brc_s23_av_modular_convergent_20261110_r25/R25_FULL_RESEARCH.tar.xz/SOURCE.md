# Sources and scope

- Canonical previous R24: [PR #1895](https://github.com/awdawmip/enterprise-math/pull/1895), immutable head `005230ba20f7742e6daf6132cb71132505b63284`, particularly `ADDENDUM_15000.md` and `VERIFY_R24_EXTENSION.py` (exact through n15000).
- Predecessor R23: [PR #1891](https://github.com/awdawmip/enterprise-math/pull/1891), head `e3c17f8f9ccb35bdec2e64dc6a9047d7f6a4f809`, labelled-arc translation and plateau through n1174.
- Frozen scientific input: `awdawmip/enterprise-math@43ec6098b1330ae86d0a7863be336c5d97f6ef34` (unchanged).
- New exact theta bounds, local definitions, proof-kernel lemmas and complete finite witness: `PROOF.md` and `VERIFY_R25.py`. Computation evidence from 2026-11-10: `RUN_EVIDENCE.txt`, `EPOCHS_R25.tsv`.
- P000 and the currently applicable account/project mathematical research policy were read as control, not repinned as new science.

Status: source-labelled auxiliary-circle finite exact theorem; not promoted as a native X6 physical result, and not independently reviewed. Shared-task CLAIM is not inferred from this work.
