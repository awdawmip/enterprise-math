#!/usr/bin/env python3
"""S23 AV auxiliary circle: exact rational-enclosure risk epochs, source-labelled gaps.

All proofs are relative to the stated theta interval and integer cut horizon.
R_n = 1 - sum of the longest surviving gaps per original P_128 historical arc.
"""
import bisect
import heapq
import sys
from fractions import Fraction
from pathlib import Path

D=10**24
LOW=262204504569236716045286
HIGH=LOW+1
MID=LOW+HIGH  # theta midpoint numerator over 2D
M=128
N=int(sys.argv[1]) if len(sys.argv)>1 else 36000

def num(z,end):
    return z[0]*D+z[1]*end

def diff(x,y):
    return (x[0]-y[0],x[1]-y[1])

def gap(u,v,rank,fl):
    return (fl[u]-fl[v]+int(rank[u]>rank[v]),v-u)

assert N>=323000, "R25 periodic certificate requires N>=323000"
fl=[j*LOW//D for j in range(N)]
assert all(fl[j]==j*HIGH//D for j in range(N)), 'floor changes across enclosure'
frac=[j*MID%(2*D) for j in range(N)]
S=sorted(range(N),key=lambda j:frac[j]);rank=[0]*N
for r,j in enumerate(S):rank[j]=r
assert len(set(frac))==N
for r,u in enumerate(S):
    v=S[(r+1)%N]
    z=gap(u,v,rank,fl)
    assert num(z,LOW)>0 and num(z,HIGH)>0,('phase-order-change',u,v)

H=sorted(range(M),key=lambda j:rank[j]);hr=[rank[j] for j in H]
# Future neighbour identities from reverse deletion; all cut labels retained.
pr=[(r-1)%N for r in range(N)]
nx=[(r+1)%N for r in range(N)]
neighbours={}
for t in range(N-1,M-1,-1):
    k=rank[t]
    neighbours[t]=(S[pr[k]],S[nx[k]])
    nx[pr[k]]=nx[k];pr[nx[k]]=pr[k]
# Two endpoint-ordered max-heaps make each maximality comparison uniform in theta.
entries={}; hl={j:[] for j in H};hh={j:[] for j in H}

def push(u,v,owner):
    z=gap(u,v,rank,fl)
    assert num(z,LOW)>0 and num(z,HIGH)>0
    entries[u]=(v,z,owner)
    heapq.heappush(hl[owner],(-num(z,LOW),u,v,z))
    heapq.heappush(hh[owner],(-num(z,HIGH),u,v,z))

def peek(owner):
    def keep(h):
        while h:
            _,u,v,z=h[0]
            if entries.get(u)==(v,z,owner):return z
            heapq.heappop(h)
        raise AssertionError('missing owner maximum')
    l=keep(hl[owner]);h=keep(hh[owner])
    assert l==h,('maximum crossing',owner,l,h)
    return l

for k,u in enumerate(H):push(u,H[(k+1)%M],u)
risk=(0,0)
values={M:risk}
epochs=[]
counts={'oldmax':0,'newmax':0,'order_pairs':N}
for t in range(M,N):
    u,v=neighbours[t]
    k=bisect.bisect_right(hr,rank[t])-1
    owner=H[k]
    assert entries[u][0]==v
    assert entries[u][2]==owner
    old=peek(owner);counts['oldmax']+=1
    before=entries.pop(u)[1]
    left=gap(u,t,rank,fl);right=gap(t,v,rank,fl)
    assert (left[0]+right[0],left[1]+right[1])==before
    push(u,t,owner);push(t,v,owner)
    new=peek(owner);counts['newmax']+=1
    delta=diff(old,new)
    assert num(delta,LOW)>=0 and num(delta,HIGH)>=0,('negative risk',t,delta)
    risk=(risk[0]+delta[0],risk[1]+delta[1])
    if epochs and epochs[-1][1]==t and epochs[-1][2]==delta:
        epochs[-1]=(epochs[-1][0],t+1,delta,epochs[-1][3],risk)
    else:
        epochs.append((t+1,t+1,delta,values[t],risk))
    values[t+1]=risk

# R25 newly proved (finite exact) modular law, tested against every event.
def delta_at(n):
    return diff(values[n], values[n-1])
G=(-3749,14298)
H_NEXT=(40385,-154021)
for n in range(14299,25176):
    assert delta_at(n)==(0,0)
for k in range(10):
    for r in range(14298):
        n=25176+14298*k+r
        expected=G if r<67 or 103<=r<164 else (0,0)
        assert delta_at(n)==expected,('periodic law',k,r,n)
assert values[25175]==(109313,-416896)
assert values[168155]==(-4689407,17884544)
for n in range(168156,168320):
    expected=H_NEXT if n<=168222 or n>=168259 else (0,0)
    assert delta_at(n)==expected
assert values[168319]==(479873,-1830144)
for n in range(168320,322177):
    assert delta_at(n)==(0,0)
assert values[322176]==values[200000]==(479873,-1830144)
assert delta_at(322177)==H_NEXT
for n in range(322177,322341):
    expected=H_NEXT if n<=322243 or n>=322280 else (0,0)
    assert delta_at(n)==expected
for n in range(322341,323001):
    assert delta_at(n)==(0,0)
assert values[323000]==(5649153,-21544832)

# Independent complete partition: no heaps or incremental maxima, exact rational endpoint.
check=sorted(set([M,N,128,225,226,292,492,717,1106,1174,1270,3257,7621,14134,14298,15000,
                  18000,20000,24000,25000,26000,30000,35000,40000,50000,55000]+[
                  x for row in epochs for x in (row[0]-1,row[0],row[1]) if x<=N and x>=M]))
check=[n for n in check if M<=n<=N]
assert check[0]==M
for n in check:
    order=sorted(range(n),key=lambda j:frac[j])
    assert order==sorted(range(n),key=lambda j:j*LOW%D)
    assert order==sorted(range(n),key=lambda j:j*HIGH%D)
    maxes={j:None for j in H}
    for j,u in enumerate(order):
        v=order[(j+1)%n]
        k=bisect.bisect_right(hr,rank[u])-1
        owner=H[k]
        z=gap(u,v,rank,fl)
        if maxes[owner] is None or num(z,LOW)>num(maxes[owner],LOW):maxes[owner]=z
    expected=(1-sum(a for a,b in maxes.values()),-sum(b for a,b in maxes.values()))
    assert expected==values[n],('independent partition',n,expected,values[n])

out=Path(__file__).with_name('EPOCHS_R25.tsv')
with out.open('w') as f:
    f.write('n_first\tn_last\tcount\tdelta_A\tdelta_B\tR_before_A\tR_before_B\tR_after_A\tR_after_B\n')
    for a,b,z,prev,r in epochs:
        f.write(f'{a}\t{b}\t{b-a+1}\t{z[0]}\t{z[1]}\t{prev[0]}\t{prev[1]}\t{r[0]}\t{r[1]}\n')
print('PASS_R25_EXACT_BOTH_ENDPOINTS_AND_INDEPENDENT_PARTITIONS')
print('FROZEN_SCIENCE=43ec6098b1330ae86d0a7863be336c5d97f6ef34')
print('THETA_OPEN',f'{LOW}/{D}',f'{HIGH}/{D}')
print('HISTORY',M,'CERTIFIED_N',N,'INSERTIONS',N-M,'EPOCHS',len(epochs))
print('INDEPENDENT_PARTITIONS',len(check),'PHASE_FLOORS_AND_ORDER_PAIRS',N)
for a,b,z,r0,r1 in epochs:
    if b>=14000:print('EPOCH',a,b,'COUNT',b-a+1,'DELTA',z,'END_R',r1)
print('PASS_R25_MODULAR_TEN_CYCLES_AND_154021_SHIFT')
print('TEN_PERIODS=25176..168155; PERIOD=14298; ON_OFFSETS=0..66,103..163')
print('NEXT_JUMP=168156; NEXT_PLATEAU=168320..322176; RESTART=322177')
print('R25175',values[25175],'R168155',values[168155],'R168319=R322176',values[322176])
print('R323000',values[323000]);print('END',values[N])
