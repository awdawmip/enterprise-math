# R25 — exact source-labelled continued-fraction-period law through cut 323,000

Date: 2026-11-10 (Asia/Shanghai). Author-side mathematical research, independent review pending. Scientific input **frozen unchanged** at `awdawmip/enterprise-math@43ec6098b1330ae86d0a7863be336c5d97f6ef34`. Same S23/AV **auxiliary irrational-circle observer** and historical size `m=128` as R23/R24. Prior established frontier: R24 Draft PR #1895, commit `005230ba20f7742e6daf6132cb71132505b63284`, n<=15,000. New research continues that frontier; this theorem concerns the circle observer, not native X6 dynamics.

## Definitions and hypotheses

For an irrational angle theta in the *open* rational interval

```
262204504569236716045286 / 10^24 < theta
 < 262204504569236716045287 / 10^24,
```

put `phi_j={j theta}`, `P_n={phi_j:0<=j<n}`, and let `I` range over the 128 clockwise historical arcs of `P_128`. Write `M_n(I)` for the length of the longest elementary subgap of `I` in `P_n`. The optimal whole-string prediction error in this model is

`R_n := R(128,n-128) = 1 - sum_{I} M_n(I)`, for integers `n>=128`. Denote the insertion increment by `D_n = R_n-R_(n-1)` for `n>=129`.

Let `g=14298 theta-3749>0`, and `h=40385-154021 theta>0`. These are respectively the absolute approximation errors at the consecutive continued-fraction convergents `3749/14298` and `40385/154021`. The signs are verified exactly at both rational interval endpoints. We keep original cut labels `j`; two subgaps of equal length are separate sources and are retained.

## Theorem A: ten exact denominator-period cycles

For every pair of integers

`0 <= k <= 9`, `0 <= r <= 14297`,

put `n=25176+14298*k+r`. **All 142,980 individual increments satisfy**

```
D_n = g   if 0 <= r <= 66 or 103 <= r <= 163,
D_n = 0   for all other r in 0..14297.
```

Equivalently, set `C=109313-416896 theta`, and

`c(r)=min(r+1,67)+min(max(r-102,0),61)`.

Then for every integer `25176<=n<=168155`, with `k=floor((n-25176)/14298)` and `r=(n-25176) mod 14298`, the exact risk is the **single modular formula**

```
R_n = C + (128*k+c(r))*g.
```

In particular, each full period contains 67+61=128 positive insertions and 36+14134=14170 zero insertions. The gap plateaux from `n=25340..39473`, `39638..53771`, and so on through `154022..168155` each have **14,134 consecutive zero increments**. The immediately preceding plateau `n=14299..25175` has 10,877 zero increments. Exact endpoints:

```
R_25175 =  109313 -   416896 theta,
R_168155 = -4689407 + 17884544 theta.
```

The modular evaluation uses one integer quotient/remainder, bounded min/max, and affine arithmetic. It is O(1) *arithmetic operations* within this certified fixed window (integer bit-cost and construction of the certificate counted separately). This direct value formula is new; the discovery/certification algorithm below is not claimed sublinear in the 142,980 tested updates.

## Theorem B: new convergent jump and a 153,857-step plateau

At the next denominator transition, for integer cut counts:

| Newly inserted cut counts | Exact increment |
|---|---|
| `168156..168222` (67) | `h` |
| `168223..168258` (36) | `0` |
| `168259..168319` (61) | `h` |
| **`168320..322176` (153857)** | **`0`** |
| `322177..322243` (67) | `h` |
| `322244..322279` (36) | `0` |
| `322280..322340` (61) | `h` |
| `322341..323000` (660; certified prefix) | `0` |

Thus

```
R_168319 = R_200000 = R_322176 = 479873 - 1830144 theta,
D_322177 = 40385 - 154021 theta > 0,
R_323000 = 5649153 - 21544832 theta.
```

The first nonzero step after the long plateau is `n=322177`, equivalent to **future prediction length `L=n-128=322049`**, independently reproducing the older R13 endpoint. The plateau of 153,857 increments is exactly `154021-164`; the 14,134 plateau is `14298-164`. This recurrence has a constructive exact finite certificate below; extending its structural origin to arbitrary convergents remains an explicit research question.

## General finite-certificate lemmas (exact mathematical proof)

**Lemma 1 — two-endpoint affine-order stability.** Fix `N`, rational `a<b`, and a proposed cyclic order `S` of `phi_0,...,phi_(N-1)` by their fractional parts. Suppose the integers `floor(j theta)` are constant for `theta in [a,b]`, for all `j<N`. For each cyclicly adjacent pair `(u,v)` in `S`, define `z_(u,v)(theta)=floor(u theta)-floor(v theta)+w+(v-u)theta`, where `w=1` if the proposed pair wraps around 1, and `0` otherwise. If `z_(u,v)(a)>0` and `z_(u,v)(b)>0` for every cyclic adjacent pair, then the order is correct for every `theta in [a,b]`. **Proof:** Each ordered fractional difference is exactly the displayed affine function, so it stays positive on the full interval. Because the proposed list is cyclic and contains every distinct fraction, no adjacent pair can reverse without some such difference reaching zero. The special winding pair uses `w=1`. QED.

**Lemma 2 — reverse deletion reconstructs every inserted gap and its labels.** After sorting all `N` labelled fractional parts in a fixed circular order, form cyclic predecessor and successor pointers. Delete labels `N-1,N-2,...,128` in that order, recording the two neighbours immediately before each deletion. At deletion `t`, the active set is exactly `P_(t+1)`, so the recorded neighbours `(u,v)` of `t` are precisely the two endpoints of the old gap split when label `t` was inserted into `P_t`. Each deletion changes only two links. This preserves every cut label and the historical owner. QED (backward induction on `t`).

**Lemma 3 — exact increment via two endpoint maxima.** For the historical owner arc `I`, let `M` and `M'` be the largest subgap before and after inserting `t`. If both rational endpoints select the same integer-affine coefficient pair for `M`, and likewise for `M'`, these respective affine functions are the maxima for the whole interval, because they dominate every candidate at both endpoints. Then `D_(t+1)=M-M'` is the exact affine risk increment on the whole interval. Indeed, the other 127 historical maxima are unchanged. Gap splitting preserves lengths by the integer-affine addition identity. Every gap source is retained even when another has the same length. QED.

## Finite exact proof certificate and actual executed checks

The included `VERIFY_R25.py` implements the three lemmas in exact Python integer arithmetic. It does not approximate theta as a float. It computes the midpoint order only as a candidate, certifies it using endpoint floor and positive-adjacency checks (Lemma 1), recovers **all 322,872** actual insertion destinations by labelled reverse deletion (Lemma 2), and maintains separate heaps of the current historical-arc gaps ordered by their exact lengths at the two rational endpoints (Lemma 3). The chosen affine maximum pair must agree at both endpoints on every update. It checks the two new gap coefficient pairs sum exactly to the deleted gap pair, and checks increment nonnegativity at both endpoints. Finally it checks every single integer increment in both the modular law and the subsequent convergent blocks. Independent reference reconstruction re-sorts full `P_n` at **186** selected counts (every interval boundary plus additional interior counts), computing `1-sum M_n(I)` directly without using the online heaps.

The run with `N=323000` returned:

```
PASS_R25_EXACT_BOTH_ENDPOINTS_AND_INDEPENDENT_PARTITIONS
PASS_R25_MODULAR_TEN_CYCLES_AND_154021_SHIFT
HISTORY=128; INSERTIONS=322872; EPOCHS=86;
INDEPENDENT_PARTITIONS=186; PHASE_FLOORS_AND_ORDER_PAIRS=323000.
```

The complete **86 maximal constant-increment rows** are in `EPOCHS_R25.tsv`. `RUN_EVIDENCE.txt` records the actual stdout of the final executed code. The certificate's exhaustive update check is an exact finite proof for every irrational theta in the stated interval and every integer cut count in the declared window; the proof kernel is integer arithmetic plus sorting, heap and maximum invariants described above. The code is available for independent reproduction and review.

## Algorithmic resources and next mathematical obligation

For declared finite `N` and `m=128`, global phase sorting costs `O(N log N)` arithmetic comparisons, reverse deletion `O(N)`, and two endpoint heaps require `O(N log N)` total work. Stored labels, predecessor/successor pointers, per-gap records, and risk table use `O(N)` memory. The verifier also performs 186 independent full-partition reconstructions, with separate work, and uses 24-decimal-place rational endpoints plus integer-affine coefficients whose bit lengths grow with `N`. Comparisons on rational endpoints use integers with `O(log N + log 10^24)` bits for the present fixed-angle interval; these bit costs, theta input conversion, and output length are not hidden by the arithmetic-operation notation. For `N=323000`, the actual process had approximately 497 MB peak RSS and 34 seconds runtime in the recorded local execution.

**Next open question:** Prove a **symbolic, non-enumerative, source-labelled continued-fraction jump lemma** producing the `67/36/61` on/off offsets and plateau length `q-164` directly from the predecessor convergent errors and 128 historical fibre endpoints, including the change from `q=14298` to `q=154021`. A useful concrete test is to construct exact image/preimage maps of the historical-arc maxima and tie counts under `t -> t+q`, then verify one full cycle without enumerating its `q` insertion events. Until that jump lemma is supplied, Theorems A and B have the stated finite exact certificate and the modular evaluator is available on the certified window.

**Ontology:** The scalar-circle observer is an explicitly scoped auxiliary mathematical model. BRC-inspired preservation here refers to exact source labels, branch multiplicities, destination arcs and future insertions. P000 six-dimensional native space and the independent time dimension are not changed or reduced by this computation.
