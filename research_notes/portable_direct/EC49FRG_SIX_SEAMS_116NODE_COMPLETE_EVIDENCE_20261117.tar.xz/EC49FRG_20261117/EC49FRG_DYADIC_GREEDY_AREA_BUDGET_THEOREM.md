# EC49FRG — Global dyadic-area budget allocation theorem

2026-11-17. Author-proved; no independent project review. Frozen science `fc0f038e7bfd12c886b4d37f900bfb770c0f61ab`.

Consider a finite set of certified price subintervals `[a,b]` with `1<=a<b<=3`, `K(x)=7557-169x`, `D=2185500`, and the upper strip-area enclosure `U(a,b)=D*(b-a)^2/(K(a)*K(b))`. An allowed refinement splits only a currently active interval at its exact arithmetic midpoint. Given M splits, minimize the total enclosure of the resulting leaves.

**Theorem.** The rule “split the current interval of largest U” is a globally optimal M-step dyadic refinement strategy for every finite M. Equivalently, split the current interval with largest `K(a)/K(b)`.

Proof: Arithmetic-midpoint algebra gives `U(a,m)+U(m,b)=U(a,b)/2`, so the reduction from splitting interval I is `U(I)/2`. Let `u=K(a)>v=K(b)>0` and `c=(u+v)/2`. The child-to-parent ratios are `v/(4c)<1/4` and `u/(4c)<1/2`, so every descendant split reward is strictly less than its ancestor reward. All possible midpoint splits form a binary forest; a feasible set of M split nodes is ancestor-closed. Among all possible nodes, the M largest rewards form an ancestor-closed set (with suitable tie choices), hence are feasible and maximize the total reduction. A largest unperformed reward is always accessible among current leaves because any unrevealed descendant has a larger unperformed ancestor. Greedy picks the globally largest remaining reward at every step. Finally `U(a,b)=D/169^2*(r+1/r-2)` with `r=K(a)/K(b)>1` and derivative `1-1/r^2>0`, which proves equivalence of the two greedy criteria. QED.

At the EC49FRF certified 110-node frontier, M=6 yields the exact newly certified prices `105/64,103/64,101/64,99/64,97/64,275/96` in that order, all with separate unrestricted-BRC finite certificates. Hence EC49FRG's 116-node grid is **globally optimal for area enclosure among dyadic midpoint-only 6-split refinements of the old grid**. Its enclosure is `S116=353039202146480393615/236644210143071463572064`. Arbitrary real-node re-spacing is a different feasible class, covered by earlier work.
