from fractions import Fraction as Q
from pathlib import Path
import json
p=Path(__file__).resolve().parent
load=lambda x:json.loads((p/x).read_text())
old71=list(map(Q,load('old71.json')))
prior12=[Q(z['x']) for z in load('prior12seams.json')]
prior3=[Q(z['x']) for z in load('prior3seams.json')]
prior12b=[Q(z['x']) for z in load('prior12_64seams.json')]
new12=[Q(z['x']) for z in load('seams.json')]
ns=sorted(set(old71+prior12+prior3+prior12b+new12))
assert len(ns)==110
K=lambda x:Q(7557)-169*x
G=lambda x:310*(3-x)/K(x)
D=Q(2185500)
new=[]
for i in range(6):
    edges=list(zip(ns,ns[1:])); a,b=max(edges,key=lambda ab:K(ab[0])/K(ab[1]))
    x=(a+b)/2
    print('split',i+1,a,b,'new',x,'gamma',G(x),'ratio',K(a)/K(b))
    new.append(x);ns.append(x);ns.sort()
old=sorted(set(old71+prior12+prior3+prior12b+new12))
area=lambda n:sum((b-a)*(G(a)-G(b)) for a,b in zip(n,n[1:]))
print('area-before',area(old),'area-after',area(ns),'reduction',area(old)-area(ns),'fraction',1-area(ns)/2)
print('all-nodes',len(ns),len(new))
(p/'EC49FRG_PLAN.json').write_text(json.dumps({'new_prices':[str(x) for x in new], 'seams':[{'x':str(x),'lambda':str(G(x))} for x in new], 'old_nodes':[str(x) for x in old],'new_nodes':[str(x) for x in ns],'S_old':str(area(old)),'S_new':str(area(ns)),'fraction':str(1-area(ns)/2)},indent=2)+'\n')
