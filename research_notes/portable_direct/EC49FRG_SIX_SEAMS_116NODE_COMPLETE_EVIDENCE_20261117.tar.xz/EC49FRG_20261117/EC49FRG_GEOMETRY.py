#!/usr/bin/env python3
"""Exact EC49FRG 6-seam BRC grid enclosure; frozen author science EC49FRF.
K is strictly decreasing on [1,3]. No floating point for theorem tests.
"""
from fractions import Fraction as F
from math import isqrt
from decimal import Decimal, localcontext
from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent
obj=json.loads((B/'EC49FRG_PLAN.json').read_text())
old=list(map(F,obj['old_nodes']));new=list(map(F,obj['new_nodes']))
add=list(map(F,obj['new_prices']))
assert len(old)==110 and len(new)==116 and len(add)==6
assert old[0]==new[0]==1 and old[-1]==new[-1]==3
K=lambda x:F(7557)-169*x
G=lambda x:310*(3-x)/K(x)
D=F(2185500)
S=lambda n:sum((b-a)*(G(a)-G(b)) for a,b in zip(n,n[1:]))
Se=lambda n:D/F(169**2)*sum(K(a)/K(b)+K(b)/K(a)-2 for a,b in zip(n,n[1:]))
assert S(old)==Se(old) and S(new)==Se(new)
assert S(old)==F(259924479610030238135,162277343928838082317536)
assert S(new)==F(obj['S_new'])
# Verify the sequence of six choices: greedy current ratio = max K(a)/K(b)
work=old.copy();splits=[]
for x in add:
 es=list(zip(work,work[1:]))
 a,b=max(es,key=lambda z:K(z[0])/K(z[1]))
 assert x==(a+b)/2
 parent=(b-a)*(G(a)-G(b))
 after=(x-a)*(G(a)-G(x))+(b-x)*(G(x)-G(b))
 assert 2*after==parent   # New exact arithmetic-midpoint area-halving law
 splits.append({'a':str(a),'b':str(b),'x':str(x),'parent_area':str(parent),'exact_area_reduction':str(parent/2)})
 work=sorted(work+[x])
assert work==new
assert S(old)-S(new)==sum(F(z['exact_area_reduction']) for z in splits)
assert sorted(add)==sorted(F(z['x']) for z in obj['seams'])
assert all(F(z['lambda'])==G(F(z['x'])) for z in obj['seams'])
# Outward rational sqrt bounds imply rigorous ranking of each radical interval bound.
scale=10**40
def sqrt_bounds(v):
 k=isqrt(v.numerator*scale**2//v.denominator)
 low,high=F(k,scale),F(k+1,scale)
 assert low*low<=v<high*high
 return low,high
def rb(a,b):
 a0,a1=sqrt_bounds(K(a));b0,b1=sqrt_bounds(K(b))
 return 50*(b-a)/(a1+b1)**2,50*(b-a)/(a0+b0)**2
r_old=[(a,b,*rb(a,b)) for a,b in zip(old,old[1:])]
r_new=[(a,b,*rb(a,b)) for a,b in zip(new,new[1:])]
old_max=max(r_old,key=lambda q:q[2]);new_max=max(r_new,key=lambda q:q[2])
assert all(old_max[2]>z[3] for z in r_old if z is not old_max)
assert all(new_max[2]>z[3] for z in r_new if z is not new_max)
assert new_max[3]<old_max[2]
with localcontext() as ctx:
 ctx.prec=75
 def dec(v):return Decimal(v.numerator)/Decimal(v.denominator)
 def regret(a,b):return 50*dec(b-a)/(dec(K(a)).sqrt()+dec(K(b)).sqrt())**2
 out={
 'schema':'EC49FRG_116_NODE_BRC_CERTIFICATE_V1',
 'source_parent':'EC49FRF PR #2610 @ e3633f0d819888a13e430d66828a5f94d2310bf2',
 'scientific_pin':'fc0f038e7bfd12c886b4d37f900bfb770c0f61ab',
 'price_nodes':len(new),'price_intervals':len(new)-1,
 'new_seams':obj['seams'], 'greedy_bisections':splits,
 'area_identity_for_any_arithmetic_midpoint':'S[a,m]+S[m,b]=S[a,b]/2',
 'S110':str(S(old)), 'S116':str(S(new)),
 'exact_area_reduction':str(S(old)-S(new)),
 'certified_fraction_lower_bound':str(1-S(new)/2),
 'certified_percent_lower_bound':str(100*(1-S(new)/2)),
 'old_max_gap':list(map(str,old_max[:2])), 'new_max_gap':list(map(str,new_max[:2])),
 'old_max_regret_times_t':str(regret(*old_max[:2])),
 'new_max_regret_times_t':str(regret(*new_max[:2])),
 'new_max_regret_rational_lower':str(new_max[2]),'new_max_regret_rational_upper':str(new_max[3]),
 'all_outward_sqrt_bounds_verified':True, 'unique_max_regret_bound_rigorously_verified':True,
 'author_evidence_status':'AUTHOR_COMPUTED_EXACT_FINITE_CHECKED_NOT_PROJECT_REVIEWED'
 }
 print(json.dumps(out,indent=2,ensure_ascii=False))
 (B/'EC49FRG_GEOMETRY_RESULT.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
