# EC49FRG — Six exact native BRC seams, 116-node continuum enclosure and arithmetic-bisection lemma

**Research date:** 2026-11-17. **Status:** `AUTHOR_PROVED / EXACT_FINITE_CHECKED / NOT_REVIEWED`. Parent EC49FRF is on GitHub PR #2610 at commit `e3633f0d819888a13e430d66828a5f94d2310bf2`. Original scientific pin `fc0f038e7bfd12c886b4d37f900bfb770c0f61ab` remains unchanged. Source files SHA256: frozen master `cd9a50799536d2b96230777b5392b1d742ceee896da05bb49aa097cf351e1d5e`; frozen profile CSV `a61a3ee4d2f13f9d216f52cd3529c72d395c1250bfb1d7ae96a1adf5a6837c1f`.

## 1. Native BRC problem and six new critical-price certificates

Population: original native class 16943, 310 raw configurations, 141 complete **named** profile states, 228 legal physical observations (144 terminal, 84 root). Duplicate response partitions may be memoized for optimization, but their physical action labels are retained for reporting all first-action ties. Prior on profile i is `p_i(lambda)=(1-lambda)/141+lambda*m_i/310`, with `0<=lambda<=1`. Root observation cost is `xt`, terminal observation cost `t`, where `t>0, x>=1`. The unrestricted finite adaptive-tree Bellman minimum is `V(x,lambda)`.

In the parent verified model, three feasible fixed trees have expected costs divided by t:

```
A(x,l)=(1-l)*(6*x+290)/141+l*(6*x+751)/310
B(x,l)=(1-l)*(5*x+293)/141+l*(5*x+704)/310
C(x,l)=(1-l)*(5*x+295)/141+l*(5*x+685)/310
G(x)=310*(3-x)/(7557-169*x); beta=620/3299
```

At each of the **six newly sampled prices** `x`, the critical prior `lambda=G(x)` has now been solved by the full unrestricted integer Bellman recurrence, independently reproduced by a separately written weighted-subset recurrence and complete replay of all tied first-action trees. The native Bellman and independent recurrence agree on 141 profiles, 228 physical first actions and exactly four minimizing first actions `{32,34,140,142}`.

| Price x | Critical lambda | Exact weighted Bellman integer minimum | Raw certificate SHA256 |
|---|---|---:|---|
| 105/64 | 8990/155301 | 932113535360 | `55822a25acdd11e3fa79f1f59c42280b8f3482ce979b51a6dc1efc9c1beb6173` |
| 103/64 | 27590/466241 | 2797241381760 | `4775ab99e39816c1078f5f20223549b5a604290cbb5d6070e052dc9668c7b0c3` |
| 101/64 | 28210/466579 | 2798142157440 | `cac3cb35d549d247879f6fe242f493e7e7031014a0a0fb7f4c01f16f06fb232e` |
| 99/64 | 9610/155639 | 933014311040 | `f3f11f7c2287a00d48e2fa586163f7538a863541057edf070b9df14aaeea8282` |
| 97/64 | 5890/93451 | 559988741760 | `b5506fb8f45dbdc0cde73ecaf2326d002d21282b48dc3eda273ec21888b9d6dc` |
| 275/96 | 4030/678997 | 6212385506880 | `fa6e116005a8bcaeeb6d3e936542a62f1fd18c15be7446052cfa6ae4dd801443` |

The weighted integer objective in every row is scaled by `x.denominator*310*141*G(x).denominator`; it is not the normalized cost itself. At each x, `V(x,G(x)) = t*A(x,G(x)) = t*B(x,G(x))`. As in EC49FRF, **conditional on inherited exact endpoint certificates and named-first-action exclusion lemma**, fixed-tree affine-in-prior costs and concavity of the Bellman minimum extend this to `V(x,l)=t*min(A,B,C)` for every real `l` in `[0,1]`, with optimizing named first actions `{32,34}` below `G(x)`, `{140,142}` between `G(x)` and `beta`, `{16,23}` above `beta`, and adjacent unions at the respective seams. This is an author mathematical inference using inherited hypotheses, not an independent review of those hypotheses.

## 2. New exact arithmetic-midpoint area-halving lemma

Let `1<=a<b<=3`, `K(x)=7557-169*x>0`, `G(x)=310*(3-x)/K(x)` and `D=2185500`. The existing strict upper enclosure of the unverified parameter-strip area for a certified endpoint pair is

```
U(a,b)=(b-a)*(G(a)-G(b)) = D*(b-a)^2/(K(a)*K(b)).
```

**Theorem.** For the rational arithmetic midpoint `m=(a+b)/2`,

```
U(a,m)+U(m,b)=U(a,b)/2,   
U(a,b)-U(a,m)-U(m,b)=U(a,b)/2.
```

**Proof.** Write `u=K(a)`, `v=K(b)`. Since K is affine, `K(m)=(u+v)/2`. With `h=b-a`, the children have width `h/2`, and

```
U(a,m)+U(m,b)
=D*h^2/(4*K(m))*(1/u+1/v)
=D*h^2/(4*((u+v)/2))*((u+v)/(u*v))
=U(a,b)/2.
```

The identity is exact for all permitted real endpoints; rational a,b yield an exact rational new price without solving any radicals. It is a property of the *enclosure functional*, not a statement that the unknown true suboptimal area is exactly halved. It gives an exact error-budget reduction and a simple proof-check for every new dyadic midpoint.

The six new rational price nodes were selected sequentially from the current 110-node frontier by choosing the largest present `K(a)/K(b)` (equivalently, largest `log K` width) and inserting the arithmetic midpoint. The choices, in order, are:

```
[13/8,53/32] ->105/64
[51/32,13/8] ->103/64
[25/16,51/32] ->101/64
[49/32,25/16] -> 99/64
[3/2,49/32] -> 97/64
[137/48,23/8] ->275/96
```

This is an **exact greedy dyadic scheme**; the previous continuous placement theorem uses equal-log-K points. The two are deliberately distinguished.

## 3. Certified 116-node enclosure and rigorous maximal regret

The six new complete-price certificates increase the validated price nodes from 110 to 116, yielding 115 remaining uncertified parameter bands. Let `S(P)=sum_(adjacent a,b) U(a,b)` for certified-node set P. Fully exact rational results:

```
S110=259924479610030238135/162277343928838082317536
S116=353039202146480393615/236644210143071463572064
S110-S116=19144978000085375/174245733138392004168
certified_fraction >= 1-S116/2
=472935381083996446750513/473288420286142927144128
certified_percent >= 99.92540717519920764%.
```

The existing intervalwise global gap bound for a pair a,b is

```
R(a,b)/t = 50*(b-a)/(sqrt(K(a))+sqrt(K(b)))^2.
```

With the inherited outside-range certificate and new exact-price endpoint certificates, the complete `x>=1, lambda in [0,1]` global strategy bound is `0<=t*min(A,B,C)-V(x,lambda)<=0.000036800695366496801*t` (rounded upward). The **unique largest** interval error enclosure among the 115 intervals is now `[17/6,137/48]`; previous largest was `[13/8,53/32]`, at `0.000053659239846837*t`. The new upper guarantee improves by about **31.4178%**. To certify uniqueness and the strict old-to-new improvement, the checker encloses every positive square root in rational intervals of width `10^-40` using integer `isqrt`, then proves the winning lower enclosure exceeds every other upper enclosure.

These are exact rational/geometric and rigorous radical enclosure claims conditional on the already published endpoint-to-continuum interval lemma. Raw BRC native certificates and full independent replications support the six newly introduced endpoint claims.

## 4. Additional exact parametric Bellman lemma: bilinear rectangle inheritance

For any fixed deterministic fully separating adaptive BRC decision tree `T`, let `n_i^r(T),n_i^t(T)` be its root/terminal observation counts on profile i. The normalized cost is

```
F_T(x,l)=sum_i [(1-l)/141+l*m_i/310]*(x*n_i^r(T)+n_i^t(T)).
```

For any other tree Q, `F_Q-F_T` is bilinear in `(x,l)`. Suppose `a<b`, `c<d`, and the **same fixed T** is Bellman-optimal at all four corners of the rectangle `[a,b]x[c,d]`. For any Q, its nonnegative four corner gaps bilinearly interpolate with weights `(1-s)(1-u),s(1-u),(1-s)u,su`, `s=(x-a)/(b-a)`, `u=(l-c)/(d-c)`. The gaps stay nonnegative throughout. Hence **T is globally optimal over the entire rectangle**. No smoothness/monotonicity assumption on the optimal policy is required. This can turn future four-corner certificates into exact continuous two-parameter BRC regions; a rectangle crossing a genuine A/B policy seam requires subdivision or a different certificate.

For comparison on the policy seam `l=G(x)`, any fixed competitor tree Q has `F_Q-F_A=(p+qx)+(s+hx)l`; multiplying by the strictly positive `K(x)` reduces its seam gap to a quadratic integer/rational-coefficient polynomial `N_Q(x)=K(x)*(p+qx)+310*(3-x)*(s+hx)`. Positivity on a price segment can therefore be checked by its two endpoints and its interior vertex when the quadratic coefficient is positive. This is a finite exact *verification condition* for a named tree competitor, not yet an enumeration of all competitors. It provides the next parametric Bellman certificate direction.

## 5. Verification, scope and next unresolved question

The primary native routine is `code/EC49FQL_ALL_FIRST_BELLMAN.py` inherited from the parent evidence bundle; an independently written weighted-subset Bellman recursion is `code/EC49FRG_INDEPENDENT_VERIFY.py`. All six exact weighted totals, all 228 named first-query costs and all four optimal first-tree replays passed. Geometry script `EC49FRG_GEOMETRY.py` recomputes every rational identity, all six greedy selections and all 115 radical interval enclosures. The exact scientific source files, scripts, original full certificates, validation results, SHA256 manifest and a parent evidence archive are in this round's self-contained evidence bundle. No secrets or credentials are included.

**Open mother-objective question:** On the 115 remaining parameter bands, either construct a parameterized Bellman lower-bound certificate proving `V=t*min(A,B,C)` for all continuous prices and priors, or exhibit an exact action-labeled adaptive tree strictly improving this candidate in one band. The bilinear rectangle lemma permits immediate exact certification in regions with a single common optimal tree; the seam quadratic condition isolates the harder switch region. The work remains `AUTHOR_PROVED / EXACT_FINITE_CHECKED / NOT_REVIEWED` and establishes no new formal Task CLAIM, Result or Review.
