# EC49FRG self-contained original native BRC scientific evidence

2026-11-17, unreviewed author proof / exact finite computation. Exact immutable BRC scientific source pin `fc0f038e7bfd12c886b4d37f900bfb770c0f61ab` and unmodified frozen source SHA256 in `EC49FRG_THEOREM.md`.

## Reproduce

Run from the extracted `EC49FRG_20261117` directory:

```
python EC49FRG_GEOMETRY.py
PYTHONPATH=code python code/EC49FRG_INDEPENDENT_VERIFY.py 0 3
PYTHONPATH=code python code/EC49FRG_INDEPENDENT_VERIFY.py 3 6
```

These checks use exact integer/rational arithmetic and return `EC49FRG_EXACT_116_NODE...` / `ALL_NEW_CERTIFICATES_VERIFIED`. The independent checker rebuilds 141 named profiles and all 228 physical observations from the two frozen input files, computes exact unrestricted subset DP for each six new price/prior anchor and replays the four optimal first-action trees in each raw certificate. No prior GitHub network access is required to recheck this archive.

The prior native Bellman implementation is in `code/EC49FQL_ALL_FIRST_BELLMAN.py`; new full raw JSON outputs are in `new_certificates/`; `PARENT_EC49FRF_FULL_EVIDENCE.tar.xz` contains the complete 110-node inherited evidence. `EC49FRG_THEOREM.md` gives the exact theorem, dependence, geometry, verification scope, unresolved questions and source hashes. This is project-native author evidence and has no formally authenticated CLAIM/Result/Review or independent mathematical project acceptance.
