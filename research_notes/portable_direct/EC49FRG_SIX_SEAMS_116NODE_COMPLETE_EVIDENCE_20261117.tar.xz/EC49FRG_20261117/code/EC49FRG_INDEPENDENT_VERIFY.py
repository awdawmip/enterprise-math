#!/usr/bin/env python3
"""Independent exact Bellman checker for EC49FQY 6 EC49FRG parameter anchors.
Scope: class 16943, 141 profiles, 228 physical observations, frozen inputs.
Uses separate subset dynamic programming, not native solver's dual-objective routine.
"""
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
from collections import defaultdict
import hashlib, json, sys, gc
from EC49FQI_NATIVE_DATA import V, weights, reps, PIN, MASTER, CSV
B=Path(__file__).resolve().parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(B/'source/frozen_original_master.txt')==MASTER
assert sha(B/'source/EC49FPG_PROFILE.csv')==CSV
assert PIN=='fc0f038e7bfd12c886b4d37f900bfb770c0f61ab'
assert len(V)==228 and len(reps)==141 and len(weights)==141 and sum(weights)==310
N=len(reps); FULL=(1<<N)-1
physical=[]; partition_repr={}
for q,outputs in enumerate(V):
 groups={}
 for i,v in enumerate(outputs):groups[v]=groups.get(v,0)|(1<<i)
 parts=tuple(sorted(groups.values()))
 physical.append(tuple(groups.values()))
 partition_repr.setdefault(parts,q)
assert len(partition_repr)==209

def bits(m):
 while m:
  b=m&-m; yield b.bit_length()-1; m^=b

def independent_bellman(price_x,lam):
 r,t=price_x.numerator,price_x.denominator
 prices=[t]*144+[r]*84
 masses=[310*(lam.denominator-lam.numerator)+141*lam.numerator*k for k in weights]
 assert sum(masses)==310*141*lam.denominator
 low=min(r,t)
 @lru_cache(None)
 def mass(s):return sum(masses[i] for i in bits(s))
 @lru_cache(None)
 def one(s):
  if s.bit_count()<2:return 0
  best=10**50
  for p,q in partition_repr.items():
   if all((s & y).bit_count()<=1 for y in p):
    best=min(best,prices[q]);
    if best==low:break
  return best
 @lru_cache(None)
 def two(s):
  if s.bit_count()<2:return 0
  best=10**60
  for p,q in partition_repr.items():
   parts=[s&y for y in p if s&y]
   if len(parts)<2:continue
   cost=prices[q]*mass(s)+sum(one(u)*mass(u) for u in parts if u.bit_count()>1)
   best=min(best,cost)
  assert best<10**60
  return best
 @lru_cache(None)
 def bellman(s):
  if s.bit_count()<2:return 0
  best=two(s)
  for p,q in partition_repr.items():
   parts=[s&y for y in p if s&y]
   if len(parts)<2:continue
   unfinished=[u for u in parts if u.bit_count()>1]
   if prices[q]*mass(s)+low*sum(mass(u) for u in unfinished)>=best:continue
   cost=prices[q]*mass(s)
   for u in unfinished:
    cost+=bellman(u)
    if cost>=best:break
   if cost<best:best=cost
  return best
 v=bellman(FULL); first=[]
 for q,parts in enumerate(physical):
  if len(parts)<2:continue
  cost=prices[q]*mass(FULL)+sum(bellman(u) for u in parts if u.bit_count()>1)
  if cost==v:first.append(q)
 return v,first,bellman.cache_info().currsize

def replay(t):
 stats=[0]*4
 for i in range(N):
  node=t; seen=set()
  while 'leaf' not in node:
   q=node['q'];assert q not in seen and 0<=q<228
   seen.add(q)
   if q>=144:stats[0]+=1;stats[2]+=weights[i]
   else:stats[1]+=1;stats[3]+=weights[i]
   node=node['children'][str(V[q][i])]
  assert node['leaf']==i
 return stats

def A(l,x):return (1-l)*(6*x+290)/141+l*(6*x+751)/310
def Bf(l,x):return (1-l)*(5*x+293)/141+l*(5*x+704)/310
def C(l,x):return (1-l)*(5*x+295)/141+l*(5*x+685)/310
def gamma(x):return 310*(3-x)/(7557-169*x)
beta=Q(620,3299)

records=[]
from pathlib import Path
from fractions import Fraction as F
import json
for entry in json.loads((B/'EC49FRG_PLAN.json').read_text())['seams'][int(sys.argv[1]) if len(sys.argv)>1 else 0:int(sys.argv[2]) if len(sys.argv)>2 else 6]:
 x=F(entry['x']); lam=F(entry['lambda']); assert lam==gamma(x)
 p=B/'EC49FRG_new_certificates'/f'{x.numerator}_{x.denominator}_{lam.numerator}_{lam.denominator}.json'
 cert=json.loads(p.read_text())
 assert cert['frozen_scientific_commit']==PIN and cert['source_master_sha256']==MASTER
 assert cert['native_root_costs_sha256']==CSV and cert['reps']==reps
 assert cert['raw_multiplicities']==weights
 assert cert['prices']=={'root':x.numerator,'terminal':x.denominator}
 assert cert['interpolation']['numerator']==lam.numerator and cert['interpolation']['denominator']==lam.denominator
 expected_total=min(A(lam,x),Bf(lam,x),C(lam,x))*x.denominator*310*141*lam.denominator
 assert expected_total.denominator==1
 actual,first,states=independent_bellman(x,lam)
 assert actual==expected_total.numerator==cert['optimal_total_interpolated']
 assert first==[32,34,140,142]==cert['optimal_first_interpolated']==sorted(map(int,cert['all_optimal_first_trees']))
 vectors={}
 for q,tree in cert['all_optimal_first_trees'].items():
  assert int(q)==tree['q']
  ur,ut,mr,mt=replay(tree)
  reconstructed=(310*(lam.denominator-lam.numerator)*(ur*x.numerator+ut*x.denominator)+141*lam.numerator*(mr*x.numerator+mt*x.denominator))
  assert reconstructed==actual
  vectors[q]=[ur,ut,mr,mt]
 records.append({'x':str(x),'lambda':str(lam),'optimum_integer':actual,'all_first':first,'visited_subsets':states,'replayed_vectors':vectors,'certificate_sha256':sha(p)})
 print('EXACT_INDEPENDENT_PASS',x,lam,actual,first,states,flush=True)
(B/f'EC49FRG_INDEPENDENT_VERIFY_{sys.argv[1] if len(sys.argv)>1 else 0}_{sys.argv[2] if len(sys.argv)>2 else 6}.json').write_text(json.dumps({'scope':{'profiles':N,'physical_queries':len(V),'distinct_partitions':len(partition_repr)},'frozen_pin':PIN,'records':records,'status':'EXACT_COMPUTATIONAL_AUTHOR_CHECK_NOT_INDEPENDENT_PROJECT_REVIEW'},indent=2)+'\n')
assert len(records)==(int(sys.argv[2])-int(sys.argv[1]) if len(sys.argv)>2 else 6)
print('ALL_NEW_CERTIFICATES_VERIFIED',flush=True)
