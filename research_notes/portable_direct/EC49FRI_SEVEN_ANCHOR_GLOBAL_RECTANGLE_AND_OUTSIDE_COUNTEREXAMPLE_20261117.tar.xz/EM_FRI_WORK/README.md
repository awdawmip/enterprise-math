# EC49FRI — Full exact BRC rectangle proof evidence (2026-11-17)

Frozen scientific input `fc0f038e7bfd12c886b4d37f900bfb770c0f61ab`; 141 complete named profiles, 228 original physical actions.

**New:** an unconditional exact theorem *inside the frozen model* for every real `1<=root_price/terminal_price<=3`, `0<=lambda<=1` showing `V/t=min(A,B,C)`. Proof uses exact positive profile multiplicities on transition seam, concavity in price of every competitor's positively scaled seam cost, and endpoint Bellman optimality. This closes all 127 previously uncertain price intervals at once without extrapolating finite sampling.

**Correction:** the previously stated uniform `x>=1` regret upper bound relative to `min(A,B,C)` is false: for every `x>3`, `lambda=0`, a fixed replayed tree improves the candidate by at least `(x-3)/141` in normalized t units. At `x=4`, exact unrestricted Bellman value is `312/141` against `313/141` candidate.

Run exact structural, source, receipt and tree-replay checks:

```
python code/EC49FRI_SEAM_THEOREM_CHECK.py
```

Rerun each of 8 native integer Bellman computations, using `code/EC49FQL_ALL_FIRST_BELLMAN.py source/frozen_original_master.txt source/EC49FPG_PROFILE.csv endpoints/<name>.json <root_price_num> <terminal_price_den> <lambda_num> <lambda_den>`.

Rerun the independent subset Bellman implementation (native data rebuilt from frozen sources):

```
python code/EC49FRI_INDEPENDENT_8_CHECKS.py 0 3
python code/EC49FRI_INDEPENDENT_8_CHECKS.py 3 5
python code/EC49FRI_INDEPENDENT_8_CHECKS.py 5 7
python code/EC49FRI_INDEPENDENT_8_CHECKS.py 7 8
```

Inputs and algorithms included. The independent implementation is separate code but an author-side verification, not project-independent review. Full theorem in `EC49FRI_GLOBAL_OPTIMALITY_AND_OUTSIDE_COUNTEREXAMPLE_20261117.md`; output in `EC49FRI_EXACT_CHECK_RESULT.json`; original parent provenance in `PARENT_EC49FRH_FULL_EVIDENCE.tar.xz`. `MANIFEST_SHA256.json` gives all byte digests. No credentials or platform-issued runtime capability stored.

Status: AUTHOR_PROVED / EXACT_FINITE_CHECKED / NOT_REVIEWED; portable research. No formal CLAIM/Result/Review/Activity completion is claimed.
