#!/usr/bin/env python3
"""Exact finite anchor/replay and rational identity checks for EC49FRI.

The infinite-domain extrapolation in the companion theorem follows from
its explicit concavity/affinity proof; the assertions here independently
check the exact frozen boundary facts and the proof's model coefficients.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib, json
from EC49FQI_NATIVE_DATA import V,weights,reps,cost_pair,PIN,MASTER,CSV

B=Path(__file__).resolve().parent.parent
S=B/'source';E=B/'endpoints'
assert PIN=='fc0f038e7bfd12c886b4d37f900bfb770c0f61ab'
assert hashlib.sha256((S/'frozen_original_master.txt').read_bytes()).hexdigest()==MASTER
assert hashlib.sha256((S/'EC49FPG_PROFILE.csv').read_bytes()).hexdigest()==CSV
assert len(V)==228 and len(reps)==len(weights)==141 and sum(weights)==310
assert all(isinstance(w,int) and w>=1 for w in weights)

A=(6,290,6,751)
Btree=(5,293,5,704)
C=(5,295,5,685)
D=(4,296,4,707)
K=lambda x:7557-169*x
G=lambda x:F(310)*(3-x)/K(x)
beta=F(620,3299)
def score(stats,x,l):
 uR,uT,mR,mT=stats
 return (1-l)*(uR*x+uT)/141+l*(mR*x+mT)/310
def candidates(x,l):return [score(s,x,l) for s in (A,Btree,C)]
checks=[
 (F(1),F(0),F(296,141),[32,34]),
 (F(1),F(155,1847),F(7861,3694),[32,34,140,142]),
 (F(1),beta,F(7080,3299),[16,23,140,142]),
 (F(1),F(1),F(69,31),[16,23,124,131]),
 (F(3),F(0),F(308,141),[32,34,140,142]),
 (F(3),beta,F(7290,3299),[16,23,140,142]),
 (F(3),F(1),F(70,31),[16,23,59,88]),
 (F(4),F(0),F(312,141),[32,34,140,142]),
]
results=[]
certs={}
for x,l,expected,first in checks:
 f=E/f'x{x.numerator}-{x.denominator}_l{l.numerator}-{l.denominator}.json'
 cert=json.loads(f.read_text())
 assert cert['frozen_scientific_commit']==PIN
 assert cert['source_master_sha256']==MASTER and cert['native_root_costs_sha256']==CSV
 assert cert['profile_count']==141 and cert['config_count']==310
 assert cert['terminal_actions']==144 and cert['named_root_actions']==84
 assert cert['raw_multiplicities']==weights and cert['reps']==reps
 assert cert['prices']=={'root':x.numerator,'terminal':x.denominator}
 assert cert['interpolation']['numerator']==l.numerator and cert['interpolation']['denominator']==l.denominator
 assert cert['optimal_first_interpolated']==first
 assert sorted(int(q) for q in cert['all_optimal_first_trees'])==first
 opt=F(cert['optimal_total_interpolated'],x.denominator*310*141*l.denominator)
 assert opt==expected,(x,l,opt,expected)
 for q,tree in cert['all_optimal_first_trees'].items():
  assert int(q)==tree['q']
  t=cost_pair(tree)
  vec=(t['U_R'],t['U_T'],t['M_R'],t['M_T'])
  assert score(vec,x,l)==opt,(x,l,q,vec,opt)
 certs[(x,l)]=cert
 if x<=3: assert opt==min(candidates(x,l))
 else: assert x==4 and l==0 and opt<min(candidates(x,l))
 results.append({'x':str(x),'lambda':str(l),'unrestricted_optimum':str(opt),'first':first,
                 'raw_json_sha256':hashlib.sha256(f.read_bytes()).hexdigest()})

# Replay the full physical named-action tree (no abstraction/port collapse).
def vector(x,l,q):
 tree=certs[(F(x),F(l))]['all_optimal_first_trees'][str(q)]
 t=cost_pair(tree)
 return t['U_R'],t['U_T'],t['M_R'],t['M_T']
assert vector(1,0,32)==A
assert vector(1,0,34)==A
assert vector(1,G(F(1)),140)==Btree
assert vector(1,G(F(1)),142)==Btree
assert vector(1,beta,16)==C
assert vector(1,beta,23)==C
assert vector(3,0,140)==D

# Full symbolic integer identity: for a vector of tree counts, the
# quadratic coefficient of K(x)*cost(x,G(x)) is U_R - M_R.
def poly_seam(s):
 uR,uT,mR,mT=s
 # K C_Q = (x+47)(uR*x+uT)+(3-x)(mR*x+mT).
 return (uR-mR,
         47*uR+uT+3*mR-mT,
         47*uT+3*mT)
assert poly_seam(A)==poly_seam(Btree)==(0,-161,15883)
assert all(poly_seam((cost_pair(tree)['U_R'],cost_pair(tree)['U_T'],
                      cost_pair(tree)['M_R'],cost_pair(tree)['M_T']))[0]<=0
           for cert in certs.values() for tree in cert['all_optimal_first_trees'].values())
assert G(F(1))==F(155,1847) and G(F(3))==0 and 0<G(F(1))<beta<1
assert score(D,F(4),0)==F(312,141)
assert min(candidates(F(4),F(0)))-score(D,F(4),F(0))==F(1,141)
# Strict outside-range witness for all x>3 is algebraic:
# minABC(x,0)=B(x,0) and B(x,0)-D(x,0)=(x-3)/141.
for x in map(F,[F(3001,1000),4,5,10,100]):
 assert min(candidates(x,F(0)))==score(Btree,x,0)
 assert min(candidates(x,F(0)))-score(D,x,0)==(x-3)/141

# Cross-check all eight independent-subset results from saved direct reruns.
audit=[]
for first_idx,last_idx in ((0,3),(3,5),(5,7),(7,8)):
 f=B/f'EC49FRI_INDEPENDENT_{first_idx}_{last_idx}.json'
 j=json.loads(f.read_text())
 assert j['frozen_pin']==PIN and j['model_profile_count']==141
 assert len(j['records'])==last_idx-first_idx
 for z in j['records']:
  x,l=F(z['price']),F(z['prior']); c=certs[(x,l)]
  assert z['optimum_integer']==c['optimal_total_interpolated']
  assert z['first']==c['optimal_first_interpolated']
  assert z['source_certificate_sha256']==hashlib.sha256((E/f'x{x.numerator}-{x.denominator}_l{l.numerator}-{l.denominator}.json').read_bytes()).hexdigest()
  audit.append([str(x),str(l),z['visited_subsets']])

out={'scientific_pin':PIN,'native_class':16943,'certified_domain':'1<=x<=3;0<=lambda<=1',
     'global_cost_theorem':'V(x,lambda)=min(A,B,C) exactly for all real parameters in rectangle',
     'gap_inside_rectangle_exact':0,
     'outside_counterexample':{'domain':'x>3;lambda=0','candidate_gap_lower_bound':'(x-3)/141',
                               'example_x4_real_gap':'1/141'},
     'all_named_states':141,'all_physical_actions':228,
     'original_source_master_sha256':MASTER,'original_profile_sha256':CSV,
     'candidate_vectors':{'A':A,'B':Btree,'C':C,'D':D},
     'seam_candidate_integer_polynomial':list(poly_seam(A)),
     'validated_8_native_anchors':results,'independent_bellman_checks':audit,
     'status':'AUTHOR_PROVED_EXACT_FINITE_AUTHOR_CHECK_NOT_REVIEWED'}
(B/'EC49FRI_EXACT_CHECK_RESULT.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('EC49FRI 8/8 NATIVE AND INDEPENDENT CHECKS PASSED')
print('SEVEN ANCHORS PROVE ENTIRE REAL RECTANGLE; x>3 PARAMETRIC COUNTEREXAMPLE')
print('OUTPUT:',B/'EC49FRI_EXACT_CHECK_RESULT.json')
