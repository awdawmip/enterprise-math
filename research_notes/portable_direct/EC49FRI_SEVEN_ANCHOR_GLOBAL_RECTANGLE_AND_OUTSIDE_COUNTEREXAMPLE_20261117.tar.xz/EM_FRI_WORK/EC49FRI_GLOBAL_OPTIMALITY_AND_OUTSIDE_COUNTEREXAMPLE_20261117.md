# EC49FRI — Seven-anchor complete Bellman classification on the full price-prior rectangle and a sharp outside-range counterexample

Status: **AUTHOR_PROVED / EXACT_FINITE_CHECKED / NOT_REVIEWED**. Date: 2026-11-17. Parent: EC49FRH, [PR #2618](https://github.com/awdawmip/enterprise-math/pull/2618), frozen scientific commit `fc0f038e7bfd12c886b4d37f900bfb770c0f61ab`. No P000, scientific pin or observation interface has changed.

## Statement, model and provenance

For the frozen BRC class 16943: 310 original configurations, 141 distinct *named* root profiles with strictly positive integer multiplicities `m_i`, `sum_i m_i = 310`, 144 terminal and 84 named root physical actions, and 209 distinct response partitions. Let terminal cost `t>0` and root cost `xt`, `x >= 1`. For `0<=lambda<=1`, the profile prior is

`p_i(lambda) = (1-lambda)/141 + lambda*m_i/310`.

Every fully identifying adaptive decision tree is allowed. Let `V(x,lambda)` be the minimum expected total cost divided by `t`. The following three fixed native decision trees, already present in the frozen research, have exact expected normalized costs:

```
A(x,lambda) = (1-lambda)*(6*x+290)/141 + lambda*(6*x+751)/310
B(x,lambda) = (1-lambda)*(5*x+293)/141 + lambda*(5*x+704)/310
C(x,lambda) = (1-lambda)*(5*x+295)/141 + lambda*(5*x+685)/310
```

Their fixed per-profile root/terminal query counts are reconstructed and replayed from the physical original observations in the accompanying code, not presumed from the labels alone.

Set

```
K(x) = 7557 - 169*x
G(x) = 310*(3-x)/K(x)
beta = 620/3299
```

**Theorem A (exact global completion on a continuous rectangle).** For every real `1<=x<=3` and `0<=lambda<=1`, with the exact frozen BRC actions and input,

`V(x,lambda) = min{A(x,lambda), B(x,lambda), C(x,lambda)}`.

In particular the entire `[1,3] x [0,1]` rectangle is certified; the former 128-node, 99.931059%-area enclosure is an independently valid but strictly weaker sufficient enclosure on this rectangle. The optimal cost is *exact* for all real parameter values in the rectangle, rather than a finite sampling or an extrapolation from numerical agreement.

**Theorem B (all optimal first observations on the rectangle).** For `1<x<3`, the complete optimal physical first-action sets are:

| Prior | Exact optimal first-action indices |
|---|---|
| `lambda=0` or `0<lambda<G(x)` | `{32,34}` |
| `lambda=G(x)` | `{32,34,140,142}` |
| `G(x)<lambda<beta` | `{140,142}` |
| `lambda=beta` | `{16,23,140,142}` |
| `beta<lambda<=1` | `{16,23}` |

At the price boundaries these same sets apply away from two end-corners, with `G(3)=0`. At `(x,lambda)=(3,0)` the optimal set is `{32,34,140,142}`; at `(1,1)` it is `{16,23,124,131}`; at `(3,1)` it is `{16,23,59,88}`. All sets are *physical named action indices*, with no silent port-collapse quotient.

**Theorem C (global-price qualifier correction and parametric strict counterexample).** The three-tree formula `min(A,B,C)` is *not* a uniform regret approximation on the half-line `x>=1`. A fourth **feasible fixed native tree** `D`, replayed from the frozen `x=3, lambda=0, first action 140` certificate, has counts `(U_R,U_T,M_R,M_T)=(4,296,4,707)`. Thus, at every `x>3`, `lambda=0`,

```
V(x,0) <= D(x,0) = (4*x+296)/141
min(A(x,0),B(x,0),C(x,0)) = B(x,0) = (5*x+293)/141
min(A,B,C) - V(x,0) >= (x-3)/141 > 0.
```

At the fully checked exact point `(x,lambda)=(4,0)`, `V(4,0)=312/141`, whereas `min(A,B,C)=313/141`: the actual gap is `1/141`, greater than the earlier claimed all-`x>=1` bound `0.000036582279225540488`. Thus that prior *half-line version* of the regret claim requires correction; the present zero-gap rectangle theorem is unaffected. The growing lower bound `(x-3)/141` gives an infinite counterexample family rather than just an isolated sampled failure. The outside-range optimal policy family remains a distinct open problem.

## Proof of Theorem A — exact seam lifting and concavity

A fixed decision tree `Q` has, for each named profile `i`, nonnegative integer numbers `r_i` and `d_i` of root-price and terminal-price observations along its uniquely identified outcome path. Hence its expected cost, divided by `t`, is

`C_Q(x,lambda) = sum_i p_i(lambda)*(r_i*x+d_i)`.

For each **fixed** prior `lambda`, `C_Q(x,lambda)` is affine in `x`; for each fixed price `x`, it is affine in `lambda`. Since the physical state/action universe is finite and every eligible tree separates finite profiles, the unrestricted Bellman optimum is the minimum over such finite-tree costs. This also establishes concavity of `V(x,lambda)` separately in each scalar parameter.

The first transition curve `lambda=G(x)` has a decisive algebraic identity:

```
K(x)*p_i(G(x)) = (47+x) + m_i*(3-x)
               = (47+3*m_i) + (1-m_i)*x.
```

Indeed, `K(x)-310*(3-x)=141*(47+x)`. For every feasible fixed tree `Q`, define its polynomial numerator along the curved seam:

```
P_Q(x) = K(x)*C_Q(x,G(x))
       = sum_i [(47+3*m_i)+(1-m_i)*x]*(r_i*x+d_i).
```

Its quadratic coefficient is `sum_i (1-m_i)*r_i <= 0`, because *the exact named-profile multiplicities satisfy `m_i>=1`* and `r_i>=0`. Therefore **every** tree's seam numerator `P_Q` is concave as a quadratic in the real price `x`.

The A and B fixed trees have the same uniform and multiplicity-weighted counts of root observations (`U_R=M_R=6` for A; `U_R=M_R=5` for B). Their quadratic coefficients vanish. Direct substitution yields the **same linear seam numerator**:

```
P_A(x) = P_B(x) = 15883 - 161*x.
```

For `1<=x<=3` we have `K(x)>0`, and `0<=G(x)<=155/1847<620/3299=beta`.

The *unrestricted* native integer Bellman recurrence, independently recomputed by a second weighted-subset implementation, certifies at the two price endpoints that `V(1,G(1))=A(1,G(1))=B(1,G(1))` and `V(3,G(3))=A(3,0)=B(3,0)`. For **any** feasible tree `Q`, the polynomial `P_Q-P_A` is concave and nonnegative at both `x=1` and `x=3`. Therefore, by concavity, it is nonnegative on the **whole real interval** `[1,3]`. Thus `A=B=V` on the full curved seam `lambda=G(x)`.

At each of the three horizontal lines `lambda=0`, `lambda=beta`, `lambda=1`, unrestricted exact Bellman certificates at both `x=1` and `x=3` agree respectively with the fixed A, B=C, C policies. Since the difference `C_Q(x,lambda)-C_A/C_B/C_C(x,lambda)` is **affine** in `x` on a fixed prior line, endpoint nonnegativity proves global optimality of the indicated policy along the entire corresponding horizontal line.

Now fix any `x in [1,3]`. The four prior knots appear in order

`0 <= G(x) < beta < 1`.

They are already certified; the proposed minimum of A/B/C is **affine in lambda on each adjacent prior interval**, choosing A then B then C. The unrestricted `V(x,lambda)=min_Q C_Q(x,lambda)` is concave in `lambda`, and so lies **at least** as high as the chord between the proven optimal knot values. That chord is the exact A/B/C candidate cost. Conversely those three feasible trees give `V<=min(A,B,C)` everywhere. Equality follows on all prior intervals. QED.

## Proof of complete first-action classification (Theorem B)

At each anchor the exact native recurrence evaluates every physical first action (228) and the independently implemented recurrence agrees on the exact optimal index set. On each fixed-prior horizontal line, if a competitor tree becomes optimal at an interior price, its nonnegative affine gap to the already proven candidate must vanish identically, so its first action must belong to the **intersection** of the optimal first-action sets at the two price endpoints. The endpoint sets yield `{32,34}` at `lambda=0` in `1<x<3`; `{16,23,140,142}` at `lambda=beta`; and `{16,23}` at `lambda=1`.

On `G(x)`, each competitor tree's gap after positive multiplication by `K(x)` is a nonnegative concave quadratic. If such a gap vanished at a price interior to `[1,3]`, the nonnegative endpoint gaps would both have to vanish (the concavity chord is nonnegative). Thus every interior-seam optimal first action belongs to the intersection of endpoint action sets `{32,34,140,142}`.

For fixed `x`, within each open prior interval, the gap of any fixed tree from the identified candidate is affine in `lambda` and nonnegative at both ends. An interior zero forces a zero at both endpoints. Therefore the first-action sets are restricted to the intersections of consecutive knot first-action sets, respectively `{32,34}`, `{140,142}` and `{16,23}`. The *existence* of every listed action throughout its claimed region follows by replay of the fixed A (`32,34`), B (`140,142`), and C (`16,23`) native trees, whose exact cost vectors are unchanged with `x` and `lambda`. The three special corner ties are read directly from the exact 228-action Bellman certificates. QED.

## Exact native anchor table (new, independently reproduced)

`L` denotes the normalized Bellman optimum `V(x,lambda)`. All eight checks use original frozen byte hashes and all 228 physical observations; each native certificate includes a decision tree for every optimal first action and replay against all 141 named profiles.

| x | lambda | V exact | all optimal physical first actions | purpose |
|---|---|---|---|---|
| 1 | 0 | 296/141 | 32,34 | horizontal A left |
| 1 | 155/1847 | 7861/3694 | 32,34,140,142 | curved A=B left |
| 1 | 620/3299 | 7080/3299 | 16,23,140,142 | horizontal B=C left |
| 1 | 1 | 69/31 | 16,23,124,131 | horizontal C left |
| 3 | 0 | 308/141 | 32,34,140,142 | curved/horizontal right |
| 3 | 620/3299 | 7290/3299 | 16,23,140,142 | horizontal B=C right |
| 3 | 1 | 70/31 | 16,23,59,88 | horizontal C right |
| 4 | 0 | 312/141 | 32,34,140,142 | strict half-line counterexample |

The native certificate numerical column is exact: `optimal_total_interpolated / (x.denominator*310*141*lambda.denominator)`. The second implementation's `independent_bellman` separately computes all 209 distinct partitions of the 228 physical observations, using exact integer rational-prior mass weights. The 8 per-anchor results agree exactly. Two independently written algorithms are an author-side cross-check, **not** independent project REVIEW or formal acceptance.

## Reproduction, source typing and future question

Original frozen inputs:

- `source/frozen_original_master.txt`, SHA256 `cd9a50799536d2b96230777b5392b1d742ceee896da05bb49aa097cf351e1d5e`;
- `source/EC49FPG_PROFILE.csv`, SHA256 `a61a3ee4d2f13f9d216f52cd3529c72d395c1250bfb1d7ae96a1adf5a6837c1f`;
- native parser and exact Bellman: `code/EC49FQL_ALL_FIRST_BELLMAN.py`;
- independent profile reconstruction, full-tree replay and weighted subset Bellman: `code/EC49FQI_NATIVE_DATA.py`, `code/EC49FRI_INDEPENDENT_8_CHECKS.py`;
- algebraic proof checks and manifest audit: `code/EC49FRI_SEAM_THEOREM_CHECK.py`;
- native full certificates: eight `endpoints/*.json`, with corresponding calculation and independent-recheck logs.

Complete source/terminals are copied unchanged from parent EC49FRH archive (the self-contained archive includes the parent provenance for continuity). The exact calculation uses typed full named profiles and the same frozen raw action vectors; it is an identification/cost problem and makes no change to P000 native space or physical temporal evolution claims.

**Next:** use the proven outside-price obstruction to find the exact phase boundaries for `x>3`, including the sequence of cheaper root-count trees and their prior-dependent transitions. A small focused next step is to test `x=4` at the additional prior knots, derive a finite candidate policy family, and seek an analogous algebraic region certificate; preserve the now-closed `[1,3]` rectangle without further sampling.

**Operational state:** portable author research; no CLAIM, Result, independent REVIEW or shared Activity write is inferred from these files. A separate original task/publication/owner projection would be needed for formal adoption. GitHub Draft PR preserves published artifacts but is not canonical main.
