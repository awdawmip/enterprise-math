#!/usr/bin/env python3
"""PREFIX539: exact local BRC cocycle, dense/sparse shared-seed and raw checks.
Four STAR X6 candidate, immutable science f42f2906d77f24085c123f3ccfe9667d41caa96d.
Standard-library Python; exact integer arithmetic, no external dependencies.
"""
import gc
import json
import statistics
import time
import tracemalloc
from collections import defaultdict, Counter

STARS=((1,3,6),(1,4,5),(2,3,5),(2,4,6))
def near(a,c): return tuple((-1 if c>0 else 1)*x for x in STARS[a] if x!=abs(c))
PH=tuple((a,p,e*x) for a in range(4) for x in STARS[a] for e in (-1,1) for p in near(a,e*x))
IX={x:i for i,x in enumerate(PH)}
def successors(i):
    a,p,c=PH[i]
    b=next(b for b in range(4) if b!=a and abs(c) in STARS[b])
    return tuple(IX[x] for x in [(a,c,k) for k in near(a,c) if k!=p]+[(b,c,k) for k in near(b,c)])
NX=tuple(successors(i) for i in range(48))
T=IX[(0,1,-3)]
SIG=tuple((1 if x[2]>0 else -1) if abs(x[2])==1 else 0 for x in PH)
EPS=tuple(abs(x) for x in SIG)
assert len(PH)==48 and all(len(a)==3 for a in NX)
assert all(SIG[j]==0 for i in range(48) if SIG[i] for j in NX[i])

def tau(r,i,j):
    numerator=EPS[i]+EPS[j]-abs(SIG[j]-r)+abs(SIG[i]-r)
    assert numerator%2==0
    value=numerator//2
    assert value in (0,1)
    return value

TAU={r:tuple(tuple(tau(r,i,j) for j in NX[i]) for i in range(48)) for r in (-1,0,1)}
# Exact algebraic telescope: sum tau = (K - |sigma_end-r| + |sigma_start-r|)/2.
def upper(d): return (d+1)//3, (d+2)//4

def dense_shared(n):
    """Three sign-seed backward DP, 96 phase/last-INNER states each.
    Dense rectangles are safely capped; on requested roots the sharp triangle
    0<=h<=H, h<=p<=M is checked and extracted. Returns 48 rooted histograms.
    """
    out=[[None]*(n+1) for _ in range(48)]
    peak_alloc=0
    for r in (-1,0,1):
        states=[[[1]] for _ in range(96)]   # index 2*i+previous_INNER
        mp=mh=0
        for d in range(n+1):
            M,H=upper(d)
            for root in range(48):
                if SIG[root]!=r: continue
                poly={(p,h):v for p,row in enumerate(states[2*root])
                      for h,v in enumerate(row) if v}
                assert sum(poly.values())==6**d
                assert all(h<=p<=M and h<=H for p,h in poly)
                out[root][d]=poly
            peak_alloc=max(peak_alloc,96*(mp+1)*(mh+1))
            if d==n: break
            # For arbitrary phase / external seed r the p and h exponents may
            # exceed rooted bounds. Telescope and spacing give these safe caps.
            new_mp=(d+1)//3+2
            new_mh=(d+3)//4+1
            width=new_mh+1
            next_states=[]
            for i in range(48):
                for b in (0,1):
                    tab=[[0]*width for _ in range(new_mp+1)]
                    for choice,j in enumerate(NX[i]):
                        dp=TAU[r][i][choice]
                        for inner in (0,1):
                            dh=int(b and inner and j==T)
                            source=states[2*j+inner]
                            for p,row in enumerate(source):
                                if p+dp>new_mp: assert not any(row); continue
                                dest=tab[p+dp]
                                for h,value in enumerate(row):
                                    if value:
                                        assert h+dh<=new_mh
                                        dest[h+dh]+=value
                    next_states.append(tab)
            states=next_states
            mp,mh=new_mp,new_mh
    return out,peak_alloc

BACK=tuple(Counter(EPS[i]+2*EPS[m]+EPS[T] for m in NX[i] if T in NX[m]) for i in range(48))
assert sum(sum(x.values()) for x in BACK)==9

def sparse_shared(n):
    """Independent predecessor's 49-coordinate rank-one polynomial lift."""
    out=[[None]*(n+1) for _ in range(48)]
    peak_terms=0
    for r in (-1,0,1):
        f=[{(2-abs(SIG[i]-r),0):1} for i in range(48)]
        g={}
        for d in range(n+1):
            for root in range(48):
                if SIG[root]!=r: continue
                poly={}
                for (e,h),v in f[root].items():
                    assert e>=2 and e%2==0 and v>0
                    poly[((e-2)//2,h)]=v
                out[root][d]=poly
                assert sum(poly.values())==6**d
            peak_terms=max(peak_terms,sum(map(len,f))+len(g))
            if d==n:break
            ff=[]
            for i in range(48):
                a=defaultdict(int)
                for j in NX[i]:
                    k=EPS[i]+EPS[j]
                    for (e,h),v in f[j].items(): a[(e+k,h)]+=2*v
                for k,m in BACK[i].items():
                    for (e,h),v in g.items(): a[(e+k,h)]+=m*v
                ff.append({key:value for key,value in a.items() if value})
            gg=defaultdict(int)
            for (e,h),v in f[T].items():
                gg[(e,h+1)]+=v
                gg[(e,h)]-=v
            f,g=ff,{key:value for key,value in gg.items() if value}
    return out,peak_terms

def raw_all(n):
    """Independent forward enumeration of phase, last-INNER, K, gate number."""
    out=[]
    for root in range(48):
        states={(root,0,0,0):1}
        hist=[]
        for d in range(n+1):
            poly=defaultdict(int)
            for (i,b,k,h),value in states.items():
                delta=abs(SIG[i]-SIG[root])
                assert k>=delta and (k-delta)%2==0
                poly[((k-delta)//2,h)]+=value
            assert sum(poly.values())==6**d
            hist.append(dict(poly))
            if d==n:break
            nxt=defaultdict(int)
            for (i,b,k,h),value in states.items():
                for j in NX[i]:
                    nxt[(j,0,k+EPS[i]+EPS[j],h)]+=value
                    nxt[(j,1,k+EPS[i]+EPS[j],h+int(b and j==T))]+=value
            states=nxt
        out.append(hist)
    return out,len(states)

def measured(fn,n,repeats=1):
    runs=[]
    for _ in range(repeats):
        gc.collect()
        tracemalloc.start()
        begin=time.perf_counter()
        result,aux=fn(n)
        sec=time.perf_counter()-begin
        peak=tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        runs.append((sec,peak))
    return result,aux,{'wall_seconds_median':round(statistics.median(x[0] for x in runs),6),
                       'peak_traced_bytes_max':max(x[1] for x in runs),'runs':repeats}

def main():
    data=[]
    for d in (8,16,20):
        dense,alloc,ta=measured(dense_shared,d)
        sparse,terms,tb=measured(sparse_shared,d)
        raw,states,tc=measured(raw_all,d)
        assert dense==sparse==raw
        M,H=upper(d)
        cap=(H+1)*(M+1)-H*(H+1)//2
        values=[dense[r][d] for r in range(48)]
        assert all(len(v)<=cap for v in values)
        data.append({'depth':d,'root_depth_equalities':48*(d+1),
                     'sharp_support_slots_per_root':cap,'max_nonzero_coefficients':max(map(len,values)),
                     'distinct_rooted_polynomials':len({tuple(sorted(v.items())) for v in values}),
                     'dense_3_seed':ta,'sparse_rank_one_3_seed':tb,'raw_48_forward':tc,
                     'dense_max_allocated_integer_cells':alloc,'sparse_peak_monomials':terms})
        print('checked',d,'dense',ta,'sparse',tb,'raw',tc,flush=True)
    # Exhaustive finite check of the local cocycle law for every seed and directed edge.
    assert sum(len(NX[i]) for i in range(48))==144
    for r in (-1,0,1):
        for i in range(48):
            for j in NX[i]:
                assert tau(r,i,j) in (0,1)
    result={'status':'ALL_CHECKS_PASS','source_pin':'f42f2906d77f24085c123f3ccfe9667d41caa96d',
            'python_arithmetic':'exact unbounded integers','benchmark':'same Python process, tracemalloc ON for all methods, gc before each run, 1 repeat',
            'model':'four STAR X6 directed paths, two INNER/OUTER branches, consecutive INNER gate aAc',
            'all_directed_edge_seed_checks':432,'rows':data,
            'proof_scope':'tau local additive cocycle is universal for legal paths under frozen signed-axis BRC endpoint formula',
            'math_review':'AUTHOR_DERIVED / FINITE_TESTED / UNREVIEWED / NOT_ADMITTED'}
    with open('PREFIX539_EXACT_BENCHMARK_SUMMARY.json','w') as f:json.dump(result,f,indent=2)
    print('ALL_CHECKS_PASS')

if __name__=='__main__':main()
