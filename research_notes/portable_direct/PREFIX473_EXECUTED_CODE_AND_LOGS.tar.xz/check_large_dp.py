import sys
sys.path.insert(0,'/mnt/data/prefix473')
import prefix473_joint_codec as c
cur={(c.START,0):1}
for n in range(9):
    states=set(cur)
    qsets=[{f for f,q in states if q==i} for i in range(4)]
    assert len(states)==c.F(n)
    assert len({f for f,q in states})==c.B(n)
    assert tuple(map(len,qsets))==tuple([c.Q0(n)]+[c.B(n-i) for i in (1,2,3)])
    if n>=6:
        ordered=sorted(states)
        picked=[ordered[i] for i in sorted(set([0,1,len(ordered)//4,len(ordered)//2,3*len(ordered)//4,len(ordered)-2,len(ordered)-1]))]
        for f,q in picked:
            j=c.rank_joint(n,f,q)
            assert c.unrank_joint(n,j)==(f,q)
            for h in range(4):
                j=c.rank_horizon(n,f,q,h)
                ff,cl=c.unrank_horizon(n,j,h)
                assert (ff,cl)==(f,c.qclass(q,h))
    print('DP',n,'states',len(states),'paths',sum(cur.values()),'H',tuple(c.csize(n,h) for h in range(4)),'PASS',flush=True)
    if n<8:cur=c.next_dp(cur,n)
print('DP_COUNTS_AND_SAMPLED_CODEC_ALL_PASS')
