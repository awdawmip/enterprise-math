#!/usr/bin/env python3
"""PREFIX-473: dictionary-free full/finite-horizon aba X6 BRC joint support codec.
All states, ranks and checks use exact Python integers. No network/no external deps.
This code is an independently executed reference, not a native execution authority.
"""
from math import comb, factorial
from collections import defaultdict

# Base code reproduces the exact formulas already proved in PREFIX-472.
WEIGHT=(1,2,3,4,2)
def pbin(t,d):
    v=1
    for i in range(d): v*=t-i
    return v//factorial(d)
def P(m): return sum(a*pbin(m-h+7,7) for h,a in enumerate(WEIGHT))
def diff(f,degree):
    v=[f(i) for i in range(degree+1)]; out=[]
    while v:
        out.append(v[0]); v=[v[i+1]-v[i] for i in range(len(v)-1)]
    return out
def poly_prefix(ds,n): return sum(a*comb(n,i+1) for i,a in enumerate(ds) if i+1<=n)
def smax(n,k): return (n+k)//(k+1)
def M(n,k,s): return n if s==0 else n-1-(s-1)*(k+1)
def s_prefix(n,k,s):
    if s==0:return 0
    return P(n)+poly_prefix(diff(lambda j:P(n-1-j*(k+1)),7),s-1)
def R(t):return (t+1)*(3*t+2)//2
def c5poly(q): return (4*q**4+20*q*q+6)//3
def shell_prefix(m,t):
    a=poly_prefix(diff(lambda j:R(j)*c5poly(m-2*j),6),t)
    if m%2==0 and t==m//2+1: a-=R(m//2)
    return a
def c(j,q):
    if q<0:return 0
    if j==0:return int(q==0)
    return sum(comb(j,a)*comb(q-a+j-1,j-1) for a in range(min(j,q)+1))
def H(j,q):
    if q<0:return 0
    return sum(comb(j,a)*comb(q-a+j,j) for a in range(min(j,q)+1))
def prefix_signed(rem,j,v):
    assert -rem<=v<=rem
    if v<0:return H(j,rem+v)
    return 2*H(j,rem-1)+c(j,rem)-H(j,rem-v-1)
def rank_vec(d):
    rem=sum(abs(x) for x in d);out=0
    for i,x in enumerate(d):
        if x>-rem:out+=prefix_signed(rem,4-i,x-1)
        rem-=abs(x)
    assert rem==0
    return out
def unrank_vec(q,idx):
    assert 0<=idx<c(5,q)
    ans=[];rem=q
    for i in range(5):
        lo,hi=-rem,rem
        while lo<hi:
            mid=(lo+hi)//2
            if prefix_signed(rem,4-i,mid)>idx: hi=mid
            else:lo=mid+1
        v=lo; idx-=prefix_signed(rem,4-i,v-1) if v>-rem else 0
        ans.append(v);rem-=abs(v)
    assert idx==rem==0
    return tuple(ans)
def tri_start(t,C):return C*(2*t+1)-C*(C-1)//2
def rank_tri(t,A,C):
    assert 0<=C<=t and 0<=A<=2*t-C
    return tri_start(t,C)+A
def unrank_tri(t,v):
    assert 0<=v<R(t)
    lo,hi=0,t+1
    while lo+1<hi:
        mid=(lo+hi)//2
        if tri_start(t,mid)<=v:lo=mid
        else:hi=mid
    return v-tri_start(t,lo),lo
def B(n):return s_prefix(n,3,smax(n,3)+1) if n>=0 else 0

def base_rank(n,st):
    s,d,A,C=st
    assert n>=0 and 0<=s<=smax(n,3) and len(d)==5
    m=M(n,3,s);q=sum(abs(v) for v in d)
    assert m>=q and (m-q)%2==0
    t=(m-q)//2
    return s_prefix(n,3,s)+shell_prefix(m,t)+rank_vec(d)*R(t)+rank_tri(t,A,C)
def base_unrank(n,v):
    assert 0<=v<B(n)
    lo,hi=0,smax(n,3)+1
    while lo+1<hi:
        mid=(lo+hi)//2
        if s_prefix(n,3,mid)<=v:lo=mid
        else:hi=mid
    s=lo; m=M(n,3,s);v-=s_prefix(n,3,s)
    lo,hi=0,m//2+1
    while lo+1<hi:
        mid=(lo+hi)//2
        if shell_prefix(m,mid)<=v:lo=mid
        else:hi=mid
    t=lo;v-=shell_prefix(m,t);q=m-2*t
    d=unrank_vec(q,v//R(t));A,C=unrank_tri(t,v%R(t))
    return (s,d,A,C)

# Raw BRC f=(special count, five ordinary signed displacements, valuation A,C)
# gate w=aba; a=+E2, b=+E3; s>=2 requires r=s-1 prior gates.
def to_raw(st):
    s,d,A,C=st;r=max(s-1,0)
    y=list(d);y[0]+=2*r;y[1]+=r
    Lb=max(0,r-max(y[1],0))
    return (s,tuple(y),A+Lb,C)
def to_normal(raw):
    s,y,A,C=raw;r=max(s-1,0)
    d=list(y);d[0]-=2*r;d[1]-=r
    Lb=max(0,r-max(y[1],0))
    return (s,tuple(d),A-Lb,C)
def pad(raw, a=0,b=0):
    s,y,A,C=raw
    v=list(y);v[0]+=a;v[1]+=b
    return (s,tuple(v),A+min(b,max(-y[1],0)),C)
def unpad(raw,a=0,b=0):
    s,y,A,C=raw
    v=list(y);v[0]-=a;v[1]-=b
    return (s,tuple(v),A-min(b,max(-v[1],0)),C)
PADS={1:(1,0),2:(1,1),3:(2,1)}
def exceptions(n):
    Z=(0,0,0,0,0)
    def raw(s,na,nb):return (s,(na,nb,0,0,0),0,0)
    if n==0:return []
    if n==1:return [raw(0,1,0)]
    E=[raw(0,n,0),raw(0,n-1,1),raw(1,n-1,0)]
    if n==3:E.append(raw(1,1,1))
    return E
def removed_indices(n):
    return sorted(base_rank(n,to_normal(f)) for f in exceptions(n))
def Q0(n):return B(n)-len(exceptions(n))
def F(n):return Q0(n)+sum(B(n-j) for j in (1,2,3))
def offset(n,q):
    assert q in range(4)
    return Q0(n)+sum(B(n-j) for j in range(1,q)) if q else 0

def rank_joint(n, raw,q):
    assert q in range(4) and n>=0
    if q==0:
        rank0=base_rank(n,to_normal(raw));holes=removed_indices(n)
        assert rank0 not in holes, (n,raw,q)
        return rank0-sum(h<rank0 for h in holes)
    a,b=PADS[q]
    r=base_rank(n-q,to_normal(unpad(raw,a,b)))
    assert pad(to_raw(base_unrank(n-q,r)),a,b)==raw
    return offset(n,q)+r

def unrank_joint(n,index):
    assert 0<=index<F(n)
    if index<Q0(n):
        holes=removed_indices(n);v=index
        for h in holes:
            if h<=v:v+=1
        assert v not in holes
        return to_raw(base_unrank(n,v)),0
    for q in (1,2,3):
        lo=offset(n,q);hi=lo+B(n-q)
        if lo<=index<hi:
            a,b=PADS[q]
            return pad(to_raw(base_unrank(n-q,index-lo)),a,b),q
    assert False

def csize(n,H):
    if H<=0:return B(n)
    if H==1:return B(n)+B(n-3)
    if H==2:return B(n)+B(n-2)+B(n-3)
    return F(n)
def qclass(q,H):
    if H<=0:return 0
    if H==1:return 1 if q==3 else 0
    if H==2:return 2 if q==3 else (1 if q==2 else 0)
    return q

def rank_horizon(n,raw,q,H):
    assert H>=0
    z=qclass(q,H)
    if H==0 or (H<=2 and z==0):return base_rank(n,to_normal(raw))
    if H==1:return B(n)+base_rank(n-3,to_normal(unpad(raw,*PADS[3])))
    if H==2:
        assert z in (1,2)
        qsource=2 if z==1 else 3
        off=B(n)+(B(n-2) if z==2 else 0)
        return off+base_rank(n-qsource,to_normal(unpad(raw,*PADS[qsource])))
    return rank_joint(n,raw,q)
def unrank_horizon(n,v,H):
    assert 0<=v<csize(n,H)
    if H==0 or (H<=2 and v<B(n)):
        return to_raw(base_unrank(n,v)),0
    if H==1:return pad(to_raw(base_unrank(n-3,v-B(n))),*PADS[3]),1
    if H==2:
        k=v-B(n)
        if k<B(n-2):return pad(to_raw(base_unrank(n-2,k)),*PADS[2]),1
        return pad(to_raw(base_unrank(n-3,k-B(n-2))),*PADS[3]),2
    raw,q=unrank_joint(n,v)
    return raw,q

# Independent state DP; transitions are from exact f+q, not inverse padding or rank formulas.
AA=(0,1,0,2,1);CC=(0,0,1,0,1)
# KMP q transition for w=aba with letters a,b,other.
TRANS=((1,0,0),(1,2,0),(3,0,0),(1,2,0))
def next_state(raw,q,letter):
    s,y,A,C=raw
    if letter=='x':
        if q!=3:return None
        return ((s+1,y,A,C),0)
    i,sgn=letter
    Y=list(y); delta=(sgn<0 and Y[i]>0) or (sgn>0 and Y[i]<0)
    Y[i]+=sgn
    typ=0 if (i,sgn)==(0,1) else 1 if (i,sgn)==(1,1) else 2
    return ((s,tuple(Y),A+AA[i]*int(delta),C+CC[i]*int(delta)), TRANS[q][typ])
LETTERS=[(i,sgn) for i in range(5) for sgn in (+1,-1)]
START=(0,(0,0,0,0,0),0,0)
def next_dp(cur,n):
    z=defaultdict(int)
    for (raw,q),multiplicity in cur.items():
        for d in LETTERS:
            dest=next_state(raw,q,d)
            z[dest]+=multiplicity
        if q==3:
            dest=next_state(raw,q,'x');z[dest]+=multiplicity
        # Initial x permitted only at empty path
        if n==0:z[((1,raw[1],raw[2],raw[3]),0)]+=multiplicity
    return dict(z)

def direct_words(n):
    """Independent word DFS, no dynamic-programming aggregation."""
    hist=defaultdict(int)
    def rec(raw,q,depth):
        if depth==n:hist[(raw,q)]+=1;return
        for d in LETTERS:
            nxt=next_state(raw,q,d);rec(*nxt,depth+1)
        if depth==0:rec((1,raw[1],raw[2],raw[3]),0,depth+1)
        elif q==3:rec(*next_state(raw,q,'x'),depth+1)
    rec(START,0,0)
    return dict(hist)

def test():
    cur={(START,0):1}
    total=0
    for n in range(0,6):
        states=set(cur); fkeys={raw for raw,q in states}
        qstates=[{raw for raw,q in states if q==j} for j in range(4)]
        assert len(fkeys)==B(n),(n,len(fkeys),B(n))
        assert len(states)==F(n),(n,len(states),F(n))
        assert len(qstates[0])==Q0(n)
        for j in (1,2,3):
            assert len(qstates[j])==B(n-j)
            assert qstates[j]=={pad(to_raw(base_unrank(n-j,k)),*PADS[j]) for k in range(B(n-j))}
        assert fkeys-qstates[0]==set(exceptions(n)),(n,fkeys-qstates[0],set(exceptions(n)))
        ranks=set()
        for raw,q in states:
            assert to_raw(to_normal(raw))==raw
            k=rank_joint(n,raw,q)
            assert unrank_joint(n,k)==(raw,q)
            ranks.add(k)
        assert len(ranks)==F(n) and min(ranks)==0 and max(ranks)==F(n)-1
        for h in range(4):
            classes={(raw,qclass(q,h)) for raw,q in states}
            assert len(classes)==csize(n,h),(n,h,len(classes),csize(n,h))
            indices={rank_horizon(n,raw,q,h) for raw,q in states}
            assert len(indices)==csize(n,h) and min(indices)==0 and max(indices)==csize(n,h)-1
            for idx in indices:
                rr,cl=unrank_horizon(n,idx,h)
                assert rank_horizon(n,rr,[0,3][cl] if h==1 and cl==1 else ([0,2,3][cl] if h==2 else cl),h)==idx
        if n<=4: assert cur==direct_words(n), (n,'word count mismatch')
        print(f'n={n} B={B(n)} Q={tuple(len(qs) for qs in qstates)} F={F(n)} H={tuple(csize(n,h) for h in range(4))} total_paths={sum(cur.values())} PASS')
        total+=len(states)
        if n<5:cur=next_dp(cur,n)
    for n in (16,64,1024,10**9):
        for h in range(4):
            cnt=csize(n,h)
            for idx in sorted(set([0,1,cnt//3,cnt//2,cnt-2,cnt-1])):
                rr,cl=unrank_horizon(n,idx,h)
                q=cl if h>=3 else (0 if cl==0 else (3 if h==1 else cl+1))
                assert rank_horizon(n,rr,q,h)==idx
        print(f'large_n={n} B_bits={B(n).bit_length()} F_bits={F(n).bit_length()} EXACT_ROUNDTRIP_PASS')
    print(f'EXHAUSTIVE_JOINT_STATES_CHECKED={total}')
    print('ALL_CHECKS_PASS')

if __name__=='__main__': test()
