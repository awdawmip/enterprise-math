# EC49FRF — Twelve new unrestricted BRC seams, 110-node enclosure, and exact multi-budget grid allocation theorem

**Research date:** 2026-11-17. **Status:** `AUTHOR_PROVED / EXACT_FINITE_CHECKED / NOT_REVIEWED`.
**Parent verified author-side science:** EC49FRE, GitHub PR #2607, commit `e2f8e0c5f1ac33773ac4a5f714ba22ccb4da9ce9`; pinned original scientific source `fc0f038e7bfd12c886b4d37f900bfb770c0f61ab` unchanged. The parent self-contained evidence archive is included in this bundle. Current P000 / ACTIVE worldview and portable research rule were read independently and are not overwritten.

## Exact model and preserved observations

The native BRC class 16943 has 310 original configurations, 141 distinct **complete named** cost profiles, 228 physically labeled legal observations (144 terminal and 84 root), and 209 distinct response partitions. No named physical action is erased from reported first-query ties. The strictly positive prior at profile i is

`p_i(lambda)=(1-lambda)/141 + lambda*m_i/310`, `0<=lambda<=1`, `sum_i m_i=310`.

Normalize terminal price `t>0`; root price is `r=xt` with `x>=1`. `V(x,lambda)` minimizes the weighted cost over **all finite separating adaptive decision trees** using these 228 legal physical observations. The three *feasible* candidate BRC trees have normalized costs

- `A=(1-lambda)(6x+290)/141 + lambda(6x+751)/310`
- `B=(1-lambda)(5x+293)/141 + lambda(5x+704)/310`
- `C=(1-lambda)(5x+295)/141 + lambda(5x+685)/310`.

Set `K(x)=7557-169x`, `G(x)=310(3-x)/K(x)`, `beta=620/3299`, and `D=2185500`.

## Theorem 1 — 12 exact continuous-prior price seams

At each price listed below and every **real** `lambda in [0,1]`, the unrestricted finite Bellman value equals `t*min(A,B,C)`, provided the inherited EC49FRD/EC49FRE endpoint certificates and the exact named-first-action exclusion lemma hold as stated. The optimal named first actions are `(32, 34)` below `G(x)`, `(140, 142)` between `G(x)` and `beta`, and `(16, 23)` above `beta`; at the respective endpoints, retain the unions of adjacent sets. All 12 first seams satisfy `0<G(x)<beta<1`.

| Root/terminal price x | First seam lambda=G(x) | Exact integer-weight Bellman minimum | Certificate SHA256 | Unrestricted subset cache |
|---|---|---:|---|---:|
| `107/64` | `5270/93113` | 559,087,966,080 | `2c2c580d13214d11fdff83f26fbadc19830a1835ff4cc0fce770ae08d218bb8f` | 6041 |
| `109/64` | `25730/465227` | 2,794,539,054,720 | `cc66174da6f139f7208db7b8aca5194112673916f62fbacdef1dbb08d41c2eee` | 6041 |
| `111/64` | `8370/154963` | 931,212,759,680 | `ddfa8ae306781113b90556e8ec5c14eecc79b10ef93daf06d73fcfce51100e1c` | 6041 |
| `113/64` | `24490/464551` | 2,792,737,503,360 | `9fb5893bb81228ed1d4d907d5f0252f8e242fc9a6ca53c487dbb10e885955d6d` | 6041 |
| `115/64` | `23870/464213` | 2,791,836,727,680 | `b46812560a6502fd1078c04ff77934b88095ed1ba058943971f190fff1f90e5d` | 6041 |
| `117/64` | `62/1237` | 7,442,495,872 | `242a858e9bee5e65256b1ace148715efd3706156677d2973868cba4fd09c5d9d` | 6041 |
| `119/64` | `22630/463537` | 2,790,035,176,320 | `8622c4823a4cb9d896e43f547200405684bf53815d08c1bcfd28de471cda8e7e` | 6041 |
| `121/64` | `22010/463199` | 2,789,134,400,640 | `5ec07a492a32c8dd6ff1df13e4f43ad59d88234621ebe8e3a652b4bca960527c` | 6041 |
| `123/64` | `230/4977` | 29,981,006,720 | `a8d998ae79ab49a023a7ce2b4f2ac8a9905d262c40ebb65002d878c1b84278e4` | 6041 |
| `125/64` | `20770/462523` | 2,787,332,849,280 | `1796eb736aebb45040dc49f6a70cf09b3ac195a6105eb8e8099dc8a1413d120f` | 6042 |
| `127/64` | `4030/92437` | 557,286,414,720 | `72d3e98d3004e0ae832f5a1d1c775195096e6231889b3eecd5d85f6e4a851e52` | 6042 |
| `129/64` | `6510/153949` | 928,510,432,640 | `103a5d14d99bf0fbcce25b1f6d074be6bcef5273e2725a89f9ededc38a4a4e5c` | 6052 |

**Proof with explicit dependencies.** Source loader reconstructs all 310 original objects, groups only complete identical named cost profiles, and retains all 228 physical actions. At each critical rational `(x,G(x))`, the exact integer Bellman recursion visits every reachable strictly decreasing non-singleton response fiber: positive query costs exclude nonsplitting loops from an optimum. The recursion's unrestricted optimum and the exact finite tie set `(32, 34, 140, 142)` agree with a *different* weighted subset dynamic-programming implementation; its 12 independent pass logs and full certificates are present. This proves the exact discrete assertion at each new first seam. At each fixed x, costs of each fixed decision tree are affine in lambda, so the optimal value is their lower envelope, hence concave. An affine candidate that touches the optimum at both ends of a lambda interval equals it throughout that interval. Reusing the *actual* neighboring endpoint and beta certificates with the inherited first-action exclusion lemma gives all-real-prior cost and named-first-action classification. End of proof (dependency status `AUTHOR_PROVED / EXACT_FINITE_CHECKED / NOT_REVIEWED`).

All integer minimums in the table are weighted accumulators scaled by `64*310*141*denominator(G(x))`, not costs divided by t. Full native result JSONs include all candidate first-action costs and full tied trees; the independent checker separately enumerates all 228 physically labeled first actions and replays each tied tree.

## Theorem 2 — globally optimal allocation of a finite sampling budget over any fixed price intervals

**This is an analytic theorem about certified-interval geometry, with no new BRC physical operation.** Let a finite set of already certified prices `1<=p_0<...<p_M<=3` be fixed. Each original gap `I_j=[a_j,b_j]` has `L_j=log(K(a_j)/K(b_j))>0`. For any nonnegative integer budget `m` of additional *real-valued* price nodes, choose integers `n_j>=1` such that `sum_j(n_j-1)=m` and place `n_j-1` nodes in `I_j`.

For fixed `n_j`, the **unique** simultaneous minimizer of the interval strip-area upper bound and the interval maximum-regret upper bound is the grid uniform in log K:

`K(x_(j,k)) = K(a_j)^(1-k/n_j) * K(b_j)^(k/n_j)`, `k=0,...,n_j`.

The optimal interval contributions are exactly

`F_j(n) = (2D/169^2)*n*(cosh(L_j/n)-1)` (enclosed strip area),

`Q_j(n) = (50/169)*tanh(L_j/(4n))` (max normalized regret bound).

For **global area minimization at a fixed budget**, allocate successive extra nodes to an interval maximizing its current marginal area reduction `Delta_j(n)=F_j(n)-F_j(n+1)`, re-spacing that interval to the equal-log-K grid whenever its `n` changes. This greedy allocation is globally optimal for every finite `m`.

For **global minimax regret at a fixed budget**, allocate successive extra nodes to an interval maximizing `L_j/n_j`, again re-spacing it to equal-log-K. This greedy allocation is globally optimal. Equivalently, define

`h_m = min { h>0 : sum_j (max(1,ceil(L_j/h))-1) <= m }`.

The best possible maximal normalized regret enclosure is `(50/169)*tanh(h_m/4)`.

**Proof.** For one gap and positive log-increments `y_1,...,y_n` summing to L, the area identity is `(2D/169^2)*sum_k(cosh(y_k)-1)`. Strict convexity of cosh and Jensen establish the unique equal increments for minimum area; monotonicity of tanh shows equal increments uniquely minimize the maximal interval regret bound. The function `F_j(n)` for real `n>0` satisfies

`F_j'(n)=(2D/169^2)*(cosh(L_j/n)-1-(L_j/n)*sinh(L_j/n)) <0`,

`F_j''(n)=(2D/169^2)*(L_j^2/n^3)*cosh(L_j/n)>0`.

Therefore the discrete marginal `Delta_j(n)` is positive and strictly decreases with n. Choosing the m largest currently accessible marginals yields the exact optimum: if another allocation has lower area, exchanging its smallest allocated marginal for a larger available marginal strictly improves it, contradiction. For minimax, a target maximum log-step `h` is feasible exactly when at least `max(1,ceil(L_j/h))` intervals are allocated to every j, requiring `sum_j(max(1,ceil(L_j/h))-1)<=m`. Raising the currently largest `L_j/n_j` until budget exhaustion meets this threshold optimally, since below any target h the greedy algorithm never spends a node on an interval already satisfying that threshold while an unsatisfied interval remains. These characterize the two global optimization problems without assuming their optimal integer allocations always coincide. QED.

This extends the inherited EC49FRD theorem, which optimized the locations of a **fixed number of nodes inside one gap**, to **arbitrary competing gaps and a shared finite sampling budget**. All analytic cosh/tanh/log functions describe parameter-grid geometry only; the underlying 228 BRC physical sensing actions retain their native discrete semantics.

## Theorem 3 — exact 12-budget allocation at the inherited 98-node frontier and the certified 110-node enclosure

For the inherited EC49FRE 98 price nodes, the unique 12 largest gaps in `L_j` are the 12 consecutive intervals from `53/32` through `65/32`, all of width `1/32`. Furthermore, half the log-length of each of these gaps is strictly less than the 13th-largest original log-length. Consequently, Theorem 2's minimax allocator puts **one additional node in each** and none in the other 85 gaps. This allocation is globally minimax-optimal among all allocations of 12 real nodes. The 12 new rational BRC-certified nodes at their arithmetic midpoints are

`107/64,109/64,111/64,113/64,115/64,117/64,119/64,121/64,123/64,125/64,127/64,129/64`.

The fact that precisely these 12 gaps are selected is checked with *exact rational comparisons* of `K(a)/K(b)` (log monotonicity); the half-gap separation is checked with exact rational squares, requiring no numerical logarithm. Because arithmetic midpoints are generally not exactly equal-log-K midpoints, the **allocation** is globally minimax-optimal, while the **chosen rational locations** are verified feasible close approximations, not asserted to be the unique continuous optimum grid.

With `P110=P98 union {these 12 prices}`, the 110-node exact results are

- `S98=296902200973874060795/160864097511408031554912`;
- `S110=259924479610030238135/162277343928838082317536`;
- **exact reduction** `S98-S110=13113000/53754785413 >0`;
- certified area lower bound for `[1,3] x [0,1]`: `1-S110/2=324294763378066134396937/324554687857676164635072`, i.e. **99.9199135032%**;
- **unique maximal interval upper bound:** `[13/8,53/32]`;
- old and new sharp envelope readouts: `0.00005413048225249587545103954322059877053944425296941217359230656135886680` and `0.00005365923984683695430332158676245061390191919763029475810674278089176280` times t, respectively.

For every `x>=1`, `0<=lambda<=1`, the inherited certificate outside `[1,3]` combined with new 109 within-range enclosures gives

`0 <= t*min(A,B,C) - V(x,lambda) <= t * [50*(53/32-13/8)/(sqrt(K(13/8))+sqrt(K(53/32)))^2]`,

whose upper bound is **< 0.0000536592398468370 t** (outward rounding). The 110-node proof uses exact rational strip identities, and integer-square-root rational *outward* enclosures of all 109 radical bounds at absolute square-root precision `10^-40`. It proves the reported maximum is unique without relying on decimal rankings.

**Geometric proof.** For any adjacent certified prices `a<b`, prior endpoint concavity and affine candidate feasibility establish `min(A,B,C)=V` outside the enclosed crossover strip `G(b)<lambda<G(a)`; thus the gap's uncertified area is at most `(b-a)(G(a)-G(b))`. Direct substitution gives `D(b-a)^2/(K(a)K(b))`. Summing exactly across 109 intervals yields S110 above. The inherited cross-price regret interpolation bound is `50(b-a)/(sqrt(K(a))+sqrt(K(b)))^2`; exact outward brackets identify its maximum. QED (retaining inherited interval-lemma assumptions).

## Evidence, reproduction and boundaries

Full raw source hashes: `frozen_original_master.txt` SHA256 `cd9a50799536d2b96230777b5392b1d742ceee896da05bb49aa097cf351e1d5e` and `EC49FPG_PROFILE.csv` SHA256 `a61a3ee4d2f13f9d216f52cd3529c72d395c1250bfb1d7ae96a1adf5a6837c1f`. All source bytes and the exact native and independent DP scripts are included in the evidence bundle. Reproduce with

```text
python EC49FRF_GEOMETRY.py
PYTHONPATH=code python code/EC49FRC_INDEPENDENT_VERIFY.py 0 4
PYTHONPATH=code python code/EC49FRC_INDEPENDENT_VERIFY.py 4 8
PYTHONPATH=code python code/EC49FRC_INDEPENDENT_VERIFY.py 8 12
```

The new 12 full Bellman JSON certificates, all native execution logs, three independent checks (each checking all 228 candidate first actions), exact geometric script/result and full inherited EC49FRE evidence are bundled; full per-file SHA256/size manifest accompanies them. Recalculation is exact integer / rational throughout the proof-bearing discrete claims and interval rankings; decimals are report readouts. The new 12 seam proofs are conditional on accurately inherited endpoint/named-action lemmas, not separate project review. Claim status `AUTHOR_PROVED / EXACT_FINITE_CHECKED / NOT_REVIEWED`.

Formal topic `RS-EC49AS` lacks an immutable publication directory as of GitHub `main` snapshot observed on 2026-11-17, so this is independent portable research, **not** a new formal CLAIM, PROGRESS, Result, Review or Foundation promotion; no existing owner was displaced. Researcher identity is the current independent author session, not a purported reuse of historic researcher credentials.

**Next genuine scientific objective:** Build a parameterized Bellman lower-bound certificate for all remaining 109 strips (not another mere upper enclosure), or construct a single exact action-labeled adaptive decision tree with expected cost strictly less than `t*min(A,B,C)` in one strip. The current maximal upper-bound interval `[13/8,53/32]` is a specific high-information test target; a refined grid alone will not discharge the remaining universal conjecture.
