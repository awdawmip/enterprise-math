# EC49FRF — self-contained exact native BRC evidence, 110-node continuation

2026-11-17. Parent EC49FRE verified commit `e2f8e0c5f1ac33773ac4a5f714ba22ccb4da9ce9`, scientific pin `fc0f038e7bfd12c886b4d37f900bfb770c0f61ab`. Full proof and domain in `EC49FRF_THEOREM.md`.

This directory includes raw original frozen master and CSV, 12 new full Bellman certificates, original native solver, independently written full weighted-subset Bellman implementation and replay, 12 native logs, three independent batch logs/results, `EC49FRF_GEOMETRY.py`, exact rational area/regret results, immutable inherited EC49FRE self-contained evidence archive, and byte SHA256/size manifest.

Run `python EC49FRF_GEOMETRY.py`, then `PYTHONPATH=code python code/EC49FRC_INDEPENDENT_VERIFY.py 0 4`, `4 8`, `8 12` to independently recheck the original 12 native claims and all tie-tree replays. Each re-execution covers all 141 distinct named profiles, 228 physical actions, all reachable recursive Bellman states at that price and prior. The inherited scientific dependency can be inspected through `INHERITED_EC49FRE_FULL_EVIDENCE_20261117.tar.xz`.

This is author-proved exact finite work with no independent project review or formal Task CLAIM. Scientific scope is one native BRC sensing class, not X6 physical-dynamics validation. No plaintext credentials or secrets are included.
