#!/usr/bin/env python3
"""Exact parameter geometry and 12-budget minimax allocation, using inherited 98 price nodes.
Strict interval ranking uses rational comparison of K(a)/K(b); radical regret via isqrt outward enclosure.
No external data or network required.
"""
from fractions import Fraction as Q
from math import isqrt
from decimal import Decimal,localcontext
from pathlib import Path
import json
BASE=Path(__file__).resolve().parent
old71=sorted(set(map(Q,json.loads((BASE/'old71.json').read_text()))))
old12=[Q(x['x']) for x in json.loads((BASE/'prior12seams.json').read_text())]
old3=[Q(x['x']) for x in json.loads((BASE/'prior3seams.json').read_text())]
old12b=[Q(x['x']) for x in json.loads((BASE/'prior12_64seams.json').read_text())]
new12=[Q(x['x']) for x in json.loads((BASE/'seams.json').read_text())]
old=sorted(set(old71+old12+old3+old12b));new=sorted(set(old+new12))
assert len(old)==98 and len(new)==110 and len(new12)==12
assert old[0]==new[0]==1 and old[-1]==new[-1]==3
assert not set(new12)&set(old)
K=lambda x:Q(7557)-169*x
G=lambda x:310*(3-x)/K(x)
D=Q(2185500)
assert all(K(x)>0 for x in new)
assert all(Q(v['lambda'])==G(Q(v['x'])) for v in json.loads((BASE/'seams.json').read_text()))
def area(nodes):return sum((b-a)*(G(a)-G(b)) for a,b in zip(nodes,nodes[1:]))
def area2(nodes):return D/Q(169**2)*sum(K(a)/K(b)+K(b)/K(a)-2 for a,b in zip(nodes,nodes[1:]))
for nodes in (old,new):assert area(nodes)==area2(nodes)
S98,S110=area(old),area(new)
assert S98==Q(296902200973874060795,160864097511408031554912)
assert S110<S98
# Exact proof that the 12 chosen original intervals are the 12 largest normalized log-K intervals;
# splitting them once keeps every half-gap below each of the remaining unsplit gaps.
edges=list(zip(old,old[1:]))
ratios=[K(a)/K(b) for a,b in edges]
sorted_indices=sorted(range(len(edges)),key=lambda j:ratios[j],reverse=True)
selected=sorted_indices[:12]
selection_expected=[j for j,(a,b) in enumerate(edges) if Q((a+b)/2) in new12]
assert sorted(selected)==selection_expected
assert ratios[sorted_indices[11]]>ratios[sorted_indices[12]]
# If sqrt(r) < s, then r < s^2; this guarantees no top interval receives a second node before all 12 are split.
assert all(ratios[j]<ratios[sorted_indices[12]]**2 for j in selected)
# For fixed budget 12, any solution targeting max L/n <= max remaining interval requires each of the largest 12
# intervals to have n>=2, exhausting budget. This certifies exact allocation optimality.
# Exact ranking of 109 regret bound intervals with 10^-40 enclosing sqrt.
SCALE=10**40
def sqrtrange(z):
 q=isqrt((z.numerator*SCALE*SCALE)//z.denominator)
 lo,hi=Q(q,SCALE),Q(q+1,SCALE)
 assert lo**2<=z<hi**2
 return lo,hi
def rb(a,b):
 al,au=sqrtrange(K(a)); bl,bu=sqrtrange(K(b));
 return Q(50)*(b-a)/(au+bu)**2,Q(50)*(b-a)/(al+bl)**2
rows=[(a,b,*rb(a,b)) for a,b in zip(new,new[1:])]
prev=[(a,b,*rb(a,b)) for a,b in zip(old,old[1:])]
leader=max(rows,key=lambda x:x[2]);oldlead=max(prev,key=lambda x:x[2]);
assert all(leader[2]>z[3] for z in rows if z!=leader)
assert all(oldlead[2]>z[3] for z in prev if z!=oldlead)
assert leader[3]<oldlead[2]
with localcontext() as cx:
 cx.prec=70
 def dec(q):return Decimal(q.numerator)/Decimal(q.denominator)
 def regret(a,b):return 50*dec(b-a)/(dec(K(a)).sqrt()+dec(K(b)).sqrt())**2
 result={
  'schema':'EC49FRF_110_NODE_12_BUDGET_MINIMAX_GEOMETRY_V1',
  'parent': 'EC49FRE_98_NODE', 'frozen_scientific_commit':'fc0f038e7bfd12c886b4d37f900bfb770c0f61ab',
  'new_prices':[str(x) for x in new12],
  'price_nodes':len(new),'price_intervals':len(rows),
  'S98':str(S98),'S110':str(S110),'strip_area_reduction':str(S98-S110),
  'certified_area_fraction_lower_bound':str(1-S110/2),
  'certified_percent_lower_bound':str(100*(1-S110/2)),
  'old_worst':[str(oldlead[0]),str(oldlead[1])],
  'new_worst':[str(leader[0]),str(leader[1])],
  'prior_max_regret_over_t':str(regret(oldlead[0],oldlead[1])),
  'new_max_regret_over_t':str(regret(leader[0],leader[1])),
  'max_regret_lower_rational':str(leader[2]),
  'max_regret_upper_rational':str(leader[3]),
  'selected_original_intervals': [[str(edges[j][0]),str(edges[j][1])] for j in selected],
  'top_twelve_log_interval_ranking_exact': True,
  'one_split_each_discrete_minimax_allocation_exact': True,
  'geometric_lagrange_spacings_of_rational_nodes_not_exactly_equal':True,
  'math_status':'AUTHOR_PROVED / EXACT_RATIONAL_AND_INTERVAL_VERIFIED / NOT_REVIEWED'
 }
 (BASE/'EC49FRF_GEOMETRY_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False,indent=2))
 print('EC49FRF_110_NODE_MINIMAX_ALLOCATION_GEOMETRY_VERIFIED')
