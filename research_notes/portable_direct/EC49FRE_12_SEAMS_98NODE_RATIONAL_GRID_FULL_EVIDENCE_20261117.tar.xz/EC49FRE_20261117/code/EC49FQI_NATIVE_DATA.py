#!/usr/bin/env python3
"""Exact BRC class-16943 first-query palette / isolated-tie / re-entry audit.

Usage: python EC49FQG_PALETTE_VERIFY.py EC49FQF_EVIDENCE [output.json]
The 25 inherited Bellman endpoint certificates are audited, not regenerated.
This program independently rebuilds original BRC observations from frozen inputs,
verifies all 54 saved decision trees by profile replay, checks physical-index aliases,
and derives universal first-action sets through an elementary affine-envelope lemma.
"""
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
import csv, hashlib, itertools, json, sys

BASE = Path(__file__).resolve().parent.parent
src=BASE/'source'
PIN='fc0f038e7bfd12c886b4d37f900bfb770c0f61ab'
MASTER='cd9a50799536d2b96230777b5392b1d742ceee896da05bb49aa097cf351e1d5e'
CSV='a61a3ee4d2f13f9d216f52cd3529c72d395c1250bfb1d7ae96a1adf5a6837c1f'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
master=src/'frozen_original_master.txt'; csvfile=src/'EC49FPG_PROFILE.csv'
assert sha(master)==MASTER and sha(csvfile)==CSV
roots=(3,5,6,7)
with master.open() as f:
    nfamilies,nweights,nconfigs=map(int,f.readline().split())
    assert (nfamilies,nweights,nconfigs)==(94,178850,38169)
    fam=[]
    for _ in range(nfamilies):
        x=[0]*4
        for j in range(int(f.readline())):
            l,w=f.readline().split()
            x[roots.index(bytes.fromhex(w)[0])] |= 1<<int(l)
        fam.append(x)
    configurations=[tuple(map(int,f.readline().split())) for _ in range(nconfigs)]
def domain(config):
    v=[0]*24
    for famid in config:
        for k,mask0 in enumerate(fam[famid]):
            mask=mask0
            while mask:
                p=mask&-mask;v[p.bit_length()-1] |= 1<<k;mask^=p
    return tuple(v)
target=domain(configurations[16943]);ids=[i for i,c in enumerate(configurations) if domain(c)==target]
assert len(ids)==310
opts=[l for l in range(24) if target[l].bit_count()>1]
alloc=list(itertools.product(*(tuple(r for j,r in enumerate(roots) if target[l]>>j&1) for l in opts)))
assert len(alloc)==144
root_subsets={}
for j,r in enumerate(roots):
    ls=[l for l in opts if target[l]>>j&1]
    root_subsets[r]=sorted(sum(1<<l for l,b in zip(ls,bits) if b)
                           for bits in itertools.product((0,1),repeat=len(ls)))
keys=[(r,s) for r in roots for s in root_subsets[r]]
assert len(keys)==84
C=defaultdict(dict);idset=set(ids)
with csvfile.open() as f:
    for row in csv.DictReader(f):
        cid=int(row['config'])
        if cid in idset:
            key=(int(row['root']),int(row['subset']))
            assert key not in C[cid]
            C[cid][key]=int(row['cost'])
assert len(C)==310 and all(len(C[cid])==84 for cid in ids)
profiles={};reps=[];weights=[]
for cid in ids:
    profile=tuple(C[cid][key] for key in keys)
    if profile not in profiles:
        profiles[profile]=len(profiles);reps.append(cid);weights.append(0)
    weights[profiles[profile]]+=1
assert len(reps)==141 and sum(weights)==310
T=[]
for assignment in alloc:
    mask={r:0 for r in roots}
    for l,r in zip(opts,assignment):mask[r] |= 1<<l
    T.append(tuple(sum(C[cid][r,mask[r]] for r in roots) for cid in reps))
R=[tuple(C[cid][key] for cid in reps) for key in keys]
V=T+R
assert len(V)==228
alias=defaultdict(list)
for q,v in enumerate(V):
    fiber=defaultdict(list)
    for i,value in enumerate(v):fiber[value].append(i)
    signature=tuple(sorted(tuple(members) for members in fiber.values()))
    alias[signature].append(q)
assert len(alias)==209
assert all(all(q<144 for q in qs) or all(q>=144 for q in qs) for qs in alias.values())
alias_by_q={q:tuple(group) for group in alias.values() for q in group}


# Independent exact replay of a candidate tree against the native 141-state / 310-config data.
def cost_pair(tree):
    uR=uT=mR=mT=0
    for i in range(len(reps)):
        n=tree; seen=set()
        while 'leaf' not in n:
            q=n['q'];assert isinstance(q,int) and 0<=q<len(V) and q not in seen
            seen.add(q)
            if q<144: uT+=1;mT+=weights[i]
            else: uR+=1;mR+=weights[i]
            n=n['children'][str(V[q][i])]
        assert n['leaf']==i
    return {'U_R':uR,'U_T':uT,'M_R':mR,'M_T':mT,'U_total':uR+uT,'M_total':mR+mT}

