# EC49FRE — full native, auditable scientific evidence

New result: 12 exact class-16943 BRC first-seam certificates at odd-numerator `/64` prices from `131/64` to `153/64` inclusive; a 98-price-node rational area/regret certificate; and a new rational-rounding robustness theorem for the jointly optimal ideal K-grid. All mathematical claims and inherited dependencies are stated in `EC49FRE_THEOREM.md`.

Frozen scientific commit: `fc0f038e7bfd12c886b4d37f900bfb770c0f61ab`. This bundle includes its original BRC master and profile data, the two distinct exact integer Bellman implementations, all 12 complete machine certificates (not just indexes), original native logs, independent replica checks in batches `[0,6)`, `[6,9)`, `[9,12)`, and exact 98-node geometric verifier. The companion immutable `INHERITED_EC49FRD_FULL_EVIDENCE_20261117.tar.gz` contains all inherited EC49FRD science, including the nested preceding 83-node archive.

From this folder run:

```
python EC49FRE_GEOMETRY.py
PYTHONPATH=code python code/EC49FRC_INDEPENDENT_VERIFY.py 0 6
PYTHONPATH=code python code/EC49FRC_INDEPENDENT_VERIFY.py 6 9
PYTHONPATH=code python code/EC49FRC_INDEPENDENT_VERIFY.py 9 12
```

Each independent replay verifies exactly all 228 labeled first-action possibilities, the full unrestricted weighted integer Bellman optimum and each tied first-observation decision tree. `MANIFEST_SHA256.json` checks file hashes, sizes, and the exact source. `EC49FRE_GEOMETRY.py` uses `Fraction` and outward `isqrt` brackets for the radical maximum, not floating-point ordering.

All current scientific proof and computation are author-side `NOT_REVIEWED` and have no formal Task CLAIM/Result. The scientific source pin is unchanged; `RS-EC49AS` is a non-published formal task according to the original native continuation result.
