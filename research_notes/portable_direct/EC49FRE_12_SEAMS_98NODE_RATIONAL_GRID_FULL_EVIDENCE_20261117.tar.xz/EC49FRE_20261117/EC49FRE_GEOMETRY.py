#!/usr/bin/env python3
"""EC49FRE: exact 98-node BRC-class-16943 grid geometry and regret order.
This verifies geometric interpolation of the inherited fully certified price seams,
not the raw Bellman certificates (verified separately by independent native DP).
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal, localcontext
from math import isqrt
import json
BASE=Path(__file__).resolve().parent
old71=sorted(set(map(F,json.loads((BASE/'old71.json').read_text()))))
old12=[F(v['x']) for v in json.loads((BASE/'prior12seams.json').read_text())]
old3=[F(v['x']) for v in json.loads((BASE/'prior3seams.json').read_text())]
add=[F(v['x']) for v in json.loads((BASE/'seams.json').read_text())]
old=sorted(set(old71)|set(old12)|set(old3)); new=sorted(set(old)|set(add))
assert len(old71)==71 and len(old)==86 and len(new)==98 and len(add)==12
assert new[0]==old[0]==1 and new[-1]==old[-1]==3
assert len(new)==len(old)+len(add)
K=lambda x:F(7557)-169*x
G=lambda x:310*(3-x)/K(x)
D=F(2185500)
assert all(K(x)>0 for x in new)
assert all(F(v['lambda'])==G(F(v['x'])) for v in json.loads((BASE/'seams.json').read_text()))
def area(nodes):
 return sum(((b-a)*(G(a)-G(b)) for a,b in zip(nodes,nodes[1:])),F(0))
def area_formula(nodes):
 return D/F(169**2)*sum((K(a)/K(b)+K(b)/K(a)-2 for a,b in zip(nodes,nodes[1:])),F(0))
for n in (old,new): assert area(n)==area_formula(n)
S86,S98=area(old),area(new)
assert S86==F(10770320075410254305,5143575841741225186848)
assert S98<S86
scale=10**40
def sqrtrange(z):
 q=isqrt(z.numerator*scale**2//z.denominator)
 lo,hi=F(q,scale),F(q+1,scale)
 assert lo*lo<=z<hi*hi
 return lo,hi
def rr(a,b):
 al,au=sqrtrange(K(a));bl,bu=sqrtrange(K(b))
 return F(50)*(b-a)/(au+bu)**2,F(50)*(b-a)/(al+bl)**2
old_rows=[(a,b,*rr(a,b)) for a,b in zip(old,old[1:])]
rows=[(a,b,*rr(a,b)) for a,b in zip(new,new[1:])]
oldlead=max(old_rows,key=lambda z:z[2]);lead=max(rows,key=lambda z:z[2])
assert all(lead[2]>z[3] for z in rows if z is not lead)
assert all(oldlead[2]>z[3] for z in old_rows if z is not oldlead)
assert lead[3]<oldlead[2]
with localcontext() as ctx:
 ctx.prec=70
 dec=lambda z:Decimal(z.numerator)/Decimal(z.denominator)
 regret=lambda a,b:Decimal(50)*dec(b-a)/(dec(K(a)).sqrt()+dec(K(b)).sqrt())**2
 d=F(153,64)
 a,b=F(19,8),F(77,32)
 xstar=(Decimal(7557)-(dec(K(a))*dec(K(b))).sqrt())/Decimal(169)
 local_actual=(d-a)*(G(a)-G(d))+(b-d)*(G(d)-G(b))
 # local_best numeric is only an informative readout; all global area/regret checks above are rational-certified
 result={
  'schema':'EC49FRE_98_PRICE_NODES_EXACT_V1',
  'frozen_scientific_commit':'fc0f038e7bfd12c886b4d37f900bfb770c0f61ab',
  'parent_pr':2604,
  'added_nodes':[str(x) for x in add],
  'node_count':len(new),'interval_count':len(new)-1,
  'S86':str(S86),'S98':str(S98),'area_exact_gain':str(S86-S98),
  'certified_fraction_lower_bound':str(1-S98/F(2)),
  'certified_percent_lower_bound':str(dec((1-S98/F(2))*100)),
  'prior_worst_interval':[str(oldlead[0]),str(oldlead[1])],
  'new_worst_interval':[str(lead[0]),str(lead[1])],
  'prior_worst_regret_over_t':str(regret(oldlead[0],oldlead[1])),
  'new_worst_regret_over_t':str(regret(lead[0],lead[1])),
  'new_worst_lower_rational':str(lead[2]),
  'new_worst_upper_rational':str(lead[3]),
  'strict_maximum_verified_by_rational_sqrt_enclosure':True,
  'first_split_best_real_position':str(xstar),
  'first_split_rational_position':str(d),
  'first_split_position_error':str(abs(xstar-dec(d))),
  'first_split_rational_area':str(local_actual),
  'status':'EXACT_FINITE_GEOMETRY_CHECKED / NOT_REVIEWED'
 }
 (BASE/'EC49FRE_GEOMETRY_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False,indent=2))
 print('EC49FRE_98_NODE_RATIONAL_GEOMETRY_VERIFIED')
