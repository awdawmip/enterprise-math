# EC49FRE — Twelve exact native BRC seams, 98-node parameter enclosure, and rational-grid robustness theorem

2026-11-17 · status `AUTHOR_PROVED / EXACT_FINITE_CHECKED / NOT_REVIEWED`.

Inherited author-side frontier: EC49FRD PR #2604, commit `5e753e49725947f18f202bd979e4861f396aac6a`, frozen scientific input `fc0f038e7bfd12c886b4d37f900bfb770c0f61ab`. The 86 earlier price-node certificates, source distinctions and unrestricted-tree conventions are preserved. This is independent portable research under the project's current research protocol; the unavailable formal RS-EC49AS publication provides no CLAIM.

## Typed model and theorem statement

Original BRC class 16943 has 310 integer configurations, 141 distinct complete named profiles, and 228 physically labeled legal observations (144 terminal and 84 root; 209 different response partitions). The strictly positive prior on named profile i is

`p_i(lambda)=(1-lambda)/141 + lambda*m_i/310`, `sum_i m_i=310`, `0<=lambda<=1`.

Root sensing cost is `r=xt`, terminal sensing cost is `t>0`, and `x>=1`. The unrestricted optimum `V(x,lambda)` minimizes expected observation cost over all finite adaptive separating decision trees with physical action labels retained. The three known feasible BRC trees have normalized costs

- `A=(1-lambda)(6x+290)/141 + lambda(6x+751)/310`;
- `B=(1-lambda)(5x+293)/141 + lambda(5x+704)/310`;
- `C=(1-lambda)(5x+295)/141 + lambda(5x+685)/310`.

Write `K(x)=7557-169x`, `G(x)=310(3-x)/K(x)` and `beta=620/3299`.

**Theorem 1 (twelve new all-real-prior price slices, using inherited endpoint and named-action exclusion lemmas).** For each of the twelve prices in Table 1, for *every real* `lambda` in `[0,1]`,

`V(x,lambda)=t*min(A(x,lambda),B(x,lambda),C(x,lambda))`.

All optimal physically labeled first actions at the stated price are `{32,34}` for `0<=lambda<G(x)`, `{140,142}` for `G(x)<lambda<beta`, and `{16,23}` for `beta<lambda<=1`. At `G(x)`, take the union of the first two sets, and at `beta` take the union of the final two. Here `0<G(x)<beta<1`.

### Table 1 — newly computed native critical Bellman certificates

| Price x | First seam lambda=G(x) | Exact unscaled weighted Bellman optimum | Independent DP visited subsets | New certificate SHA256 prefix |
|---|---|---:|---:|---|
| `153/64` | `4030/152597` | 924,907,329,920 | 5929 | `b56a68790a53f32e…` |
| `151/64` | `12710/458129` | 2,775,622,765,440 | 5929 | `e50b024e4de92bff…` |
| `149/64` | `13330/458467` | 2,776,523,541,120 | 5929 | `a8b2b0652e4d925f…` |
| `147/64` | `930/30587` | 185,161,621,120 | 5929 | `7d6a4407347ebf6a…` |
| `145/64` | `310/9769` | 59,113,299,840 | 5929 | `fa4707a90fb46ab9…` |
| `143/64` | `15190/459481` | 2,779,225,868,160 | 5929 | `1c341edc28e3cb30…` |
| `141/64` | `5270/153273` | 926,708,881,280 | 5929 | `81308d23820af9f5…` |
| `139/64` | `16430/460157` | 2,781,027,419,520 | 5929 | `d6fc779ea66bd142…` |
| `137/64` | `3410/92099` | 556,385,639,040 | 5929 | `dde39f087cba9230…` |
| `135/64` | `5890/153611` | 927,609,656,960 | 5929 | `ea2918e5f5dc9f55…` |
| `133/64` | `18290/461171` | 2,783,729,746,560 | 5929 | `7e93a27c197c7141…` |
| `131/64` | `18910/461509` | 2,784,630,522,240 | 5929 | `a0a1a896054b16ba…` |

The integer optimum equals the chosen tree's exact expected cost multiplied by `x.denominator*310*141*lambda.denominator`; it is a raw integer accumulator, not the cost normalized by `t`.

**Proof.** The actual frozen BRC profile loader reconstructs 141 complete profiles and all 228 legal sensing actions with their physical indices; partition-equivalent actions may share a Bellman subproblem but each physical name is retained in first-action reporting. At each listed `lambda=G(x)`, an unrestricted exact finite weighted-subset Bellman recursion minimizes over all separating first observations, recursively over all strictly smaller non-singleton response fibers. Positive observation prices make every useful query split the current subset, so each path has at most 140 informative internal nodes and this dynamic program covers every finite adaptive separating tree. The independent implementation reconstructs the native source separately and obtains precisely the same integer optimum, first-action tie set `{32,34,140,142}` and complete separating-tree replay. All new exact certificates are included in the accompanying archive with each full SHA256 and the independent logs.

The inherited EC49FRD source is needed for the neighboring certified price endpoints, the classification at the shared second seam `beta`, and the single-seam named-label exclusion lemma. For fixed `(x,lambda)`, each feasible decision tree has cost affine separately in `x` and `lambda`; the unrestricted optimum is the infimum of these affine costs and hence concave in either parameter with the other fixed. Equality to an affine feasible candidate at two parameter endpoints propagates to their interval by concavity and feasibility. The inherited price-endpoint anchors, the new equality at `G(x)` and the inherited named-label exclusion close the relevant prior intervals. This is the precise dependency of the all-real claim; raw 12-point sampling alone would be insufficient. QED (conditional on the inherited exact lemma and certificate validity).

## Theorem 2 — 98-price-node exact continuum certificate

Let `P86` be the 86 certified inherited prices and let `P98=P86 union {the twelve prices in Table 1}`. In `[1,3] x [0,1]`, for each pair of adjacent fully certified price nodes `a<b`, the uncertified area is contained inside the strip `G(b)<lambda<G(a)`; the bound is an *enclosure*, not an assertion that the entire strip is truly non-optimal. With `D=2185500`,

`S(P) = sum_(adjacent a<b) (b-a)*(G(a)-G(b)) = D*sum_(adjacent a<b) ((b-a)^2/(K(a)*K(b))).`

The exact 98-node outcomes are

- `S98 = 296902200973874060795/160864097511408031554912`;
- `S86 - S98 = 423000/1703822659 > 0`;
- certified fraction of `[1,3]x[0,1]` at least `321431292821842189049029/321728195022816063109824` = **99.90771644960%**.

The 97 interval regret enclosures are `R(a,b)=50(b-a)/(sqrt(K(a))+sqrt(K(b)))^2`. An exact integer-square-root outward bracket of each radical at precision `10^-40` establishes that the *unique worst certificate* occurs at `[2,65/32]`:

`0 <= t*min(A,B,C) - V(x,lambda) <= 0.0000541304822524958 * t`

for all `x>=1`, `lambda in [0,1]`, using the unchanged inherited `x>=3` certificate. The former bound was `0.0000546100750162483 * t`. Both the area difference and the ranking of all 97 intervals are exact arithmetic certificates; displayed decimals are rounded readouts only.

## Theorem 3 — rational approximation stability of the globally jointly optimal grid

Fix arbitrary `1<=a<b<=3`, integer `m>=2`, `K(x)=7557-169x>0`, and the continuous jointly optimal grid `x_0^*=a < ... < x_m^*=b` from EC49FRD, characterized by

`K(x_i^*)=K(a)^(1-i/m)*K(b)^(i/m)`.

Write `rho=(K(a)/K(b))^(1/m)>1`, `h=log(rho)`, and consider any rational or real perturbed grid `q_0=a<q_1<...<q_m=b` satisfying `|q_i-x_i^*|<=delta` at each interior knot (all perturbed knots within `[a,b]`). Define `eta=169*delta/K(b)` and let `S_min` and `R_minimax` denote the exact EC49FRD optimum values for `m` intervals. Then

`0 <= S(q)-S_min <= (2185500/169^2)*(4*m-6)*cosh(h+2*eta)*eta^2`,

`R_minimax <= max_i R(q_i,q_(i+1)) <= R_minimax + 25*delta/K(b)`.

The `cosh` and `log` in this analytic bound are *auxiliary positive-real functions of the price-grid variables*, not native BRC observation or physical evolution operations. All scientific BRC observations and critical costs above were computed with the actual typed finite profile model and exact integer recursions.

**Proof.** Put `epsilon_i=log K(q_i)-log K(x_i^*)`; its endpoints vanish. Since `K` is decreasing and all knots lie in `[a,b]`, the real mean-value theorem gives `|epsilon_i| <= eta`. Defining `d_i=epsilon_i-epsilon_(i+1)` yields `y_i=log(K(q_i)/K(q_(i+1)))=h+d_i`, `sum_i d_i=0`, and `|d_i|<=2eta`. The exact area identity from EC49FRD is

`S(q)=(2D/169^2)*sum_i (cosh(y_i)-1)`, `D=2185500`.

Taylor's theorem *as an analytic inequality in y* (not as a BRC computation) gives `cosh(h+d_i) <= cosh(h)+sinh(h)*d_i+(1/2)*cosh(h+2eta)*d_i^2`; the first-order terms sum to zero. Moreover `sum_i d_i^2 <= (4m-6)*eta^2`, because first/last differences have magnitude at most `eta` and all `m-2` interior differences at most `2eta`. The new upper area bound follows; the lower bound is the inherited strict-convexity optimum.

The exact regret expression is `R(q_i,q_(i+1))=(50/169)*tanh(y_i/4)`. The function `tanh` is increasing with derivative at most one for positive arguments. Hence the largest interval upper bound differs from the ideal equal-spacing bound by at most `(50/169)*(2eta/4) = 25delta/K(b)`. The inherited global minimax theorem gives the lower inequality. QED.

**Constructive corollary.** Round each interior `x_i^*` to its nearest multiple of `1/H` for integer `H>=1` and leave the exact endpoints unchanged. If `1/H < K(b)*(rho-1)/169`, all rounded knots remain strictly increasing within `[a,b]`, with `delta<=1/(2H)`; the area gap is `O(H^-2)` and the maximum regret excess is `O(H^-1)` with the explicit constants above. This is a rational implementability guarantee for the otherwise often irrational optimal K-grid. The new price knots still require exact native Bellman certificates before they can be called certified BRC optimality seams.

As a concrete local instance, the first newly certified split `q=153/64` lies in `[19/8,77/32]`, and differs from that interval's exact real minimizer `(7557-sqrt(K(19/8)*K(77/32)))/169` by approximately `0.0000028840945867956175` in x. It is therefore a near-minimax rational split with a fully computed native Bellman seam; no transfer to physical Heartbeat dynamics is asserted.

## Reproducibility, provenance and next unit

The frozen original master (`SHA256 cd9a50799536d2b96230777b5392b1d742ceee896da05bb49aa097cf351e1d5e`) and full root-profile CSV (`SHA256 a61a3ee4d2f13f9d216f52cd3529c72d395c1250bfb1d7ae96a1adf5a6837c1f`) are included with their original pinned identity. The self-contained archive includes the newly executed 12 complete native JSON Bellman certificates, original native code, second independently constructed DP, exact geometry code/results, all logs, immutable inherited EC49FRD evidence archive, and one SHA256/size manifest.

The native computation and independent replication cover all 141 profiles, 228 named actions, 209 response partitions and all induced finite distinguishing trees at each listed price-seam point. New mathematical statements are author-proved with exact finite checks and currently `NOT_REVIEWED`. Preserved P000 six-space-plus-one-time, native signed axis, three-dimensional slice and residual-fidelity constraints are not changed by this auxiliary sensor optimization.

**Next unresolved question:** For the remaining 97 intervals, replace the strip-based *upper* regret certificate by a parameterized Bellman *lower bound* strong enough to prove `V(x,lambda)=t*min(A,B,C)` throughout the strips, or construct one exact counterexample decision tree with smaller cost. The latest maximal upper-bound interval is `[2,65/32]`; a further rational price between these endpoints is an independent exact-computation candidate. The research control's original continuation receipt is `FAILED / CANONICAL_REJECTED: unknown current immutable task publication` for `RS-EC49AS`; no formal CLAIM/Result/Activity checkpoint is asserted for this portable paper.
