#!/usr/bin/env python3
"""PREFIX-364: exact rational four-labelled continuation from t=1/16 toward H12.
Static auxiliary five-Port real quadratic inverse; not native X6 or typed BRC.
All decisive root inclusion and separation checks use Fraction, not floating point.
The rounded center proposal is never used as proof without a Banach certificate.
"""
from fractions import Fraction as Q
from pathlib import Path
import json

ROOT=Path(__file__).parent
T=lambda s:Q(str(s))
qa=list(map(Q,[34000,3200,58250,46600,31525]))
qb=list(map(Q,[204144,56336,1286,12936,28011]))
Z=Q(0)
# x=(Re u, Im u, Re v, Im v), B from PREFIX-363
forms=[
 (Z,[Q(1),Z,Z,Z],Z,[Z,Q(1),Z,Z]),
 (Z,[Z,Z,Q(1),Z],Z,[Z,Z,Z,Q(1)]),
 (Q(5,2),[Q(3,2),Q(-7,2),Z,Q(-4)],Q(9,2),[Q(7,2),Q(3,2),Q(4),Z]),
 (Q(11,4),[Q(11,4),Q(-15,8),Q(5,4),Q(-9,4)],Q(15,8),[Q(15,8),Q(11,4),Q(9,4),Q(5,4)])]
hess=[[[2*(a[j]*a[k]+b[j]*b[k]) for k in range(4)] for j in range(4)] for c,a,d,b in forms]
hess_norm=[[sum(map(abs,row)) for row in H] for H in hess]
def hgj(x):
 hs=[];gr=[]
 for c,a,d,b in forms:
  re=c+sum(a[j]*x[j] for j in range(4))
  im=d+sum(b[j]*x[j] for j in range(4))
  hs.append(re*re+im*im)
  gr.append([2*(re*a[j]+im*b[j]) for j in range(4)])
 return hs,gr

def inverse4(a):
 tab=[a[i][:]+[Q(int(i==j)) for j in range(4)] for i in range(4)]
 for j in range(4):
  p=next((k for k in range(j,4) if tab[k][j]),None)
  if p is None:raise ZeroDivisionError('singular center Jacobian')
  tab[j],tab[p]=tab[p],tab[j]
  z=tab[j][j]; tab[j]=[x/z for x in tab[j]]
  for i in range(4):
   if i==j:continue
   f=tab[i][j];tab[i]=[tab[i][k]-f*tab[j][k] for k in range(8)]
 return [row[4:] for row in tab]

def cert(lo,hi,x,r):
 assert lo<=hi and r>0
 t=(lo+hi)/2; dt=(hi-lo)/2
 hs,gs=hgj(x)
 q0=qa[0]+qb[0]*t
 q0hi=q0+qb[0]*dt
 f=[q0*hs[i]-qa[i+1]-qb[i+1]*t for i in range(4)]
 ft=[qb[0]*hs[i]-qb[i+1] for i in range(4)]
 J=[[q0*gs[i][j] for j in range(4)] for i in range(4)]
 M=inverse4(J)
 # |J(y,s)-J(x,t)| row entry <= |q1'|dt*|grad H| + q1max*r*||Hess row||_1.
 delta=[[qb[0]*dt*abs(gs[k][j])+q0hi*r*hess_norm[k][j] for j in range(4)] for k in range(4)]
 K=max(sum(abs(Q(int(i==j))-sum(M[i][k]*J[k][j] for k in range(4))) for j in range(4)) +
       sum(abs(M[i][k])*sum(delta[k]) for k in range(4)) for i in range(4))
 R=max(abs(sum(M[i][k]*f[k] for k in range(4))) +
       dt*abs(sum(M[i][k]*ft[k] for k in range(4))) for i in range(4))
 return K,R,r-R-K*r

def nearest12(y):
 z=y*10**12+Q(1,2)
 return Q(z.numerator//z.denominator,10**12)

def proposed(x,t):
 x=list(x)
 for _ in range(3):
  h,g=hgj(x);q0=qa[0]+qb[0]*t
  f=[q0*h[k]-qa[k+1]-qb[k+1]*t for k in range(4)]
  m=inverse4([[q0*g[k][j] for j in range(4)] for k in range(4)])
  x=[nearest12(x[i]-sum(m[i][k]*f[k] for k in range(4))) for i in range(4)]
 return x

# Independently exact algebraic root-disc centers from PREFIX-362.
raw={
'R0':[-377672048073067810,-33179190554807625,-1024551038755984257,444706162301618834],
'R1':[-356409585780010685,-129264232275208610,-996054577075402787,505315427522394764],
'R2':[-352894576312037190,-138572914348820846,-712359837804994165,860239422072391724],
'R3':[50087969218036839,375803445861251879,-1103871278550833250,170107619451771814]}
old={k:[Q(z,10**18) for z in arr] for k,arr in raw.items()}
# Input pin and endpoint chosen strictly before certified second fold lower bound.
T0=Q(1,16)
T1=T('0.0665')
assert T0<T1<T('0.0669341021803707452694')
# Minimum four-source identity is conditional on PREFIX-362 exact algebraic physical orbit discs.
# Try a small number of deterministic mesh refinements; every output remains auditable.
chosen=None
for N,r in [(128,Q(1,5000)),(256,Q(1,5000)),(512,Q(1,5000)),(1024,Q(1,5000)),(512,Q(1,10000)),(1024,Q(1,10000))]:
 try:
  span=T1-T0
  mesh=[T0+span*Q(j,N) for j in range(N+1)]
  branches={}
  for lab,init in old.items():
   prev=init; segments=[];witnesses=[]; maxK=Z;maxR=Z;minMargin=None
   for j in range(2*N+1):
    t=T0+span*Q(j,2*N)
    prev=proposed(prev,t)
    if j%2==0:
     witnesses.append(prev)
    else:
     jj=(j-1)//2
     K,R,margin=cert(mesh[jj],mesh[jj+1],prev,r)
     if not (K<1 and margin>0):raise ArithmeticError(f'{lab} segment {jj}: K={float(K):.3f} margin={float(margin):.7f}')
     maxK=max(maxK,K);maxR=max(maxR,R)
     minMargin=margin if minMargin is None else min(minMargin,margin)
     segments.append(prev)
   # Endpoints: the initial physical fiber discs intersect their witness Banach boxes.
   assert max(abs(witnesses[0][j]-init[j]) for j in range(4))<Q(1,10**7)
   wr=Q(1,10**7)
   for j,pt in enumerate(witnesses):
    K,R,margin=cert(mesh[j],mesh[j],pt,wr)
    if not(K<1 and margin>0):raise ArithmeticError(f'{lab} witness {j}')
    neigh=([0] if j==0 else [N-1] if j==N else [j-1,j])
    for i in neigh:
     if not(max(abs(pt[k]-segments[i][k]) for k in range(4))+wr<r):
      raise ArithmeticError(f'{lab} cube overlap {j},{i}')
   branches[lab]=dict(segments=segments,witnesses=witnesses, maximum_K=maxK,maximum_R=maxR,minimum_margin=minMargin)
  # Check 4 branches pairwise disjoint throughout each common t interval,
  # by a disjoint coordinate in all corresponding pairs of four-dimensional boxes.
  for j in range(N):
   for p,l in enumerate(raw):
    for other in list(raw)[p+1:]:
     a=branches[l]['segments'][j];b=branches[other]['segments'][j]
     if not any(abs(a[k]-b[k])>2*r for k in range(4)):
      raise ArithmeticError(f'branch pair indistinguishable {j}: {l}/{other}')
  chosen=(N,r,branches)
  break
 except (ArithmeticError,ZeroDivisionError,AssertionError) as exc:
  print('refine',N,str(r),'reason',str(exc)[:110],flush=True)
if chosen is None:raise AssertionError('No certified mesh; no PASS issued')
N,r,branches=chosen
# Strictly separated by original u real component between R0 and R3 at terminal T1.
# Additional feasible next slice of fold tracking remains a separate obligation.
# Label inheritance from PREFIX-362's complete list of physical roots at t=1/16.
# The initial Banach witness contains a physical root; the other five algebraic
# u disks are strictly disjoint from its u-projection. Thus it is the labeled one.
all_u_raw=[(-377672048073067810,-33179190554807625),
(-356409585780010685,-129264232275208610),
(-352894576312037190,-138572914348820846),
(50087969218036839,375803445861251879),
(94355598915408067,-239135968680029203),
(205214119154923474,-520097140339574159)]
for i,lab in enumerate(raw):
 p=branches[lab]['witnesses'][0];wr=Q(1,10**7);root_radius=Q(1,10**12)
 for j,(a,b) in enumerate(all_u_raw):
  if j==i:continue
  z=[Q(a,10**18),Q(b,10**18)]
  assert any(abs(p[k]-z[k])>wr+root_radius for k in range(2)),(lab,j)
# Newly extended robust coherent observer separation for inherited H3→R2/R1.
rv2=min(node[2]-r for node in branches['R2']['segments'])
rv1=max(node[2]+r for node in branches['R1']['segments'])
assert rv2>-Q(73,100) and rv1<-Q(99,100)
q1min=(qa[0]+qb[0]*T0)/Q(59536)
assert q1min>Q(10,13)
assert 2*q1min*Q(26,100)>Q(2,5)
assert 2*q1min*Q(13,100)>Q(1,5)>Q(1,8)
# At t=0.0665 identify which two branches are close to PREFIX-361 fold center,
# without claiming that these already connect through the remaining parameter gap.
fold=[T(v) for v in [
 '-0.373142042340452907175027641211875750534155477909222485673943462979448485422037',
 '-0.0837445473545578199827813837006670780233159346317921776530597395806951736384667',
 '-1.00089215574741813465830349283668302546824867512845484704354632234612753727647',
 '0.471287741123734760043946207194095912238481474040888194561639891017377903234185']]
for lab in ('R0','R1'):
 assert max(abs(branches[lab]['witnesses'][-1][k]-fold[k])+Q(1,10**7)+Q(1,10**24) for k in range(4))<Q(1,30)
for lab in ('R2','R3'):
 assert max(abs(branches[lab]['witnesses'][-1][k]-fold[k])-Q(1,10**7)-Q(1,10**24) for k in range(4))>Q(1,5)
startgap=max(abs(old['R0'][k]-old['R1'][k]) for k in range(4))
endgap=max(abs(branches['R0']['witnesses'][-1][k]-branches['R1']['witnesses'][-1][k]) for k in range(4))
assert startgap>Q(9,100) and endgap+2*Q(1,10**7)<Q(1,25)

terminal={k:[str(z) for z in v['witnesses'][-1]] for k,v in branches.items()}
res={
 'schema':'EM_PREFIX364_FOUR_PHYSICAL_SOURCE_CONTINUATION_V1',
 'status':'AUTHOR_SIDE_EXACT_RATIONAL_UNREVIEWED_NOT_ADMITTED',
 'frozen_global_main':'802ddc66d8755f7a95a0dcb8a34573cb7a7b69e6',
 'frozen_project_main':'ea390dcadd5d3233200fad2aa0888d427f157db8',
 'model':'Static five-Port auxiliary complex 3x5; exactly the F/J/H of PREFIX-363; not native X6 dynamics',
 't_start':'1/16','t_end':str(T1),
 'segments_per_branch':N,'root_boxes':4*N,'endpoint_witnesses':4*(N+1),
 'root_cube_radius':str(r),'witness_cube_radius':'1/10000000',
 'branches':{k:{'maximum_K_upper_1e9':int(v['maximum_K']*10**9)+1,
                 'maximum_R_upper_1e9':int(v['maximum_R']*10**9)+1,
                 'minimum_margin_lower_1e9':int(v['minimum_margin']*10**9),
                 'terminal_center_decimal':[f'{float(z):.12f}' for z in v['witnesses'][-1]],
                 'initial_rouche_label':k} for k,v in branches.items()},
 'checks':['all root boxes contraction and self-map, exact Fraction','all endpoint witnesses existence and inclusion in neighbor root boxes','four same-parameter root cubes pairwise disjoint','left endpoint lies in PREFIX362 root discs, unique physical lift'],
 'additional_strict_claims':{'original_five_intensities_identical_for_all_four':'from F=0 by construction', 'extended_R2_minus_R1_coherent_C_gt':'2/5', 'extended_each_side_coherent_threshold_margin_gt':'1/5', 'noise_abs_tolerated':'1/8', 'R0_R1_start_maxnorm_difference_gt':'9/100', 'R0_R1_terminal_maxnorm_difference_lt':'1/25', 'R0_R1_terminal_within_fold_center_maxnorm':'1/30', 'R2_R3_terminal_outside_fold_center_maxnorm':'1/5'},
 'source_dependency':'PREFIX362 R0-R3 complete physical fiber and tiny u/v certified isolation discs; PREFIX363 separate H3-R1/R2 labels; PREFIX361 fold-center accurate root box.',
 'unproved':'No connection from t=0.0665 to singular source t_b; no all-parameter global source count reproved, no native X6/P000 bridge.',
 'verdict':'PASS_PREFIX364_EXACT_FOUR_LABELED_CONTINUATIONS_TO_0P0665'}
(ROOT/'RESULTS_PREFIX364.json').write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(res['verdict'])
print('N',N,'r',r,'boxes',4*N,'witnesses',4*(N+1))
for k,v in res['branches'].items():print(k,v)
