"""Exact Fraction tests for an R5 policy-coupled perturbation theorem.

This verifies algebra and a fully specified finite auxiliary example. It does
not independently re-enumerate the predecessor R5 two-merger process.
"""
from fractions import Fraction as F
from itertools import product

# Two terminal cylinders. Seedless-LR has one policy L; FULL also has F.
qF = (F(3, 4), F(1, 4))
qL = (F(1, 4), F(3, 4))
base_margin = F(1, 2)
r0 = (F(1, 2), F(1, 2))
for eps in (F(0), F(1, 16), F(1, 4), F(3, 8), F(1, 2)):
    lo = tuple(max(-eps, -r) for r in r0)
    hi = tuple(min(eps, 1-r) for r in r0)
    d = tuple(a-b for a,b in zip(qF,qL))
    formula = base_margin + sum(min(di*a, di*b) for di,a,b in zip(d,lo,hi))
    corners = [base_margin+sum(di*z for di,z in zip(d,delta))
               for delta in product(*[(a,b) for a,b in zip(lo,hi)])]
    assert min(corners) == formula == base_margin-eps
    assert all(0 <= r+z <= 1 for z in product(*[(a,b) for a,b in zip(lo,hi)]) for r in ())
    print(f"toy_epsilon={eps} exact_worst_fixed_witness_margin={formula}")
assert base_margin/(2*F(1)) == F(1,4)  # uniform |change|<=2 epsilon
assert base_margin/sum(abs(a-b) for a,b in zip(qF,qL)) == F(1,2)
assert r0[0]-F(1,2) == 0 and r0[1]+F(1,2) == 1

# Nontrivial LEGAL time-affine shaping on a separate 4-terminal Q toy.
times = (1,2,3,4)
base = (F(1,4), F(1,3), F(1,2), F(2,3))
a, b = -F(1,16), F(1,32)
new = tuple(r+a+b*t for r,t in zip(base,times))
assert all(F(0) <= r <= F(1) for r in new)
policies = ((F(1,8),F(1,4),F(1,4),F(3,8)),
            (F(1,4),F(1,4),F(1,4),F(1,4)),
            (F(3,8),F(1,8),F(3,8),F(1,8)))
c=F(41,12)
old_scores=[]
new_scores=[]
for weights in policies:
    assert sum(weights)==1 and all(w>0 for w in weights)
    e0=sum(w*r for w,r in zip(weights,base))
    e1=sum(w*r for w,r in zip(weights,new))
    tq=sum(w*t for w,t in zip(weights,times))
    assert e1 == e0+a+b*tq
    old_scores.append(c*e0-tq)
    new_scores.append(c*e1-(1+c*b)*tq)
    assert new_scores[-1] == old_scores[-1]+c*a
assert max(new_scores)-min(new_scores) == max(old_scores)-min(old_scores)
print(f"legal_global_gauge_a={a} b={b} new_labels={new}")

# Exact R5 benchmark arithmetic: conditional on inherited baseline J-gap=2.
s,d=F(3,16),F(1,8)
merger_mass=2*s
C=F(3,4)+1/(2*s)
assert C == F(41,12) and merger_mass==F(3,8)
assert 12*d/(4*s)==2
assert 2*41*merger_mass==F(123,4)
assert 2/F(123,4)==F(8,123)
for bb,rr in ((F(0),F(1,16)),(-F(1,12),F(1,16)),(F(1,24),F(1,32))):
    margin=F(2)-F(123,4)*rr
    norm=F(41)+abs(F(12)+F(41)*bb)
    assert margin>0
    lower=margin/norm
    print(f"R5_assumed_base_gap=2 gauge_b={bb} residual_rho={rr} J_b_margin_lower={margin} Linfty_lower={lower}")
assert (F(2)-F(123,4)*F(1,16))/(F(41)+abs(F(12)-F(41,12)))==F(3,1904)
print('PASS_EXACT_R5_POLICY_COUPLED_GAUGE_ROBUSTNESS')
