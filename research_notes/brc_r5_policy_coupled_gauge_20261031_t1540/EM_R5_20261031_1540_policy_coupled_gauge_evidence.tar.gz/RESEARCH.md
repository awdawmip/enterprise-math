# R5 — Exact policy-coupled robustness and observer-gauge reduction

Research date: 2026-10-31 Asia/Shanghai. Type: **author-side mathematical research**. State: `AUTHOR_PROVED / EXACT_FRACTION_CHECKED / UNREVIEWED / NOT_ADMITTED / PORTABLE_ONLY / REGISTER_PENDING`. The finite-policy theorems below are self-contained under their stated assumptions. The R5 numerical corollary **assumes** the preceding unreviewed author's Bellman support identity; this run did not re-enumerate its 1,024 FULL and 16 LR deterministic trajectories.

## Frozen source and problem

- Account source: `awdawmip/chatgpt-global-knowledge main@0f56e103e335e81db09f4169fb389c29f06815b6`; normative bootstrap/manual, P000, ACTIVE worldview and relevant mathematics/BRC rules read at that same immutable SHA.
- Project source: `awdawmip/enterprise-math main@d26fed9696ab2e230c7c9e8bbe64f684be6bb7ce`; project AGENTS, P000, current source authority and `docs/PORTABLE_RESEARCH_PROTOCOL.md` read at that immutable SHA.
- Direct predecessor: R5 author-side [`research_notes/brc_r5_merger_q_error_robustness_20261031_t1440/RESEARCH.md`](https://github.com/awdawmip/enterprise-math/blob/0d01d50eef898384a993ab39e79fb6df1ab8fb3d/research_notes/brc_r5_merger_q_error_robustness_20261031_t1440/RESEARCH.md). It derives, conditional on the original R5 Bellman support identity, a post-merger terminal-Q-error amplitude threshold `8/123` at `(alpha_0,alpha_1)=(1/4,1/8)`.
- Original positive two-merger model and conditional baseline support are described in [`README.md`](https://github.com/awdawmip/enterprise-math/blob/e7916482f44a925e11ece98e406309f4655fb1f1/research_notes/brc_r5_positive_two_merger_rigidity_20261031_t1340/README.md). Exact native X6 realization and original mother target remain open.

**Question.** Can we replace the prior two-independent-suprema error budget by an *exact policy-coupled* perturbation budget, and distinguish genuinely new source/path Q-error information from changes of observer coordinates?

## Theorem 1 — exact worst perturbation for one fixed FULL witness

Take a finite two-law finite-horizon STOP/CONTINUE model with fixed natural transition weights, fixed decision topology and a finite set of terminal Q cylinders `h=1,...,m`. Fix the terminal baseline error labels `r_h in [0,1]`. For an arbitrary fixed deterministic/behavioral FULL witness `f`, let `q_f(h)>=0` be its Q mass ending at cylinder `h`. Let the seedless LR policy class have finitely many deterministic policies `l_j`, `j in J`, such that a signed linear observer support functional reaches its maximum over all real LR behavioral policies at some `l_j`. This holds when each time-labelled LR local decision variable occurs at most once along a trajectory, making the expected observer **multi-affine** in these variables.

Suppose the support functional includes `c*error_Q` and other terms fixed by the natural transition/stopping-time law; it may also include P-error only when that label is held fixed. Write the original signed support scores as `A_f` and `B_j`. Change the Q terminal errors by one common physical perturbation vector `delta=(delta_h)_h` for **both** policy classes (never independently optimize different error worlds for FULL and LR). Every coordinate must lie in the exact legal interval

```
L_h(epsilon)=max(-epsilon,-r_h),
U_h(epsilon)=min(+epsilon,1-r_h), epsilon>=0.
```

Define `D_j(h)=q_f(h)-q_lj(h)`. Then the **exact**, all-real, attained minimum of the fixed-witness margin against *all* seedless LR behaviors over all legal Q-error perturbations is

```
min_{delta in box(epsilon)} [ H_new(f)-sup_LR H_new ]
= min_{j in J} [ A_f-B_j +
    sum_h min( c*D_j(h)*L_h(epsilon), c*D_j(h)*U_h(epsilon) ) ].       (1)
```

All data rational => the right side is exactly rational at rational epsilon. If (1) is positive, this *one particular FULL witness* separates the entire new LR convex hull simultaneously for every legal calibration in the box. If it is nonpositive, this witness's **uniform** separation has failed, which does **not** establish equality of FULL and LR hulls: another FULL policy/direction might still separate.

**Proof.** For a fixed policy, its path distribution is unchanged by a terminal error-label change, so `H_new(f)=A_f+c sum_h q_f(h)delta_h` and `H_new(l_j)=B_j+c sum_h q_lj(h)delta_h`. Because the LR support maximum is the maximum over finitely many `l_j`, subtracting it is a **minimum** over `j`. The two finite/compact minimizations commute: `min_delta min_j = min_j min_delta`. Each remaining linear expression in `delta` attains its minimum at one legal box endpoint per coordinate. Summing the independent endpoint minima gives (1), including baselines at 0 or 1. No probabilistic independence of error label adjustments between policies was used. Q source/route cylinders remain separate until this exact observer calculation. QED.

**Sharper corollary.** When legal bounds do not truncate `[-epsilon,epsilon]`, (1) equals

```
min_j [ A_f-B_j - |c|*epsilon*sum_h |q_f(h)-q_lj(h)| ].            (2)
```

The `L1` mass discrepancy can be **strictly less** than `Q_f(C)+Q_lj(C) <= 2m_C`, which was the previous run's universal union-bound coefficient. Formula (1) also remains valid after legal `[0,1]` clipping. This is a task-specific optimization improvement, not a claim that the earlier universal bound was false.

### Complete exact auxiliary counterexample to sharpness of the crude threshold

Consider two terminal Q-error cylinders, a fixed FULL witness and one LR deterministic policy with mass vectors

```
q_f=(3/4,1/4), q_l=(1/4,3/4), r=(1/2,1/2), c=1,
A_f-B_l=1/2.
```

Treat the difference `A_f-B_l` as a given *signed support baseline* of this finite observation model; it is an **auxiliary model**, not an asserted R5/native X6 construction. FULL contains both `f` and `l`. For every rational or real `0<=epsilon<=1/2`, (1) yields the exact minimum `1/2-epsilon`, achieved by `delta=(-epsilon,+epsilon)`. Thus the fixed witness loses strict separation at exactly `epsilon=1/2`, with fully legal new response labels `(0,1)`. The previous independent-supremum coarse estimate using cylinder mass cap `m_C=1` only certifies `1/2-2epsilon>0`, stopping at `epsilon<1/4`. This **strict factor-two improvement** illustrates why the R5 next step must compute true joint cylinder occupancies rather than rely on the universal `2*m_C` bound. It does not assert any R5 numerical improvement before those occupancies have been read.

## Theorem 2 — full-terminal time-affine observer-gauge equivalence

For **every** finite probability model, strategy class and two-law four-observer map

```
O=(error_P,error_Q,T_P,T_Q),
```

suppose *every* complete Q terminal trajectory `h`, including early STOP histories, receives the same legal error-response calibration

```
r_new(h) = r_old(h) + a + b*tau(h),   0 <= r_new(h) <= 1,
```

where `tau(h)` is that trajectory's actual Q stopping time and `(a,b)` is independent of policy, source and route. Then for every policy

```
O_new = A_(a,b)(O_old)
      = (error_P, error_Q + a + b*T_Q, T_P, T_Q).                  (3)
```

This affine shear has inverse `(error_P, error_Q'-a-b*T_Q,T_P,T_Q)` and linear determinant `1`. It preserves **all** affine ranks, exact equality/inequality of FULL and LR observation convex hulls, and equality/inequality or nonconvexity of their **actual real behavioral observation sets**. In particular, for the original R5 benchmark separator `J=41*error_Q-12*T_Q`, the transported functional

```
J_b = 41*error_Q_new - (12+41*b)*T_Q
```

satisfies `J_b(O_new)=J(O_old)+41*a`; the two policy classes' support gap is exactly the baseline gap for every *legal* gauge calibration, regardless of its raw amplitude. QED by summing path weights, using `sum_h Q_pi(h)=1` and `sum_h tau(h)*Q_pi(h)=T_Q(pi)`.

**Important scope separation.** Time-affine calibration here is applied on **all** Q terminal histories. A modification allowed *only* after the stage-3 merger generally is **not** of form (3): its contribution is `a*Q_pi(C)+b*E_Q[tau*1_C]`, which depends on policies. Theorem 2 never deletes hidden origin/route BRC residuals and does not infer a native X6 isomorphism.

## Corollary — gauge-quotiented R5 robustness (conditional on inherited Bellman gap)

More generally suppose a **legal final** error response is decomposed into

```
r_new(h) = r_old(h) + a + b*tau(h) + eta(h),
eta(h)=0 outside the declared post-merger cylinder C,
|eta(h)|<=rho on C.
```

The intermediate time-affine response need **not** itself be a legal probability label: only the final response must be in `[0,1]`. Applying the inverse affine observer shear (3) reduces the problem exactly to the localized error `eta`. If `Q_pi(C)<=m_C` for all policies, then the transported support gap satisfies

```
Delta_new(J_b) >= Delta_old(J) - 2*41*m_C*rho.                    (4)
```

At the original R5 benchmark `alpha_0=1/4`, `alpha_1=1/8`, the inherited **unreviewed author-side** identities are `Delta_old(J)=2` and `m_C=3/8`; hence

```
Delta_new(J_b) >= 2 - 123*rho/4.                                 (5)
```

The raw perturbation `max_h |r_new(h)-r_old(h)|` can exceed the predecessor's `8/123` threshold: what controls (5) is the *residual* `rho` **after** a global time-affine component is removed, subject always to final label legality. Formula (5) is strictly positive for `rho<8/123` independently of `a,b`. This is an exact extension of the earlier small raw-amplitude exclusion to a gauge-quotiented class; existence of a nontrivial `a,b` *legal for every exact R5 baseline terminal label* remains to be checked against the predecessor's complete branch table.

For `rho=1/16` the signed support gap is at least `5/64`; for any fixed legal `b`, an optimizing FULL observation lies at `L_infinity` distance at least

```
(5/64) / (41+|12+41*b|)                                          (6)
```

from the whole LR convex hull. At `b=0`, this is `5/3392`; at **conditionally legal** `b=-1/12`, it is `3/1904`. The distance statement is an *existence* certificate for the optimizer, not a claim about the inherited particular FULL witness. P-error changes remain irrelevant to this signed support direction.

## Actual verification and limitations

`VERIFY.py` was executed using Python standard-library exact `Fraction`. It validates the all-legal-endpoints formula in a completely specified two-cylinder auxiliary example for five epsilon values, displays the strict improvement of the exact coupling threshold, checks a nonzero **legal** full-terminal affine calibration on three explicit probability vectors, and checks the inherited R5 rational constants and transported distance expressions. Literal stdout is in `EXACT_OUTPUT.txt`, ending `PASS_EXACT_R5_POLICY_COUPLED_GAUGE_ROBUSTNESS`.

Universal conclusions (1) and (3) are analytic proofs; examples and rational checks are **not** a full enumeration of R5 trajectories or an independent confirmation of the predecessor's Bellman formula. The R5 numerical claims (4)-(6) are explicitly conditional on the predecessor's declared model and support identity. The original all-signed four-hull equality vs real behavioral-image mother problem remains open. No formal CLAIM, Source Result, independent Driver review, Foundation promotion, P000 modification or native X6 bridge is asserted.

## Next discriminating step

Read the complete R5 two-merger `VERIFY.py` and reconstruct the actual 1,024 FULL and 16 seedless-LR deterministic Q post-merger terminal-cylinder mass vectors, preserving source, route, history, STOP/CONTINUE action and P/Q normalization. For the exact original `J`-maximizing FULL witness compute (1), including **legal** `[0,1]` endpoint truncation, and report its sharp rational robustness threshold. Then solve the finite union of rational LPs for the first actual `J` support-gap closure (if one exists); a closed `J` gap is **not** four-hull equality, so retain all-signed Farkas/primal hull checks. Avoid using this auxiliary theorem to relabel the parent R5 model or discard source residual.
