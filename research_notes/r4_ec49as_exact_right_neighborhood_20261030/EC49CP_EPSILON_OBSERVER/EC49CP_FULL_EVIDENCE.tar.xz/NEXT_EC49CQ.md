# EC49CQ — minimal interface that recovers d=0 ε-residuals

Continuation source: EC49CP/README_EC49CP.md, exact `VERIFY_EC49CP.py`, `EXACT_REPORT_EC49CP.json`; predecessor EC49CO proof at Git commit `30cb1b7879e0ab433d6b80b7d969e80a715ff80d`. Research frame: frozen P000/native X6; typed **positive** BRC branch instruments `(2,3,3,2,1,1)` and `(3,2,3,2,1,1)` on positive primitive axes and negative weights1; four ordered A/B tags; four whole operations a,b,c,d defined in EC49CP.

Already proved (do not repeat): with empty-word observation included, `dim O_h^ε=D_h+9`, `D_h=3(3h²+7h+1)` for h>=1. For n even >= max(10,2h+6), full one-step joint right-shift has rank D_{h+1} and kernel dimension9 supported only at current d=0, even though the prior nonempty-only kernel of dimension6 was at d=2E1,2E2. There are nine literal genuine length10 path-multiset kernel witnesses, modular exact checks h1..12, native BRC crosschecks n0,2,4.

**Unsolved scientific unit:** specify one *genuinely new* observable or whole operation: (A) a prefix-interior BRC readout that can observe a chosen nonzero displacement and distinguish ε residuals, or (B) one new native signed operation. Derive the quotient rank of each added readout on the existing 9-dimensional kernel, then derive full new right-shift rank and construct literal path witnesses or a strict no-go.

Acceptance: exact operation word and observer, signed X6 displacement rules, reachable A/B DFA, type-specific BRC multiplier and target fiber, all-h argument (or explicit finite qualified result), one executable integer/modular checker, nonnegative literal multiset witness when rank changes, exact real-path saturation threshold or a clearly scoped formal-only theorem. Preserve immutable predecessor, authorship and separate formally granted CLAIM/Review rights. Do not infer physical time or phase amplitudes from positive branch weights.

Status: author-side portable next question; **not** a formal immutable task/publication, claim or accepted result.
