# EC49CP — Adding the empty suffix relocates the BRC rolling kernel (precise observer theorem)

2026-10-31 · original author-side, portable mathematical research · `ANALYTIC_PROOF / EXACT_MODULAR_AUDIT_PASS / LITERAL_NATIVE_BRC_WITNESS_PASS / UNREVIEWED / NOT_ADMITTED`.

## Provenance and question

**Frozen source reads for this research unit** (read-only scientific assumptions): `GLOBAL_KNOWLEDGE_V1` canonical `main@d522eeb3558ca30ba8fda20d6ad508f364477fc7`; Enterprise Math `main@a2f0a44c2a7e0b345e0aadc72c90f0b5866bcf24`. Both entries, P000 `ACTIVE_LOCKED`, native X6+separately typed time, ACTIVE residual-fidelity worldview, and `docs/PORTABLE_RESEARCH_PROTOCOL.md` were read. P000, worldview and source runtime were not altered. Existing author-side result EC49CO is at immutable commit `30cb1b7879e0ab433d6b80b7d969e80a715ff80d`, `EC49CO_ROLLING_KERNEL/README_EC49CO.md`. Previous all-window real-history saturation is used *at its original scope* (EC49CN/CO); this is an author-side dependency, not an accepted theorem.

EC49CO established a **six-dimensional kernel** of the joint one-step rolling observer when both the input and output windows exclude the empty word. The new question is whether exposing the zero-operation readout `ε` removes that information loss, and, if so, exactly what remains unobservable.

## Exact native model

An actual history `p` is a fixed-length word over twelve signed primitive axes `±E₁,...,±E₆` in the original X6 relative-displacement chart. A step modifies one signed integer coordinate. No absolute physical origin or physical clock is introduced: `return to 0` means returning to the initial *relative Cell* at the end of the *chosen word*.

The A/B ordered-pattern automaton has reachable states
`Q={(a,b):a,b ∈ {0,1,2}}\{(1,1)}`. Here `2` means that A=(+E₁,+E₂) or B=(+E₂,+E₁) occurred at least once, `1` means the first symbol is pending, and `0` means no pending first symbol. The indicator functions on `Q` are

* `F_A=1[a=2]`, `F_B=1[b=2]`, `u_A=1[a=0]`, `u_B=1[b=0]`;
* the four displayed tags are `(1−F_A)(1−F_B)`, `(1−F_A)F_B`, `F_A(1−F_B)`, `F_AF_B`.

Three **typed positive BRC** channels are retained separately: `w₀` with weights for positive E₁..E₆ `(2,3,3,2,1,1)`, `w₁` with `(3,2,3,2,1,1)`, and exact path multiplicity `1`; all negative-axis steps have weight `1`. The output consists of `4×3=12` integer channel/tag coordinates, gated by final relative displacement `0`. This is a *positive-weight branch-counting BRC model*, not a signed/phase amplitude or a native physical-time law. The established kernel source is `EC49CI_OPERATION_CLOSURE/native_signed_brc.py` at the cited immutable PR frontier; its Git blob is `300a96e3dc24bf6fff73743037a0347a8bc83176`.

The four **whole** future operations are

```
a = (-E₁,-E₁)       b = (-E₂,-E₂)
c = (+E₁,+E₂,-E₁,-E₂)
d = (+E₂,+E₁,-E₂,-E₁).
S = {a,b,c,d}.
```

For `h≥1`, `O_h(p)` stores the 12 outputs of `pw` over all `w∈S¹∪...∪Sʰ` (nonempty words); `O_h^ε(p)` additionally includes `w=ε`. The image of real fixed-length histories under these maps is a rational linear/additive observation space `Y_{h,n}` or `Y^ε_{h,n}`. Signed *linear combinations of nonnegative multiset histories* are allowed **only to measure linear rank**; this is not physical cancellation of positive mass. The question concerns the smallest exact additive **rational-linear** observation state, not arbitrary nonlinear encodings.

## Theorem 1 — ε adds exactly nine dimensions (all finite h)

For every integer `h≥1`, in the formal native X6/BRC fiber carrier (independent typed channels on each reachable `(displacement,q)`), the row rank obeys

\[
D_h=\dim O_h=3(3h^2+7h+1),\qquad
\boxed{\dim O_h^\varepsilon=D_h+9}.
\]

For real histories of a common **even** length `n≥max(10, 2h+4)`, the same equality holds for the actual observation images: `dim_Q Y_{h,n}^ε=D_h+9`. The full old-rank assertion uses the real-history saturation theorem cited above. The nine *new* dimensions have an explicit length-10 native-path witness below, which persists at all larger even lengths by prependable neutral two-step X6 excursions.

**Proof.** A nonempty whole-operation word returns to the relative origin only from positive target displacement `(2i,2j,0,0,0,0)` with `i,j≥0`. At each nonzero target the new empty word gives zero, so rows are unchanged. At target `(0,0)`, all nonempty return-capable suffixes consist solely of `c,d`. Their first whole operation maps the eight DFA states so that all later completion labels depend precisely on `1,u_A,u_B`; both `c` and `d` are available for every `h≥1`, attaining rank **3 per BRC type**. The empty word supplies the four direct tag rows spanning `1,F_A,F_B,F_AF_B`. The union has row basis

\[
\{1,u_A,u_B,F_A,F_B,F_AF_B\},
\]

which has rank **6**, exactly 3 more per type. For example, evaluation on states `(00),(01),(02),(10),(20),(22)` has integer determinant `−1` when ordered as `(1,F_A,F_B,F_AF_B,u_A,u_B)`. Three independent BRC type channels give `3·(6−3)=9`; all other displacement fibers are unchanged. This proves the formal formula. The explicit all-type genuine-history witness in Theorem 3 supplies the missing lower bound in real paths for lengths ≥10, while existing EC49CN/CO full-rank histories supply `D_h` for `n≥2h+4`; add the independent kernels and pad by neutral excursions. ∎

## Theorem 2 — ε exposes the old six, but the joint future kernel becomes nine

For `h≥1`, regard `O_{h+1}^ε(p)` as input and for each `e∈S` form the next observation `O_h^ε(pe)`. The typed exact right-shift maps are

\[
(T_e^\varepsilon y)_w = y_{ew},\quad w\in S^{0}\cup S^1\cup\dots\cup S^h.
\]

For formal carriers and, in the actual image, **even** `n≥max(10,2h+6)`, put `N_h=(h+1)(h+2)/2`. Then

\[
\begin{aligned}
\dim Y^\varepsilon_{h+1,n}&=D_{h+1}+9=9h^2+39h+42,\\
\operatorname{rank} T_a^\varepsilon&=\operatorname{rank} T_b^\varepsilon=12N_h,\\
\operatorname{rank} T_c^\varepsilon&=\operatorname{rank} T_d^\varepsilon=6N_h,\\
\operatorname{rank}(T_a^\varepsilon,T_b^\varepsilon,T_c^\varepsilon,T_d^\varepsilon)&=D_{h+1}=9h^2+39h+33,\\
\boxed{\dim\ker(T_a^\varepsilon,T_b^\varepsilon,T_c^\varepsilon,T_d^\varepsilon)&=9.}
\end{aligned}
\]

All nine lost dimensions lie in the target **displacement-zero** fiber. In contrast, the prior EC49CO nonempty-output rolling kernel had dimension 6, supported at the two target fibers `(2,0)` and `(0,2)` (in the E₁,E₂ chart). The old six directions become visible after one update because the new output explicitly includes `w=ε`, i.e. the full **one-operation** observer. The new nine directions are current ε distinctions that disappear after *every nonempty whole operation*. Thus simply exposing ε does **not** create an exact self-updating minimal sufficient state.

**Proof.** Across all `e∈S` and output words `w` of length `0..h`, the concatenations `ew` run through **exactly** all nonempty words of length `1..h+1`. Thus the joint output row space is the already-proved nonempty observation row space of rank `D_{h+1}`. By Theorem 1 its input row space has rank `D_{h+1}+9`; rank-nullity gives exactly 9. At displacement zero, the nonempty rows span `1,u_A,u_B`, whereas ε adds the three independent `F_A,F_B,F_AF_B`, per type. At other fibers all input rows are nonempty, so there is no loss there.

For one prefix `a` (or `b`), the previous EC49CO nonempty continuation rank `3(4N_h−1)` gains just three typed dimensions: the zero-continuation `aε` provides four completion tags at its single low-weight target, where `av` with nonempty `v` spanned three; hence `3(4N_h−1)+3=12N_h`. For `c` and `d`, `cε`/`dε` lies in the same existing two-dimensional DFA row space at target zero, so their prior ranks `6N_h` do not change. This proves all formulas. ∎

## Theorem 3 — nine independent REAL native BRC witnesses

At real history length 10, every direction in the nine-dimensional rolling kernel can be represented by a difference of two **nonnegative integer** multisets of genuine signed-X6 paths, preserving exact branch weights. Six eight-step closed histories whose ending DFA states are `00`, `01`, `02`, `10`, `20`, `22` are explicitly encoded in `VERIFY_EC49CP.py` as `BASIS`. Each is prefixed with precisely one of the three neutral two-step excursions `(+E₁,−E₁)`, `(+E₂,−E₂)`, or `(+E₃,−E₃)`.

These three excursion types multiply the three BRC channels by the invertible integer matrix

\[
M=\begin{pmatrix}2&3&3\\3&2&3\\1&1&1\end{pmatrix},\qquad\det M=1.
\]

They therefore isolate each BRC channel exactly over the rationals. Integer multiples clear the (nonzero integer) underlying base-history weights; the verifier constructs integer *signed* multiplicities, then splits positive and negative coefficients into two legitimate nonnegative path multisets. In the DFA state axis, take the three differences

\[
\begin{aligned}
\Delta_A&=\delta_{20}-\delta_{10},\\
\Delta_B&=\delta_{02}-\delta_{01},\\
\Delta_{AB}&=\delta_{00}-\delta_{20}-\delta_{02}+\delta_{22}.
\end{aligned}
\]

Each is annihilated by `1,u_A,u_B`, hence after every nonempty `c/d` word; any word containing `a/b` has nonzero final displacement and produces zero. Conversely ε reports, respectively, a change in `F_A`, `F_B`, and the joint `F_AF_B` not generated by future-only rows. Their ε-tag vectors in tag order `00,01,10,11` are `(-1,0,1,0)`, `(-1,1,0,0)`, `(1,-1,-1,1)`; three directions × three typed channels are independent. (Scaling the two weighted types by 324 makes all coefficients integers.) This is a **true-path lower bound**, not a free formal-state postulate. ∎

**Minimal retention corollary.** At current history length meeting the above bound, a future-only joint right-shift forgets exactly nine independent rational-linear coordinates. Supplementing *future observations* by the current zero-displacement, typed readouts `F_A`, `F_B`, and `F_AF_B` (three per BRC channel) recovers the whole `O_{h+1}^ε` state; fewer than nine additional independent rational scalars cannot do so. The full twelve ε tag coordinates are redundant relative to the retained future observation rows. This is an interface-specific **one-step loss repair**; it does not establish a fixed-dimensional state for indefinitely many rolling steps.

## Executed verification and exact boundary

`VERIFY_EC49CP.py` uses standard-library modular elimination over `F_1000003` on the reachable eight-state operation maps and exact integer literal X6 path evaluation. It checks all formula coordinates for `h=1,...,12`, including all four single-prefix ranks, identifies the nine-dimensional deficit **only at displacement zero**, and independently evaluates nine concrete signed-history differences across **all 1,364 distinct suffix words of lengths 1..5 each** (12,276 per-witness/word checks). The nine ε-vectors have the declared rank. The native `EC49CI` BRC `endpoint_weight` and `endpoint_multiplicity` functions were actually loaded; all length-0/2/4 zero-return aggregates matched exhaustive literal signed-step enumeration.

Observed rank samples `(h, D_{h+1}, D_{h+1}+9, rank joint future, kernel)`:

| h | old full | ε full | future rank | kernel |
|---:|---:|---:|---:|---:|
|1|81|90|81|9|
|3|231|240|231|9|
|6|591|600|591|9|
|12|1797|1806|1797|9|

Run in the checked-out PR branch:

```bash
python research_notes/r4_ec49as_exact_right_neighborhood_20261030/EC49CP_EPSILON_OBSERVER/VERIFY_EC49CP.py --max-h 12 --literal-h 5
```

The script reads the *already published* `../EC49CI_OPERATION_CLOSURE/native_signed_brc.py`; its fallback `source/native_signed_brc.py` is only for the bundled standalone evidence archive. Outputs are `EXACT_REPORT_EC49CP.json` and standard output. The report preserves actual ranks, nine literal witnesses, normalization and native BRC cross-check aggregates. All calculations are exact integers or modular prime-field arithmetic. Finite checks **corroborate** the separate all-h rank proof, rather than being its justification. Quantifiers concern this declared four-operation language; an expanded operation set, a mid-operation native observation, phase amplitudes or an alternative observer requires a fresh rank calculation.

## Literature and novelty boundary

The general relation between weighted automaton realizations and Hankel row rank is classical: Fliess (1974), explained by Nathanaël Fijalkow (2018-04-12), <https://games-automata-play.github.io/blog/fliess_theorem/>. The cited connection is **background**, not a proof of the present six-axis positive-BRC fiber ranks. Balle–Panangaden–Precup, *A Canonical Form for Weighted Automata and Applications to Approximate Minimization*, arXiv:1501.06841 (2015), <https://arxiv.org/abs/1501.06841>, is relevant to weighted automaton minimization but does not establish this exact observer-specific kernel claim. A comprehensive novelty search is pending. No physical-time, native heartbeat law or novel physics is claimed.

## Permission, durable status and next mathematical unit

This is an **original author-side portable analysis**, not a canonical Result, Driver review, accepted theorem, activity authorization, or an active formal CLAIM. The native adapter reported `research_authority_granted=false` and active-job quota `5/5` at its 2026-10-31T13:31Z status read. Canonical owner/claim could not be verified from that status alone; native activity/CLAIM writes were not attempted. The source-PR branch stores a readback-verifiable original author proof and executable evidence; formal `REGISTER_PENDING / UNREVIEWED / NOT_ADMITTED` remains.

**Next EC49CQ:** allow either (i) fixed non-origin readout after the first primitive step *inside* `c,d`, or (ii) one additional native signed two-step operation with a different displacement, and derive the **exact new joint rolling kernel** on every affected X6 displacement fiber. First test whether any previously invisible d=0 current ε contrasts become distinguishable *after* an allowed future operation; if so, exhibit an actual path pair and the smallest new observer set. Keep positive branch-counting, phase and physical-time claims separate.
