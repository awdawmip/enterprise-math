#!/usr/bin/env python3
"""EC49CP: exact epsilon-observer rolling-kernel audit for native X6 signed BRC.

Scope: formal reachable 8-state A/B automaton, four original complete operations
(a,b,c,d), 3 typed BRC channels; real positive-weight paths for witnesses.
Ranks use finite-field arithmetic F_1000003, and literal observations use
arbitrary-precision integers. Analytic all-h proof lives in README_EC49CP.md.
"""
from __future__ import annotations
import argparse
import importlib.util
import itertools
import json
from collections import defaultdict
from functools import reduce
from math import lcm
from pathlib import Path

PRIME = 1000003
STATES = tuple((a,b) for a in range(3) for b in range(3) if (a,b)!=(1,1))
OPS = {'a':(-1,-1),'b':(-2,-2),'c':(1,2,-1,-2),'d':(2,1,-2,-1)}
W0 = (2,3,3,2,1,1)
W1 = (3,2,3,2,1,1)
ONE = (1,1,1,1,1,1)


def step(q,x):
    a,b=q
    if a != 2:
        a=2 if a==1 and x==2 else (1 if x==1 else 0)
    if b != 2:
        b=2 if b==1 and x==1 else (1 if x==2 else 0)
    return a,b


def run(q, steps):
    for s in steps:
        q=step(q,s)
    return q


def label(q):
    return 2*int(q[0]==2)+int(q[1]==2)


def displacement(steps):
    d=[0]*6
    for x in steps:
        d[abs(x)-1]+=1 if x>0 else -1
    return tuple(d)


def weight(steps):
    w0=w1=1
    for x in steps:
        if x>0:
            w0*=W0[x-1]
            w1*=W1[x-1]
    return w0,w1,1


def observe_steps(steps):
    """Return tag-by-typed-channel 4x3 tuple; zeros if endpoint not origin."""
    t=[[0,0,0] for _ in range(4)]
    if not any(displacement(steps)):
        t[label(run((0,0),steps))]=list(weight(steps))
    return tuple(tuple(v) for v in t)


def rank_mod(rows):
    piv={}
    for row in rows:
        r=[x%PRIME for x in row]
        for j,v in sorted(piv.items()):
            if r[j]:
                c=r[j]
                r=[(x-c*y)%PRIME for x,y in zip(r,v)]
        j=next((i for i,x in enumerate(r) if x),None)
        if j is not None:
            inv=pow(r[j],-1,PRIME)
            piv[j]=[(inv*x)%PRIME for x in r]
    return len(piv)


IDENTITY=tuple(range(len(STATES)))
OP_MAP={name:tuple(STATES.index(run(q,steps)) for q in STATES) for name,steps in OPS.items()}


def map_append(m,x):
    r=OP_MAP[x]
    return tuple(r[q] for q in m)


def maps_by_length(H):
    result=[{(0,0,IDENTITY)}]
    for k in range(H):
        result.append({(i+int(x=='a'),j+int(x=='b'),map_append(m,x))
                       for i,j,m in result[-1] for x in OPS})
    return result


def grouped_rank(maps):
    groups=defaultdict(set)
    for i,j,m in maps:
        tags=[label(STATES[v]) for v in m]
        for k in range(4):
            groups[(i,j)].add(tuple(int(tag==k) for tag in tags))
    return {f:rank_mod(rows) for f,rows in groups.items()}


def sum_rank(maps):
    return 3*sum(grouped_rank(maps).values())


def epsilon_audit(h):
    bylen=maps_by_length(h+1)
    full_nonempty=set().union(*bylen[1:])
    full_with_epsilon=full_nonempty|bylen[0]
    per={}
    for x in OPS:
        src=OP_MAP[x]
        per[x]={(i+int(x=='a'),j+int(x=='b'),tuple(m[src[k]] for k in range(8)))
                for length in range(h+1) for i,j,m in bylen[length]}
    future=set().union(*per.values())
    N=(h+1)*(h+2)//2
    D=3*(3*(h+1)**2+7*(h+1)+1)
    predicted={
        'full_nonempty':D,
        'full_with_epsilon':D+9,
        'future_all_four':D,
        'T_a':12*N,'T_b':12*N,'T_c':6*N,'T_d':6*N,
    }
    actual={
        'full_nonempty':sum_rank(full_nonempty),
        'full_with_epsilon':sum_rank(full_with_epsilon),
        'future_all_four':sum_rank(future),
        **{'T_'+x:sum_rank(per[x]) for x in OPS}
    }
    assert actual==predicted,(h,actual,predicted)
    f_aug=grouped_rank(full_with_epsilon)
    f_future=grouped_rank(future)
    deficits={str(k):3*(v-f_future.get(k,0)) for k,v in f_aug.items() if v!=f_future.get(k,0)}
    assert deficits=={'(0, 0)':9},(h,deficits)
    oldf=grouped_rank(full_nonempty)
    extra={str(k):3*(v-oldf.get(k,0)) for k,v in f_aug.items() if v!=oldf.get(k,0)}
    assert extra=={'(0, 0)':9},(h,extra)
    # Kernel of full future + exact epsilon readout is identically zero because
    # its row set equals the augmented observation row set.
    return {
      'h':h,'triangular_N_h':N,'predicted_ranks':predicted,'measured_ranks':actual,
      'rolling_joint_kernel':actual['full_with_epsilon']-actual['future_all_four'],
      'new_epsilon_dimensions_by_fiber':extra,
      'lost_future_dimensions_by_fiber':deficits,
      'unit_observer_rank':sum_rank(bylen[0]),
      'distinct_maps_by_length':[len(r) for r in bylen],
    }


# Six real, closed, eight-step historical exemplars.
BASIS={
 '00':(3,-3)*4,
 '20':(1,2,-1,-2)+(3,-3)*2,
 '02':(2,1,-2,-1)+(3,-3)*2,
 '22':(1,2,-1,-2,2,1,-2,-1),
 '01':(3,-3)*3+(-2,2),
 '10':(3,-3)*3+(-1,1),
}
STATE_ID={'00':(0,0),'20':(2,0),'02':(0,2),'22':(2,2),'01':(0,1),'10':(1,0)}
DELTA={
 'A_completion':{'20':1,'10':-1},
 'B_completion':{'02':1,'01':-1},
 'joint_AB':{'00':1,'20':-1,'02':-1,'22':1},
}
COEFF={0:(-1,0,1),1:(0,-1,1),2:(3,3,-5)}
LOOP_AXES=(1,2,3)


def witness_rows():
    for k,steps in BASIS.items():
        assert len(steps)==8 and not any(displacement(steps))
        assert run((0,0),steps)==STATE_ID[k],(k,steps,run((0,0),steps))
    scale={t:lcm(*(weight(BASIS[k])[t] for k in BASIS)) if t<2 else 1 for t in range(3)}
    output={}
    for t in range(3):
        for name,d in DELTA.items():
            rows=[]
            for q,sign in d.items():
                f=scale[t]//weight(BASIS[q])[t] if t<2 else 1
                for axis,c in zip(LOOP_AXES,COEFF[t]):
                    if c:
                        steps=(axis,-axis)+BASIS[q]
                        assert len(steps)==10 and not any(displacement(steps))
                        assert run((0,0),steps)==STATE_ID[q]
                        rows.append((sign*f*c,steps))
            output[(t,name)]=rows
    return output,scale


def verify_witnesses(max_suffix_length):
    pairs,scales=witness_rows()
    result={}
    for (typ,name),rows in pairs.items():
        by_eps=[[0,0,0] for _ in range(4)]
        for c,path in rows:
            tag=label(run((0,0),path))
            for z,v in enumerate(weight(path)):
                by_eps[tag][z]+=c*v
        expected=[0,0,0,0]
        for q,d in DELTA[name].items():
            expected[label(STATE_ID[q])]+=d*scales[typ]
        for tag in range(4):
            for z in range(3):
                assert by_eps[tag][z]==(expected[tag] if z==typ else 0), (typ,name,by_eps)
        # Exhaustive literal check; appended words are raw signed steps, not a DFA shortcut.
        checked=0
        for length in range(1,max_suffix_length+1):
            for word in itertools.product(OPS, repeat=length):
                suffix=tuple(s for x in word for s in OPS[x])
                summed=[[0,0,0] for _ in range(4)]
                for c,path in rows:
                    observed=observe_steps(path+suffix)
                    for tag in range(4):
                        for ch in range(3):
                            summed[tag][ch]+=c*observed[tag][ch]
                assert not any(v for tag in summed for v in tag),(typ,name,word,summed)
                checked+=1
        result[f'{name}:channel_{typ}']={
           'epsilon_four_labels_in_selected_channel':expected,
           'epsilon_full_4_by_3':by_eps,
           'literal_signed_histories':len(rows),
           'positive_multiset_path_count':sum(c for c,_ in rows if c>0),
           'negative_multiset_path_count':-sum(c for c,_ in rows if c<0),
           'future_words_checked':checked,
        }
    return {'normalization_scales':scales,'nine_real_path_kernel_witnesses':result,
            'h_max_literal_checked':max_suffix_length}


def crosscheck_native_brc(source_file):
    """Compare per-path integer branch enumeration to original native BRC kernel."""
    spec=importlib.util.spec_from_file_location('native_signed_brc',source_file)
    native=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    report={}
    for n in (0,2,4):
        actual=[0,0,0]
        for steps in itertools.product(tuple(range(1,7))+tuple(-i for i in range(1,7)),repeat=n):
            if not any(displacement(steps)):
                v=weight(steps)
                actual=[a+b for a,b in zip(actual,v)]
        expect=[int(native.endpoint_weight(n,(0,)*6,W0,ONE)),
                int(native.endpoint_weight(n,(0,)*6,W1,ONE)),
                native.endpoint_multiplicity(n,(0,)*6)]
        assert actual==expect,(n,actual,expect)
        report[str(n)]={'native_BRC_endpoint':[str(v) for v in expect],
                        'literal_enumeration':[str(v) for v in actual]}
    return report


def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('--max-h',type=int,default=10)
    cli.add_argument('--literal-h',type=int,default=5)
    source_in_pr=Path(__file__).resolve().parent.parent/'EC49CI_OPERATION_CLOSURE'/'native_signed_brc.py'
    local_evidence=Path(__file__).resolve().parent/'source'/'native_signed_brc.py'
    cli.add_argument('--source',default=str(source_in_pr if source_in_pr.exists() else local_evidence))
    cli.add_argument('--output',default=str(Path(__file__).with_name('EXACT_REPORT_EC49CP.json')))
    args=cli.parse_args()
    results=[epsilon_audit(h) for h in range(1,args.max_h+1)]
    rw=verify_witnesses(args.literal_h)
    audit=crosscheck_native_brc(args.source)
    report={'schema':'EC49CP_EPSILON_ROLLING_KERNEL_AUDIT_V1',
      'scope':'native signed X6, two positive BRC weight instruments and count, eight reachable DFA states; four exact suffix ops',
      'prime':PRIME,'results':results,'literal_witness':rw,'original_native_BRC_crosscheck':audit,
      'limitations':'Modular ranks checked only over listed h. All-h ranks follow the separate analytic row-space proof. Real path witness is difference of two nonnegative path multisets, not phase cancellation. h-window model is not native physical-time evolution.'}
    with open(args.output,'w',encoding='utf-8') as f:json.dump(report,f,ensure_ascii=False,indent=2)
    print('EC49CP PASS; h 1..',args.max_h,'eps new +9, combined rolling kernel 9 in every case')
    print('Literal native witness: 9 independent type/label directions, suffixes 1..',args.literal_h,
          'of',sum(4**j for j in range(1,args.literal_h+1)),'words each')
    print('Native BRC aggregate cross-check length 0,2,4 PASS')
    print('Report:',args.output)

if __name__=='__main__':main()
