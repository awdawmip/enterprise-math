#!/usr/bin/env python3
"""Author-side EC49FKA R7 B14 retained-key native BRC exact certificate.
Uses frozen EC49FGW generator and FGJ A/B 94-edge witnesses.
Exact ordered, signed native microstep prefixes; full raw keys.
"""
import collections,itertools,json,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'EC49FJR'))
import EC49FGW_RADIUS5_SCREEN as g
B=14
PIN='fc0f038e7bfd12c886b4d37f900bfb770c0f61ab'
assert g.PIN==PIN

def min_family(masks):
    """Remove exact duplicates and supersets; mathematically sound domination."""
    out=[]
    for v in sorted(set(masks),key=lambda x:(x.bit_count(),x)):
        if any((old&v)==old for old in out): continue
        out.append(v)
    return out

def feas_union(options):
    """Return whether selections from each family can have union <= B."""
    st=[0]
    maxima=[]
    for opt in options:
        nxt={a|b for a in st for b in opt if (a|b).bit_count()<=B}
        if not nxt:return False,maxima
        st=min_family(nxt)
        maxima.append(len(st))
    return True,maxima

def solve(profile,catalog):
    rows,ps=g.validate_profile(profile)
    labels=tuple((d['window'],d['signature']) for d in rows)
    witnesskeys={g.raw_key(d['word']) for d in rows}
    bylab=collections.defaultdict(list)
    for lab,w in catalog:
        if g.raw_key(w) in witnesskeys:
            bylab[lab].append(frozenset(g.pref(w)))
    assert sum(map(len,bylab.values()))==9838
    support=collections.defaultdict(int);k_sup=collections.defaultdict(int)
    for i,d in enumerate(rows):
        k_sup[g.raw_key(d['word'])]|=1<<i
        for pr in ps[i]:support[pr]|=1<<i
    backgrounds=collections.defaultdict(list);released=0;allhist=collections.Counter()
    for Q in itertools.combinations(range(24),7):
        m=sum(1<<i for i in Q)
        if any(s&m==s for s in k_sup.values()):released+=1;continue
        removed=tuple(sorted(p for p,s in support.items() if s&m==s))
        allhist[len(removed)-1]+=1
        if len(removed)==B+1:backgrounds[removed].append(Q)
    assert released==192696 and len(backgrounds)==26
    assert sum(map(len,backgrounds.values()))==5890
    detail=[];certs=collections.Counter()
    for gid,(removed,Qs) in enumerate(sorted(backgrounds.items()),1):
        F=set(support)-set(removed)
        common=set.intersection(*({labels[i] for i in Q} for Q in Qs))
        assert len(common) in (4,5)
        choices={}
        # Key identity is retained by the 17 fixed words; eligible candidates are complete.
        for lab in sorted(common):
            choices[lab]=[x-F for x in bylab[lab] if len(x-F)<=B]
            assert choices[lab]
        # Restrict integer bits to this fixed background: no endpoint compression.
        universe=set().union(*(set(x) for sub in choices.values() for x in sub))
        index={p:i for i,p in enumerate(sorted(universe))}
        mask={}
        for lab in common:
            m=[]
            for s in choices[lab]:
                bit=0
                for p in s:bit|=1<<index[p]
                m.append(bit)
            mask[lab]=min_family(m)
        selected=None;max_states=[]
        for r in range(2,len(common)+1):
            for L in itertools.combinations(sorted(common),r):
                feasible,counts=feas_union([mask[lab] for lab in L])
                if not feasible:
                    selected=L;max_states=counts;break
            if selected:break
        detail.append({'group':gid,'contexts':len(Qs),'removed_prefix_count':len(removed),
                       'common_labels':[list(z) for z in sorted(common)],
                       'obstruction_labels':[list(z) for z in selected] if selected else [],
                       'arity':len(selected) if selected else None,
                       'raw_eligible_counts':{str(l):len(choices[l]) for l in sorted(common)},
                       'minimal_set_counts':{str(l):len(mask[l]) for l in sorted(common)},
                       'prefix_universe':len(index),'intermediate_antichain_states':max_states})
        if selected:certs[len(selected)]+=len(Qs)
        print(profile['profile_id'],gid,'contexts',len(Qs),'arity',len(selected) if selected else 'SURVIVE','counts',max_states,flush=True)
    return {'profile':profile['profile_id'],'b14_contexts':5890,'backgrounds':26,
            'counts_by_certificate_arity':dict(certs),
            'unresolved_contexts':5890-sum(certs.values()),
            'details':detail,
            'all_retained_budget_histogram':dict(sorted(allhist.items()))}

def main():
    t=time.time();catalog=list(g.all_words());assert len(catalog)==178850
    assert len({g.raw_key(w) for _,w in catalog})==94
    print('SOURCE',len(catalog),'legal BRC words, 94 keys, seconds',round(time.time()-t,2),flush=True)
    res=[solve(profile,catalog) for profile in g.W['profiles']]
    obj={'schema':'EC49FKA_R7_B14_AUTHOR_EXACT_CERTIFICATE_V1','frozen_pin':PIN,
         'source':'EC49FGW original generator and EC49FGJ frozen A/B witnesses',
         'legal_words':len(catalog),'raw_complete_keys':94,'budget_B':B,'profiles':res,
         'conclusion':'94 exactly for every B14 retained-key seven-position context' if all(r['unresolved_contexts']==0 for r in res) else 'partial',
         'time_seconds':round(time.time()-t,2)}
    (P/'EXACT_REPORT_EC49FKA.json').write_text(json.dumps(obj,indent=2)+'\n')
    print('SUMMARY',[(r['profile'],r['counts_by_certificate_arity'],r['unresolved_contexts']) for r in res],flush=True)
    if all(r['unresolved_contexts']==0 for r in res):print('EC49FKA_ALL_11780_EXACT_PASS',flush=True)

if __name__=='__main__':main()
