#!/usr/bin/env python3
"""Independent raw-catalogue literal-union finite check; no domination/antichain."""
import json,itertools,collections,time
from pathlib import Path
P=Path(__file__).parent; SRC=P/'EC49FJR'
B=14
j=json.loads((P/'EXACT_REPORT_EC49FKA.json').read_text())
witness=json.loads((SRC/'EC49FGJ_SEVEN_KEY_94_WITNESSES.json').read_text())
STEP={'a':(-1,-1),'c':(1,2,-1,-2),'d':(2,1,-2,-1),'e':(3,1,1,-3),'f':(1,-1),'g':(2,-2)}
def prefixes(word):
  out=set();t=()
  for op in word:
   for d in STEP[op]:
    t=t+(d,);out.add(t)
  return frozenset(out)
cat=collections.defaultdict(list)
for line in (SRC/'FJR_CATALOG.tsv').read_text().splitlines():
 h,s,x,y,z,w=line.split('\t');h,s,x,y,z=map(int,(h,s,x,y,z))
 assert len(w)==h
 cat[(h,s)].append(((x,y,z),prefixes(w)))
assert sum(map(len,cat.values()))==178850
res=[];tic=time.time()
for pinfo in j['profiles']:
 profile=next(pr for pr in witness['profiles'] if pr['profile_id']==pinfo['profile'])
 rows=sorted(profile['demands'],key=lambda d:(d['window'],d['signature']))
 label=[(d['window'],d['signature']) for d in rows]
 kp=[];ps=[]
 for d in rows:
  pp=prefixes(d['word']);ps.append(pp)
  k=(sum(sum(1 for z in STEP[c] if z==i) for c in d['word']) for i in (1,2,3))
  kp.append(tuple(k))
 support=collections.defaultdict(int);k_support=collections.defaultdict(int)
 for i,(s,k) in enumerate(zip(ps,kp)):
  for z in s:support[z]|=1<<i
  k_support[k]|=1<<i
 allprefix=set(support);bg=collections.defaultdict(list)
 for Q in itertools.combinations(range(24),7):
  mask=sum(1<<i for i in Q)
  if any(m&mask==m for m in k_support.values()):continue
  rem=frozenset(z for z,s in support.items() if s&mask==s)
  if len(rem)==B+1:bg[rem].append(Q)
 assert len(bg)==26 and sum(map(len,bg.values()))==5890
 allowed=set(kp)
 choices=collections.defaultdict(list)
 for lab,words in cat.items():
  for k,px in words:
   if k in allowed:choices[lab].append(px)
 for record,(removed,Qs) in zip(pinfo['details'],sorted(bg.items(),key=lambda x:tuple(sorted(tuple(z+4 for z in v) for v in x[0])))):
  # Group labels/ordering are reconciled below using their actual logical context;
  # tuple sign-encoding sort is consistent with original byte prefix order.
  assert len(Qs)==record['contexts']
  used=[tuple(x) for x in record['obstruction_labels']]
  assert all(set(used).issubset({label[i] for i in Q}) for Q in Qs)
  fixed=allprefix-removed
  states={frozenset()};running=[]
  for lab in used:
   opts=[px-fixed for px in choices[lab] if len(px-fixed)<=B]
   new=set()
   for a in states:
    for b in opts:
     union=a|b
     if len(union)<=B:new.add(union)
   running.append(len(new));states=new
   if not states:break
  assert not states,(pinfo['profile'],record['group'],record['obstruction_labels'])
  res.append({'profile':pinfo['profile'],'group':record['group'],'contexts':len(Qs),'arity':len(used),'direct_raw_union_states':running})
  print('DIRECT',pinfo['profile'],record['group'],len(Qs),'arity',len(used),'states',running,flush=True)
obj={'schema':'EC49FKA_INDEPENDENT_RAW_CATALOG_LITERAL_ENUM_V1','frozen_pin':j['frozen_pin'],'raw_catalogue_rows':178850,'budget':B,'certificates':res,'contexts_checked':sum(x['contexts'] for x in res),'seconds':round(time.time()-tic,2),'algorithm':'exact sets of literal signed native prefixes; literal union; exact duplicate elimination only; no antichain or endpoint quotient'}
assert len(res)==52 and obj['contexts_checked']==11780
(P/'EXACT_DIRECT_CHECK_EC49FKA.json').write_text(json.dumps(obj,indent=2)+'\n')
print('EC49FKA_DIRECT_ALL_11780_PASS',flush=True)
