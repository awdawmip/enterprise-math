#include <bits/stdc++.h>
using namespace std;
static const string letters="acdefg";
static const vector<vector<int>> steps={{-1,-1},{1,2,-1,-2},{2,1,-2,-1},{3,1,1,-3},{1,-1},{2,-2}};
struct Key {int h,u,v,w; bool operator<(const Key &t)const{return tie(h,u,v,w)<tie(t.h,t.u,t.v,t.w);}};
map<Key,map<int,pair<string,long long>>> agg;
vector<int> hist_p={0,1,2,0,2,0,1,0,0};
vector<int> hist_e={0,0,0,1,1,2,2,3,4};
long long word_count=0;
string word;
int n_a=0,n_c=0,n_d=0,n_e=0,n_f=0,n_g=0;
int signature(){
 int key=0, fact=1;
 for(int i=0;i<9;i++){
  int E=hist_e[i],p=hist_p[i];
  for(char ch:word){
   int j=letters.find(ch);
   for(int t:steps[j]){
    if(p==1&&t==2){if(E==0) E=1;else if(E==2) E=4;}
    else if(p==2&&t==1){if(E==0) E=2;else if(E==1) E=3;}
    p=t;
   }
  }
  key += E*fact; fact*=5;
 }
 return key;
}
void recurse(int depth){
 if(depth>=2&&n_e==n_a+1){
  int h=depth;
  int u=2*n_e+n_c+n_d+n_f, v=n_c+n_d+n_g,w=n_e;
  Key k{h,u,v,w}; int s=signature();
  cout<<h<<","<<u<<","<<v<<","<<w<<","<<s<<","<<word<<"\n";
  auto &m=agg[k]; auto it=m.find(s);
  if(it==m.end())m[s]={word,1};else{it->second.second++; if(word<it->second.first)it->second.first=word;}
  ++word_count;
 }
 if(depth==8)return;
 for(char ch:letters){
  switch(ch){case 'a':n_a++;break;case 'c':n_c++;break;case 'd':n_d++;break;case 'e':n_e++;break;case 'f':n_f++;break;case 'g':n_g++;break;}
  word.push_back(ch);recurse(depth+1);word.pop_back();
  switch(ch){case 'a':n_a--;break;case 'c':n_c--;break;case 'd':n_d--;break;case 'e':n_e--;break;case 'f':n_f--;break;case 'g':n_g--;break;}
 }
}
int main(){cout<<"h,u,v,w,sig,word\n";recurse(0);cerr<<"returning words: "<<word_count<<", groups "<<agg.size()<<"\n";}
