"""EC49CQ exact native X6/BRC certificate: a new net-positive operation and the nine transient dimensions.

Uses the signed-X6, strictly positive, path-product BRC instruments of native_signed_brc.py.
No conventional trigonometric, floating-point, phase-cancellation, or physics propagation calculations.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from fractions import Fraction
from itertools import permutations, product
import json
from pathlib import Path
from native_signed_brc import endpoint_multiplicity, endpoint_weight

WP=((2,3,3,2,1,1),(3,2,3,2,1,1))
WM=(1,1,1,1,1,1)
STATES=tuple((a,b) for a in range(3) for b in range(3) if (a,b)!=(1,1))
S={'a':(-1,-1),'b':(-2,-2),'c':(1,2,-1,-2),'d':(2,1,-2,-1)}
E=(3,1,1,-3)  # new operation +E3,+E1,+E1,-E3: net +2E1
EA=E+S['a']
Q6=((0,0),(0,1),(0,2),(1,0),(2,0),(2,2))
PREFIX=((1,-1),(2,-2),(3,-3))
ISOLATORS=((-1,0,1),(0,-1,1),(3,3,-5))
KERNEL_DIRECTIONS=(
    {(2,0):1,(1,0):-1},
    {(0,2):1,(0,1):-1},
    {(0,0):1,(2,0):-1,(0,2):-1,(2,2):1}
)

def step(state,x):
    a,b=state
    if a!=2: a=2 if a==1 and x==2 else (1 if x==1 else 0)
    if b!=2: b=2 if b==1 and x==1 else (1 if x==2 else 0)
    return (a,b)

def run(state,word):
    for x in word: state=step(state,x)
    return state

def disp(word):
    z=[0]*6
    for x in word: z[abs(x)-1] += 1 if x>0 else -1
    return tuple(z)

def mult(word):
    r=[1,1,1]
    for x in word:
        if x>0:
            r[0]*=WP[0][x-1]
            r[1]*=WP[1][x-1]
    return tuple(r)

def obs(word):
    # Every primitive native signed step contributes its declared positive BRC factor.
    # This path-by-path product is the exact ordered-branch summand of endpoint_weight.
    ret=[[0]*3 for _ in range(4)]
    if any(disp(word)):
        return tuple(tuple(x) for x in ret)
    a,b=run((0,0),word)
    tag=2*int(a==2)+int(b==2)
    ret[tag]=list(mult(word))
    return tuple(tuple(x) for x in ret)

def row(word,tag,qs=STATES):
    return tuple(int(2*int(run(q,word)[0]==2)+int(run(q,word)[1]==2)==tag) for q in qs)

def det(mat):
    n=len(mat)
    a=[[Fraction(v) for v in row] for row in mat]
    assert all(len(row)==n for row in a)
    result=Fraction(1)
    for j in range(n):
        k=next((k for k in range(j,n) if a[k][j]!=0),None)
        if k is None:return 0
        if k!=j:a[k],a[j]=a[j],a[k];result=-result
        t=a[j][j];result*=t
        for i in range(j+1,n):
            z=a[i][j]/t
            if z:
                for u in range(j,n):a[i][u]-=z*a[j][u]
    assert result.denominator==1
    return int(result)

def rank(rows):
    basis=[]
    for row in rows:
        r=[Fraction(v) for v in row]
        for j,b in basis:
            if r[j]:
                a=r[j];r=[x-a*y for x,y in zip(r,b)]
        k=next((j for j,z in enumerate(r) if z),None)
        if k is not None:
            d=r[k];r=[z/d for z in r]
            basis.append((k,r))
            basis.sort(key=lambda t:t[0])
    return len(basis)

def signed_witness(type_idx,direction_idx,bases):
    coeff=defaultdict(int)
    for q,qv in KERNEL_DIRECTIONS[direction_idx].items():
        for prefix,pv in zip(PREFIX,ISOLATORS[type_idx]):
            coeff[prefix+bases[q]]+=qv*pv
    plus=sorted((list(w),v) for w,v in coeff.items() if v>0)
    minus=sorted((list(w),-v) for w,v in coeff.items() if v<0)
    assert plus and minus
    assert all(len(x)==10 for x,_ in plus+minus)
    return (plus,minus)

def aggregate(side,suffix=()):
    r=[[0]*3 for _ in range(4)]
    for p,v in side:
        q=obs(tuple(p)+suffix)
        for tag in range(4):
            for t in range(3):r[tag][t]+=v*q[tag][t]
    return tuple(tuple(x) for x in r)

def difference(witness,suffix=()):
    p=aggregate(witness[0],suffix);q=aggregate(witness[1],suffix)
    return tuple(tuple(a-b for a,b in zip(r,s)) for r,s in zip(p,q))

def run_check(max_h):
    assert disp(E)==(2,0,0,0,0,0) and disp(EA)==(0,)*6
    assert mult(EA)==(12,27,1)
    assert all(row(EA,t)==row((),t) for t in range(4))
    old_rows=[row(S[c],tag) for c in 'cd' for tag in range(4)]
    epsilon_rows=[row((),tag) for tag in range(4)]
    old_rank=rank(old_rows)
    old_with_current_rank=rank(old_rows+epsilon_rows)
    assert old_rank==3 and old_with_current_rank==6
    short_compensation_rank=rank(old_rows+[row((1,1)+S['a'],tag) for tag in range(4)])
    selected_compensation_rank=rank(old_rows+[row(EA,tag) for tag in range(4)])
    assert (short_compensation_rank,selected_compensation_rank)==(5,6)
    actual_determinant=det([row((),tag,Q6) for tag in range(4)]+[row(S['c'],2,Q6),row(S['d'],1,Q6)])
    assert actual_determinant==-1
    # All actual length-8 bases have the same signed-axis inventory and BRC weights.
    tokens=(1,1,2,-1,-1,-2,3,-3)
    bases={}
    for word in sorted(set(permutations(tokens))):
        q=run((0,0),word)
        if q in Q6 and q not in bases:bases[q]=word
        if len(bases)==len(Q6):break
    assert set(bases)==set(Q6)
    assert all(disp(p)==(0,)*6 and mult(p)==(36,54,1) and run((0,0),p)==q for q,p in bases.items())
    witnesses=[]
    expected_patterns=((-1,0,1,0),(-1,1,0,0),(1,-1,-1,1))
    scale=(36*12,54*27,1)
    for t in range(3):
        for k in range(3):
            w=signed_witness(t,k,bases)
            assert any(x!=0 for r in difference(w) for x in r)
            got=difference(w,EA)
            expected=tuple(tuple(expected_patterns[k][i]*scale[t] if j==t else 0 for j in range(3)) for i in range(4))
            assert got==expected,(t,k,got,expected)
            witnesses.append({'type':t,'kernel_direction':k+1,
                              'positive_paths':w[0],'negative_paths':w[1],
                              'epsilon_difference':[list(row) for row in difference(w)],
                              'ea_difference':[list(row) for row in got],
                              'total_positive_multiplicity':sum(v for p,v in w[0]),
                              'total_negative_multiplicity':sum(v for p,v in w[1])})
    num_words=0
    for j in range(1,max_h+1):
        for suffix_letters in product('abcd',repeat=j):
            suffix=sum((S[x] for x in suffix_letters),())
            for witness in witnesses:
                wi=(witness['positive_paths'],witness['negative_paths'])
                got=difference(wi,suffix)
                assert all(all(x==0 for x in tag) for tag in got),(j,suffix_letters,witness['type'],witness['kernel_direction'],got)
            num_words+=1
    # A new positive-displacement operation probes source states entirely absent from old observer.
    p=(-1,-1);q=(3,3)
    assert all(x==0 for r in obs(p) for x in r)
    assert all(x==0 for r in obs(q) for x in r)
    assert obs(p+E)==((12,27,1),(0,0,0),(0,0,0),(0,0,0))
    assert all(x==0 for r in obs(q+E) for x in r)
    # Actual preexisting native kernel's endpoint sums: explicit enumeration at n=0,2,4.
    native_checks=[]
    for n in (0,2,4):
        totals=[0,0,0]
        for word in product(tuple(range(1,7))+tuple(range(-1,-7,-1)),repeat=n):
            v=obs(word)
            for t in range(3):totals[t]+=sum(row[t] for row in v)
        exact=[endpoint_weight(n,(0,)*6,WP[t],WM) for t in range(2)]+[endpoint_multiplicity(n,(0,)*6)]
        assert all(x.denominator==1 and x==y for x,y in zip(exact,totals))
        native_checks.append({'n':n,'native_and_ordered_branch_totals':totals})
    # 3 labelled tags per instrument constitute a 9x9 block-diagonal inverse kernel certificate.
    tag_minor=((0,1,-1),(1,0,-1),(0,0,1))  # rows: 01,10,11; columns: k1,k2,k3
    det3=det(tag_minor)
    assert det3==-1
    det9=(det3**3)*(scale[0]*scale[1]*scale[2])**3
    assert det9!=0
    return {'research_unit':'EC49CQ','max_h_literal':max_h,'suffix_words_checked':num_words,
            'witness_comparisons_checked':num_words*len(witnesses),
            'native_source_git_blob':'300a96e3dc24bf6fff73743037a0347a8bc83176',
            'old_origin_per_type_future_rank':old_rank,'old_origin_per_type_epsilon_augmented_rank':old_with_current_rank,
            'six_by_six_observer_determinant':actual_determinant,
            'shortest_len2_net_plus2E1_compensated_rank_per_type':short_compensation_rank,
            'selected_len4_net_plus2E1_compensated_rank_per_type':selected_compensation_rank,
            'nine_by_nine_witness_minor_determinant':str(det9),
            'new_operation':list(E),'net_displacement_e':list(disp(E)),
            'recovering_word_e_then_a':list(EA),'recovering_word_weights':list(mult(EA)),
            'base_states_and_words':{str(q):list(bases[q]) for q in Q6},
            'witnesses':witnesses,
            'nonfactorization_p':list(p),'nonfactorization_q':list(q),
            'nonfactorization_p_then_e': [list(x) for x in obs(p+E)],
            'nonfactorization_q_then_e':[list(x) for x in obs(q+E)],
            'native_checks':native_checks}

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--max-h',type=int,default=5)
    ap.add_argument('--output',default='EXACT_REPORT_EC49CQ.json')
    args=ap.parse_args()
    assert 1<=args.max_h<=8
    result=run_check(args.max_h)
    Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('PASS',json.dumps({k:result[k] for k in ('research_unit','max_h_literal','suffix_words_checked','witness_comparisons_checked','old_origin_per_type_future_rank','old_origin_per_type_epsilon_augmented_rank','six_by_six_observer_determinant','shortest_len2_net_plus2E1_compensated_rank_per_type','selected_len4_net_plus2E1_compensated_rank_per_type','nine_by_nine_witness_minor_determinant','recovering_word_weights','native_checks')}))
