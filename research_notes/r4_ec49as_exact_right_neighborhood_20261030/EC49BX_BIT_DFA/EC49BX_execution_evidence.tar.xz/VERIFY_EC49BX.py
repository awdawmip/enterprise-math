"""Exact signed-X6 BRC certificate: bit cost, integer DP and fixed-DFA rank.

Scope: positive rational step weights; integer multiplicities; ordered signed-X6
paths. No dynamics, complex amplitudes, or external scientific calibration.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from fractions import Fraction
from itertools import product
from math import comb, lcm
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "source" / "signed_brc.py"
data = SOURCE.read_bytes()
blob = hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()
assert blob == "300a96e3dc24bf6fff73743037a0347a8bc83176", blob
spec = importlib.util.spec_from_file_location("pinned_signed_brc", SOURCE)
assert spec and spec.loader
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)

WP = (Fraction(2), Fraction(3), Fraction(3), Fraction(2), Fraction(1), Fraction(1))
WM = (Fraction(1),) * 6
D = lcm(*(w.denominator for w in WP + WM))
CP = tuple(int(D*w) for w in WP)
CM = tuple(int(D*w) for w in WM)
Q = tuple(a*b for a,b in zip(CP, CM))


def signed_closed_paths(n):
    """Enumerate every ordered native six-axis zero-displacement path."""
    z = [0]*6
    a = [0]*n
    def rec(j):
        rem = n-j
        if sum(abs(v) for v in z) > rem:
            return
        if j == n:
            if all(v == 0 for v in z):
                yield tuple(a)
            return
        for i in range(6):
            for sg in (1,-1):
                z[i] += sg
                a[j] = sg*(i+1)
                yield from rec(j+1)
                z[i] -= sg
    yield from rec(0)


def orbit_weight(p):
    """Integer common-denominator numerator for a path, H=(1 2) orbit."""
    wa = wb = 1
    for step in p:
        ax = abs(step)-1
        sgn = step > 0
        wa *= CP[ax] if sgn else CM[ax]
        sax = 1-ax if ax in (0,1) else ax
        wb *= CP[sax] if sgn else CM[sax]
    return wa, wb


def signature(p):
    """Boolean observations: contains (+E1,+E2), contains (+E2,+E1)."""
    return (any(p[i:i+2] == (1,2) for i in range(len(p)-1)),
            any(p[i:i+2] == (2,1) for i in range(len(p)-1)))


def det(a,b):
    return a[0]*b[1]-a[1]*b[0]


def witness_rank_audit(n):
    states = {}
    count = 0
    total_weight = 0
    for p in signed_closed_paths(n):
        count += 1
        v = orbit_weight(p)
        total_weight += v[0]
        label = ''.join(str(int(x)) for x in signature(p))
        if label not in states:
            states[label] = [(p,v)]
        elif len(states[label]) == 1 and det(states[label][0][1],v):
            states[label].append((p,v))
    out = {}
    for label,seen in sorted(states.items()):
        row = {'rank':len(seen), 'witnesses':[]}
        for p,v in seen:
            row['witnesses'].append({'path':list(p),'weight_numerators':list(v)})
        if len(seen) == 2:
            row['determinant'] = det(seen[0][1], seen[1][1])
        out[label] = row
    assert count == native.endpoint_multiplicity(n,(0,)*6)
    assert Fraction(total_weight,D**n) == native.endpoint_weight(n,(0,)*6,WP,WM)
    return {'n':n,'native_path_count':count, 'native_total_weight_numerator':total_weight,
            'fixed_rank':sum(t['rank'] for t in out.values()),
            'covariant_rank':len(out), 'atoms':out}


def return_numerator_integer_dp(m, q):
    """T_j(m) integer BRC return weighted numerator, O(6 m^2) operations."""
    cur = [1] + [0]*m
    for qi in q:
        next_dp = [0]*(m+1)
        for ell in range(m+1):
            next_dp[ell] = sum(comb(2*ell, 2*k)*comb(2*k,k)
                               * qi**k * cur[ell-k] for k in range(ell+1))
        cur = next_dp
    return cur[m]


def run():
    audits = [witness_rank_audit(n) for n in (2,4,6)]
    assert (audits[0]['fixed_rank'],audits[0]['covariant_rank']) == (2,1)
    assert (audits[1]['fixed_rank'],audits[1]['covariant_rank']) == (4,3)
    assert (audits[2]['fixed_rank'],audits[2]['covariant_rank']) == (8,4)
    # Native source direct and exact integer recurrence agree for every m<=9.
    recurrence_checks = []
    for m in range(10):
        n = 2*m
        num = return_numerator_integer_dp(m,Q)
        native_value = native.endpoint_weight(n,(0,)*6,WP,WM)
        native_count = native.endpoint_multiplicity(n,(0,)*6)
        unweighted_count = return_numerator_integer_dp(m,(1,)*6)
        assert native_value == Fraction(num,D**n)
        assert native_count == unweighted_count
        assert 6**m <= native_count <= 12**(2*m)
        recurrence_checks.append({'n':n, 'weighted_brc':str(native_value),
                                  'unweighted_brc':native_count,
                                  'unweighted_bit_length':native_count.bit_length(),
                                  'weighted_common_denominator_numerator_bit_length':num.bit_length()})
    # Extend beyond direct native-composition audit to display bit-growth.
    large = []
    for m in (12,20,40,60,100):
        num = return_numerator_integer_dp(m, Q)
        unweighted = return_numerator_integer_dp(m,(1,)*6)
        large.append({'n':2*m,'unweighted_bits':unweighted.bit_length(),
                      'weighted_common_denominator_numerator_bits':num.bit_length(),
                      'integer_recurrence_only':True})
    # Each n=6 witness pair remains valid after any number of (+E3,-E3)
    # insertions at the end: signature and H action unaffected; weights x3.
    for label, row in audits[-1]['atoms'].items():
        assert row['rank']==2 and row['determinant'] != 0
        p1, p2 = (tuple(w['path']) for w in row['witnesses'])
        for loop_count in (1,2,3):
            tail = (3,-3)*loop_count
            assert signature(p1+tail) == signature(p1)
            assert signature(p2+tail) == signature(p2)
            assert det(orbit_weight(p1+tail),orbit_weight(p2+tail)) == row['determinant']*9**loop_count
    result = {
        'scientific_scope':'Native six-axis ordered signed zero-displacement words, positive rational BRC weights, auxiliary regular-language observations. Author-side evidence, not admission.',
        'pinned_native_git_blob_sha1':blob,
        'instrument':{'wp':[str(x) for x in WP], 'wm':[str(x) for x in WM], 'common_denominator':D, 'integer_q':list(Q)},
        'finite_dfa_certificate':{'H':['identity','swap_E1_E2'], 'word_A':[1,2], 'word_B':[2,1],
        'rank_upper_bound_all_even_n':8,'covariant_upper_bound_all_even_n':4,
        'analytic_saturation':'Exact 8 fixed / 4 covariant for every even n>=6, by length-6 witnesses and insertion (+E3,-E3).'},
        'witness_audits':audits,
        'direct_native_recurrence_checks':recurrence_checks,
        'large_integer_dp_checks':large,
        'bit_lower_bound':'6^m <= endpoint_multiplicity(2m,0) <= 12^(2m); explicit output bit length Theta(m).',
        'status':'EXACT_NATIVE_BRC_DIRECT_CHECK_AND_INTEGER_RECURRENCE_CHECK_PASS / AUTHOR_ANALYTIC_PROOF / UNREVIEWED / NOT_ADMITTED'}
    target=HERE/'EXACT_REPORT_EC49BX.json'
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps({'direct_native_checks':len(recurrence_checks), 'small_ranks':[
        {'n':a['n'],'fixed':a['fixed_rank'],'covariant':a['covariant_rank'],'count':a['native_path_count']}
        for a in audits], 'large_bits':large,
        'n6_witness_dets':{k:v['determinant'] for k,v in audits[-1]['atoms'].items()},
        'report_path':str(target)},ensure_ascii=False,sort_keys=True))

if __name__=='__main__':
    run()
