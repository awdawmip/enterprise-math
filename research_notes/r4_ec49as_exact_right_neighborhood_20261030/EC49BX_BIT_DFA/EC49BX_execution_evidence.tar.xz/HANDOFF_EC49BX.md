# EC49BX handoff — exact BRC bit resources and finite automaton rank

Status: author-side only; UNREVIEWED / NOT_ADMITTED; no native Claim/Result.
Input source pins (same turn): Global `e5b88cd1418df81a633a50542f6b02320475bb3e`; Enterprise Math `684a68342bf1321ba4ad33ea02b3e25f20d789e7`.
Predecessor: EC49BW PR #1730 commit `02058a5a9b561ecbe4c1f65602a425eced89b943`. Native signed_brc Git blob `300a96e3dc24bf6fff73743037a0347a8bc83176`.

Produced: PROOF_EC49BX.md (all proofs, exact eight-path witness table, quantified scopes); VERIFY_EC49BX.py (actual executed source); EXACT_REPORT_EC49BX.json (exact native and recurrence evidence). Native source file itself unchanged.

Proved: (i) arbitrary multiplicities defeat uniform exact numeral-bit bounds even at fixed path length; integer bags with max per-path multiplicity U have O(n+log U) exact numeral output for fixed positive rational weights, and the unit native closed-return aggregate has Theta(n) binary bits. (ii) integer six-axis closed-return recurrence with O(6m^2) arithmetic summands and exact native endpoint_weight bridge. (iii) one fixed DFA and finite H give a uniform |H||Q|^|H| rank bound. The two-pattern four-atom X6 example has exactly 8 fixed /4 covariant additive coordinates for all even n>=6 by 8 actual six-step witness paths and loop-extension proof.

Executed: complete closed words n=2,4,6; 10 direct comparisons recurrence↔native for n=0..18; integer recurrence for 24,40,80,120,200; t=1..3 loop checks. Exact witness determinants -180 each. Source-check Git blob verified. No physical dynamics, other endpoints, complex cancellation, arbitrary program decision or native Claim tested.

Next EC49BY: filtered BRC bit-operation cost as a function of fixed automaton / group size / n; source-side filters and native endpoint; compare full all-path computation and arbitrary sparse input bags, proving observability and representation lower bounds separately.
