#!/usr/bin/env python3
"""Exact rational regression for the source-sensitive serial-merger stopping model.
Finite tests below do not substitute for the all-real Bellman/Markovization proofs.
Only Python standard library Fraction is required.
"""
from fractions import Fraction as Q
from itertools import combinations, product

R = {-1: Q(1, 2), 0: Q(1), 1: Q(3, 2)}
L_PROB = {-1: Q(1, 3), 1: Q(1, 2)}
LEAF_R = {-1: Q(1, 4), 1: Q(2)}
STOP_ERROR = {-1: 1, 1: 0}
LEAF_ERROR = {-1: 0, 1: 1}


def qvector(a):
    assert Q(0) < a < Q(1, 2)
    return {-1: a, 0: 1-2*a, 1: a}


def observation(alpha, bits, lr=False):
    # q1 is half per origin under BOTH laws; 1 means CONTINUE.
    assert len(bits) == (4 if lr else 10)
    a1 = {i: bits[0] if lr else bits[i] for i in (0, 1)}
    a2 = {(i,j): bits[1+(j==1)] if lr else bits[2+2*i+(j==1)]
          for i in (0,1) for j in (-1,1)}
    a3 = {(i,j): bits[3] if lr else bits[6+2*i+(j==1)]
          for i in (0,1) for j in (-1,1)}
    ans = [Q(0)] * 4  # errorP,errorQ,timeP,timeQ
    totals = [Q(0),Q(0)]

    def terminal(q, ratio, t, err):
        p = q * ratio
        totals[0] += p
        totals[1] += q
        ans[0] += p*err
        ans[1] += q*err
        ans[2] += p*t
        ans[3] += q*t

    for i in (0,1):
        qi = Q(1,2)
        if not a1[i]:
            terminal(qi, Q(1), 1, 0)
            continue
        for j, qj in qvector(alpha[i]).items():
            q = qi*qj
            if j==0:
                terminal(q, Q(1), 2, 0)
            elif not a2[i,j]:
                terminal(q, R[j], 2, STOP_ERROR[j])
            else:
                terminal(q*(1-L_PROB[j]), LEAF_R[j], 3, LEAF_ERROR[j])
                qmerge=q*L_PROB[j]  # both origins and both routes reach LR=1
                terminal(qmerge, Q(1), 3+a3[i,j], a3[i,j])
    assert totals == [Q(1),Q(1)], totals
    return tuple(ans)


def det(mat):
    n=len(mat)
    assert all(len(row)==n for row in mat)
    a=[list(map(Q,row)) for row in mat]
    val=Q(1)
    for col in range(n):
        piv=next((r for r in range(col,n) if a[r][col]),None)
        if piv is None:
            return Q(0)
        if piv!=col:
            a[col],a[piv]=a[piv],a[col]
            val=-val
        factor=a[col][col]
        val*=factor
        for r in range(col+1,n):
            scale=a[r][col]/factor
            for k in range(col,n):
                a[r][k]-=scale*a[col][k]
    return val


def inverse(mat):
    n=len(mat)
    a=[list(map(Q,row))+[Q(int(r==c)) for c in range(n)]
       for r,row in enumerate(mat)]
    for col in range(n):
        piv=next((r for r in range(col,n) if a[r][col]),None)
        if piv is None:
            return None
        a[col],a[piv]=a[piv],a[col]
        scale=a[col][col]
        a[col]=[x/scale for x in a[col]]
        for row in range(n):
            if row==col:
                continue
            f=a[row][col]
            a[row]=[x-f*y for x,y in zip(a[row],a[col])]
    return [row[n:] for row in a]


def all_signed_hull_primal_certificates(full,lr):
    # A d=4 Caratheodory witness extends to an affinely independent 5-tuple
    # because the LR hull is full-dimensional; check all such 5-tuples exactly.
    bases=[]
    for subset in combinations(sorted(set(lr)),5):
        m=[[Q(1)]*5]+[[v[d] for v in subset] for d in range(4)]
        inv=inverse(m)
        if inv is not None:
            bases.append((subset,inv))
    assert bases
    result={}
    for v in sorted(set(full)):
        target=(Q(1),)+v
        for subset,inv in bases:
            w=[sum(inv[i][j]*target[j] for j in range(5)) for i in range(5)]
            if all(x>=0 for x in w):
                assert sum(w)==1
                assert all(sum(w[i]*subset[i][j] for i in range(5))==v[j] for j in range(4))
                result[v]=(subset,tuple(w))
                break
        else:
            raise AssertionError('Missing exact primal witness: '+str(v))
    return len(result),len(bases)


def run(a0,a1):
    alphas=(Q(a0),Q(a1))
    s=sum(alphas)/2
    full=[observation(alphas,b,False) for b in product((0,1),repeat=10)]
    lr=[observation(alphas,b,True) for b in product((0,1),repeat=4)]
    assert len(full)==1024 and len(lr)==16
    keypol=[(0,0,0,0),(1,0,0,0),(1,0,1,0),(1,0,1,1),(1,1,0,0)]
    v0=observation(alphas,keypol[0],True)
    cols=[tuple(x-y for x,y in zip(observation(alphas,k,True),v0)) for k in keypol[1:]]
    observed_det=det([[cols[col][row] for col in range(4)] for row in range(4)])
    expected_det=s**3*(s+4)/16
    assert observed_det==expected_det>0
    # Signed support is all-real; max over deterministic policies is exact
    # by multi-affinity of both policy observation maps.
    k=Q(3,4)+1/(2*s)
    def H(v):return k*v[1]-v[3]
    f_max=max(map(H,full))
    l_max=max(map(H,lr))
    assert k>Q(7,4)
    expected_gap=abs(alphas[0]-alphas[1])/(4*s)
    assert l_max==-1
    assert f_max==-1+expected_gap, (f_max,l_max,expected_gap)
    if a0==a1:
        certified,bases=all_signed_hull_primal_certificates(full,lr)
        assert certified==len(set(full))
        print('EQUAL',a0,a1,'full_unique',len(set(full)),'lr_unique',len(set(lr)),
              'primal_full_certificates',certified,'invertible_5vertex_bases',bases,
              'rank_minor',observed_det,'hull_gap',expected_gap)
    else:
        print('UNEQUAL',a0,a1,'full_unique',len(set(full)),'lr_unique',len(set(lr)),
              'rank_minor',observed_det,'signed_k',k,'full_support',f_max,
              'lr_support',l_max,'gap',expected_gap)
    return full,lr


def main():
    sample=run(Q(1,4),Q(1,8))
    # full maximizing source0 continues, source1 stops. Other irrelevant
    # FULL choices set to the common Bellman optimizers: D stop,Z continue,L continue.
    bits=(1,0,0,1,0,1,1,1,1,1)
    witness=observation((Q(1,4),Q(1,8)),bits,False)
    assert witness==(Q(1,4),Q(1,4),Q(7,4),Q(27,16)),witness
    H_int=lambda v:41*v[1]-12*v[3]
    assert H_int(witness)==-10
    assert max(H_int(v) for v in sample[1])==-12
    print('INTEGER_WITNESS','H=41eQ-12TQ','full_vector',witness,
          'full_support',-10,'lr_support',-12,'gap',2,
          'linf_distance_to_LR_CONVEX_HULL_at_least',Q(2,53))
    for a,b in [(Q(3,16),Q(3,16)),(Q(1,8),Q(1,8)),
                (Q(1,4),Q(1,4)),(Q(1,7),Q(2,7)),
                (Q(1,20),Q(9,20)),(Q(1,3),Q(1,10))]:
        run(a,b)
    print('PASS_EXACT_R5_POSITIVE_TWO_MERGER_SOURCE_RIGIDITY')

if __name__=='__main__':
    main()
