# R5 — Strictly positive two-law serial-merger rigidity, with an exact all-real support defect

**Author-side research, 2026-10-31 (Asia/Shanghai).** Status: `AUTHOR_PROVED / EXACT_FRACTION_CHECKED / UNREVIEWED / NOT_ADMITTED / PORTABLE_ONLY / REGISTER_PENDING`. This is a genuine finite two-measure stopping/continuation experiment, unlike the preceding abstract independent fifth-bypass monomial model. It is **not** a native Heartbeat/X6 realization or an accepted Source Task Result.

## Frozen provenance and scope

GLOBAL_KNOWLEDGE_V1 canonical `main@d171cc0e7df8db282f5eb9c40c67e55ce341488b` and Enterprise Math canonical `main@7a46ed70b59ca823805468daab0122ac0b230a20` were freshly inspected for this author turn. Apply `00_BOOTSTRAP.md`, `OPERATING_MANUAL.md`, the TASK researcher and project routes, P000 and protected ACTIVE worldview, the joint-observer information-preservation rule, and `docs/PORTABLE_RESEARCH_PROTOCOL.md`/`docs/AUTONOMOUS_RESEARCH_OPERATIONS.zh-CN.md`. Scientific predecessor: immutable `a7764f6d1e2b4f4f423c6dc0813e26f568fe60f4`, `research_notes/brc_r5_fifth_bypass_no_go_20261031_t1243/RESEARCH.md`. Neither predecessor nor P000/ACTIVE definitions have been rewritten. This research is an auxiliary probability model; no X6 embedding is inferred.

**Question.** Does a real, strictly positive source-sensitive second LR merger repair the all-signed FULL-vs-seedless-LR observer hull gap? This note builds an actual P/Q path model, proves an exact source-kernel classification over a continuous real parameter domain, and gives an explicit four-observer separation certificate. The answer for this entire model family is **no unless source kernels coincide**; when they coincide, actual observer sets also coincide, so neither case resolves the open mother target (equal full-dimensional convex hulls but different actual real behavioral observer sets).

## BRC positive path carrier and complete two-law construction

There are two hidden origins `i=0,1`, each having mass `Q_i=P_i=1/2` at stage `t=1`, with likelihood ratio `r=1`. Time is a separately typed discrete stopping stage, not a native spatial coordinate. At `t=1`, STOP produces `(time,error)=(1,0)`; CONTINUE branches at `t=2` to keys `D,C,Y` with LR ratios `(1/2,1,3/2)`. For arbitrary real `0<alpha_i<1/2`, conditional **Q** route probabilities are `(alpha_i,1-2 alpha_i,alpha_i)`, and the corresponding **P** probabilities are `(alpha_i/2,1-2 alpha_i,3 alpha_i/2)` (sum 1 under both laws). The route `C` is forced STOP at `t=2` with error 0. At `D` or `Y`, STOP at `t=2` produces error respectively 1 or 0; CONTINUE branches at `t=3` as follows:

| Parent LR at `t=2` | Q probability to common L (`LR=1`) | Q probability to residual terminal | Residual terminal LR | Terminal error | Terminal time |
|---|---:|---:|---:|---:|---:|
| `D`, `1/2` | `1/3` | `2/3` | `1/4` | 0 | 3 |
| `Y`, `3/2` | `1/2` | `1/2` | `2` | 1 | 3 |

The corresponding P transition probabilities from a parent of LR `r` to a child of LR `r'` are **exactly** `(r'/r) Q(child | parent)`. Thus `D: (P_L,P_residual)=(2/3,1/3)` and `Y: (P_L,P_residual)=(1/3,2/3)`. These pairs are strictly positive and sum to 1. Both routes and both origins reach the *same* stage-3 key `L=(3,LR=1)`: this is a real history-merging event downstream of the first origin collision. At L, STOP at `t=3` has error 0 and CONTINUE to `t=4` has error 1. That terminal move is deterministic conditional on the action. All natural positive branches have positive P and Q mass; decisions intentionally suppress unreachable branches, not violate natural-transition positivity.

For each origin, the five all-continue natural terminal subpaths have unconditional Q/P flows:

| Natural path at/beyond stage 2 | Q flow | P flow | LR |
|---|---:|---:|---:|
| `C` | `(1-2alpha_i)/2` | `(1-2alpha_i)/2` | 1 |
| `D -> L` | `alpha_i/6` | `alpha_i/6` | 1 |
| `D -> residual` | `alpha_i/3` | `alpha_i/12` | 1/4 |
| `Y -> L` | `alpha_i/4` | `alpha_i/4` | 1 |
| `Y -> residual` | `alpha_i/4` | `alpha_i/2` | 2 |

The Q and P flow sums are **each exactly 1/2 for each origin**, and every entry is strictly positive for the stated real domain. This table is the provenance-preserving BRC carrier before any reduction. Its route probability kernels have source variation `TV(Q_0,Q_1)=2|alpha_0-alpha_1|` at the first transition. This is a conditional-kernel TV, not a claim about a physical signal.

FULL can see the origin and full route history and randomize independently at every legal decision node. Seedless LR only sees `(t,P/Q)` and uses a separate real behavioral probability for each of the four decision keys: `A=(1,1),D=(2,1/2),Y=(2,3/2),L=(3,1)`. No persistent random seed or origin tag is supplied. Outputs are the **complete four-vector**

`O=(e_P,e_Q,T_P,T_Q)`, where `e_R=E_R[terminal error]` and `T_R=E_R[stop time]`, `R=P,Q`.

The experiment includes the two interacting collisions at `A` (distinct origins) and at `L` (both routes and origins). Every finite trajectory visits each decision key at most once. Therefore its observer map is multi-affine in its local behavioral action probabilities; FULL/LR convex hulls are exactly their deterministic-observer-vector hulls, for **all real behavioral policies**.

## THEOREM — exact all-real classification and full rank

For every pair of real parameters `alpha_0,alpha_1 in (0,1/2)` in the model just defined, set `s=(alpha_0+alpha_1)/2`. Then:

1. The seedless LR four-observer convex hull has full affine dimension four, with an explicit minor
   `det = s^3(s+4)/16 > 0`.
2. If `alpha_0 != alpha_1`, the FULL/LR four-observer convex hulls are **strictly different**. An exact signed support direction, allowed to depend on the fixed model parameters, is
   `H= k e_Q - T_Q`, `k=3/4 + 1/(2s) > 7/4`, with
   `max_FULL H - max_LR H = |alpha_0-alpha_1|/(4s) = TV(Q_0,Q_1)/(8s) > 0`.
3. If `alpha_0=alpha_1`, the **actual** real behavioral four-observer sets coincide and form the same convex polytope; their convex hulls coincide as well.

**Thus, for this entire two-real-parameter strict-positive serial-merger family, all-signed four-dimensional hull equality holds exactly when the source kernels coincide; in that case the actual images already agree.** This is a scoped no-go classification of this topology/terminal signature, not a universal claim over all coupled-merger stochastic systems.

### Proof of the support formula

For arbitrary fixed `s in (0,1/2)`, put `k=3/4+1/(2s)>7/4`. Under the signed terminal reward `k * error - stop_time`, the stage-3 L choice strictly prefers CONTINUE because `k-4 > -3`. At D, stopping yields `k-2`, while continuing yields `(2/3)(-3)+(1/3)(k-4)=k/3-10/3`; so D strictly prefers STOP. At Y, stopping yields `-2`, while continuing yields `(1/2)(k-3)+(1/2)(k-4)=k-7/2`; so Y strictly prefers CONTINUE. These same downstream optimizers work for every origin and for the seedless LR policy: the stage-2/3 reward and transition law depend only on the available LR route key.

If source `i` continues at A, its optimal conditional Q reward is

`C_i=alpha_i*(k-2)+(1-2alpha_i)*(-2)+alpha_i*(k-7/2)=-2+alpha_i*(2k-3/2)=-2+alpha_i/s`.

Stopping at A gives `-1`; hence the exact conditional advantage of CONTINUE is `B_i=alpha_i/s-1`. With equal initial weights 1/2, these satisfy `B_0+B_1=0`. FULL chooses the best of STOP/CONTINUE separately by origin, so `max_FULL H=-1+(1/2)(max(0,B_0)+max(0,B_1))=-1+|alpha_0-alpha_1|/(4s)`. LR has one shared action at A; its continuation advantage averages to zero, giving `max_LR H=-1`. The downstream choices already optimize sourcewise, so there is no hidden alternative policy that can improve these maxima. This proves the exact all-real gap. `H` is a **signed observer direction** applied after positive P/Q mass propagation, not an allowed negative probability.

### Proof of rank for every real parameter

LR actions are shared across origins; their four-observer vectors depend on `alpha_i` only through `s`, since the conditional output law following each route is origin-independent. Take the five deterministic LR policies in order of binary `(A,D,Y,L)` CONTINUE decisions:

`(0,0,0,0)`, `(1,0,0,0)`, `(1,0,1,0)`, `(1,0,1,1)`, `(1,1,0,0)`.

Their observer vectors, respectively, are

`v0=(0,0,1,1)`,
`v1=(s/2,s,2,2)`,
`v2=(3s/2,3s/2,(3s+4)/2,s+2)`,
`v3=(2s,2s,2s+2,(3s+4)/2)`,
`v4=(0,0,(s+4)/2,s+2)`.

The column matrix `[v1-v0,v2-v0,v3-v0,v4-v0]` has exact determinant `s^3(s+4)/16`. For every `0<s<1/2` this is positive, proving full affine dimension four (and no unexamined low-rank degeneration).

### Proof of actual-set equality when source kernels coincide

When `alpha_0=alpha_1`, the conditional Q next-key kernel and P likelihood-ratio transport are identical for histories with the same `(t,LR)` key at A, D, Y and L. In particular, L's entire terminal response is route/source independent, and the P action-key flow equals its Q flow times the current LR. Given any FULL real policy, sum its Q stop/continue flows over all histories sharing each `(t,LR)` key. Define a single seedless LR action probability as `Q_continue_flow / Q_total_key_flow` (arbitrary if the key has zero total flow). By induction in increasing stage, the LR policy reproduces every Q key/action flow and, because of the ratio relation and predictive key-kernel equality, every P key/action flow. It therefore reproduces all four observations, with the error terminal mark included at each typed transition. Conversely any LR policy is a FULL policy. The feasible finite-horizon Q key/action flow system has linear nonnegative conservation constraints, and the inverse flow-to-policy construction just given realizes every such flow. Its affine observer image is consequently a compact convex polytope. This proof covers **actual real behavioral policies**, not just deterministic hulls, and it is scoped to this equality case.

## Exact rational witness, distance, and executed checks

Choose `alpha_0=1/4`, `alpha_1=1/8`, `s=3/16`. Their route-kernel TV is `1/4`. The exact signed direction above is `k=41/12`, equivalently the integer direction `J=41e_Q-12T_Q`. FULL continues at A only for origin 0; at D it stops, at Y it continues, and at L it continues wherever reached (unreachable action values are immaterial). This legal FULL policy has

`M=(e_P,e_Q,T_P,T_Q)=(1/4,1/4,7/4,27/16)`.

Thus `J(M)=-10`, whereas the support supremum over **all real seedless LR** policies equals `-12`. In particular,

`M in conv(O_FULL) \ conv(O_LR)`, and

`dist_infinity(M, conv(O_LR)) >= 2/(|41|+|12|) = 2/53`.

This is stronger than exclusion from the nonconvex LR image; it proves the hull-equality target fails. The exact LR full-rank minor is `1809/1048576`.

`VERIFY.py` uses only Python's standard-library `Fraction`, exactly enumerates all `2^10=1024` FULL and `2^4=16` LR deterministic policies **for each specified rational input**, checks terminal P/Q masses, computes the exact signed supports and determinant, and tests additional rational pairs. In three equal-kernel cases it also constructs and verifies a nonnegative, sum-one, **at most five LR-vertex rational convex representation for every distinct FULL deterministic observation** (46 distinct FULL vectors each; 30 invertible LR five-vertex bases). This is an exact finite primal certificate for those test parameters, not the reason for the all-real Markovization theorem. The actual recorded standard output is `EXACT_OUTPUT.txt` with final line `PASS_EXACT_R5_POSITIVE_TWO_MERGER_SOURCE_RIGIDITY`.

## Limits, BRC reuse, and next discriminating question

Applied BRC interface: `REUSE_APPLIED` positive source-labelled P/Q path weights; exact RN likelihood transport; source-fiber TV as an observer defect; signed duality only at final observer. Information retained: origin, route, LR, stage, stop action and residual branch until projection to `(eP,eQ,TP,TQ)`. The complete native X6 transfer, whether this source discrepancy is physically realized, and independent mathematical review are **not established**. No native session, Source Task CLAIM, Result, independent Driver review, or Foundation promotion is asserted. Native service read-only status reported `research_authority_granted=false` with active-slot quota 5/5 and `CODE_REVIEW_REQUIRED` (2026-10-31 at observed service snapshot); only author-side artifact preservation is available here.

**Next problem:** Keep positive P/Q flows and the two serial collisions, but make the L terminal response **genuinely route-history dependent** while preserving LR collision, or add a second coupled reconvergence key. Seek a model where source kernels differ yet FULL/LR every-signed four-observer hulls coincide; require an exact at-most-five LR-vertex primal witness for each FULL deterministic observation (or Farkas separating direction). Only after confirmed full rank and hull equality attempt the strictly harder real LR-image nonmembership certificate. This note closes only the fully specified common-response family above.
