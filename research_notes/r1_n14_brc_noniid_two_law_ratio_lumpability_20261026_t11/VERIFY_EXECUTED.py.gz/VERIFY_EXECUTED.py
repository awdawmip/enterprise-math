#!/usr/bin/env python3
"""Exact rational two-law non-IID compression: obstructions and sufficient repair.
External auxiliary finite binary path models only. Standard library, no numerics.
"""
from fractions import Fraction as F
from itertools import product
from collections import defaultdict
import json

A = '01'

def words(n): return [''.join(v) for v in product(A, repeat=n)]
def count(h): return (h.count('0'),h.count('1'))

def initial(letter): return F(1,2)
def p_cond(h,a): return F(1,2)
def q_cond_a(h,a):
    if not h: return F(1,2)
    if h[-1]=='0': return F(1,4) if a=='0' else F(3,4)
    return F(1,2)
def q_cond_b(h,a):
    if not h: return F(1,2)
    return F(3,4) if a!=h[-1] else F(1,4)

def law_prob(h,law):
    ans=F(1)
    for i,a in enumerate(h): ans*=law(h[:i],a)
    return ans

def fstr(x): return f'{x.numerator}/{x.denominator}'

# Obstruction A: a genuine path-dependent Q with full support on binary depth-2 tree.
P01,P10=(law_prob(h,p_cond) for h in ('01','10'))
Q01,Q10=(law_prob(h,q_cond_a) for h in ('01','10'))
qP=P01/(P01+P10)
qQ=Q01/(Q01+Q10)
assert (P01,P10,Q01,Q10)==(F(1,4),F(1,4),F(3,8),F(1,4))
assert (qP,qQ)==(F(1,2),F(3,5)) and qP!=qQ
assert all(law_prob(h,q_cond_a)>0 for t in range(3) for h in words(t))
assert sum(law_prob(h,q_cond_a) for h in words(2))==1

# Obstruction B: LR itself is not a right-congruence, even under a genuine Markov Q.
R=lambda h: law_prob(h,q_cond_b)/law_prob(h,p_cond)
assert count('01')==count('10') and R('01')==R('10')==F(3,2)
assert R('011')==F(3,4) and R('101')==F(9,4)
assert sum(law_prob(h,q_cond_b) for h in words(4))==1

# Model B repair: signed prefix feature (number of symbol switches, last symbol).
def changes(h): return sum(h[i]!=h[i-1] for i in range(1,len(h)))
def state(h): return (count(h),changes(h),h[-1] if h else '_')
def transition(x,a):
    k,m,last=x
    j=ord(a)-48
    return (tuple(k[i]+(i==j) for i in range(2)),m+int(last!='_' and last!=a),a)
def state_cond(law,x,a):
    _,_,last=x
    return law('' if last=='_' else last,a)

def policy(h,N):
    code=sum((i+3)*(ord(a)-48+1) for i,a in enumerate(h))+2*len(h)
    if len(h)==N:
        a=F(1+code%5,7)
        return (a,1-a,F(0))
    a=F(1+code%3,10)
    b=F(1+(code//3)%3,10)
    return (a,b,1-a-b)

def measure(N,law):
    probs={'':F(1)}
    for t in range(1,N+1):
        for h in words(t): probs[h]=probs[h[:-1]]*law(h[:-1],h[-1])
    return probs

def original_flows(N):
    survive={'':F(1)}
    for t in range(N):
        for h in words(t):
            c=policy(h,N)[2]
            for a in A: survive[h+a]=survive[h]*c
    return survive

def compressed_actions(N,pp,survive):
    grouped=defaultdict(lambda:[F(0),F(0),F(0),F(0)])
    for t in range(N+1):
        for h in words(t):
            x=(t,state(h));mass=pp[h]*survive[h]
            abc=policy(h,N)
            grouped[x][0]+=mass
            for i in range(3):grouped[x][i+1]+=mass*abc[i]
    for key,row in grouped.items():
        assert sum(row[1:])==row[0],(key,row)
    return {k:tuple(row[i]/row[0] for i in range(1,4)) for k,row in grouped.items() if row[0]>0}

def full_terminal(N,law,survive,prob):
    out=defaultdict(F)
    for t in range(N+1):
        for h in words(t):
            m=prob[h]*survive[h]
            abc=policy(h,N)
            for i,d in enumerate(('P','Q')):
                out[(t,state(h),d)]+=m*abc[i]
    return dict(out)

def comp_terminal(N,law,actions):
    levels={state(''):F(1)}
    terminal=defaultdict(F)
    for t in range(N+1):
        nxt=defaultdict(F)
        for x,mass in levels.items():
            ap,aq,c=actions.get((t,x),(F(0),F(1),F(0)))
            terminal[(t,x,'P')]+=mass*ap
            terminal[(t,x,'Q')]+=mass*aq
            if t<N:
                for a in A:
                    nxt[transition(x,a)]+=mass*c*state_cond(law,x,a)
        levels=nxt
    return dict(terminal)

checks=[]
for N in (3,4,5):
    pp=measure(N,p_cond);qq=measure(N,q_cond_b)
    assert all(pp[h]>0 and qq[h]>0 for t in range(N+1) for h in words(t))
    for t in range(N+1):
        assert sum(pp[h] for h in words(t))==sum(qq[h] for h in words(t))==1
        for h in words(t):
            # For the symmetric-switch Markov model, (t,m) fixes Q/P ratio.
            expected = (F(2)**(t-1)*F(3,4)**changes(h)*F(1,4)**(t-1-changes(h))) if t else F(1)
            assert qq[h]/pp[h]==expected,(N,h)
            for a in A:
                assert state(h+a)==transition(state(h),a)
                assert q_cond_b(h,a)==state_cond(q_cond_b,state(h),a)
    surv=original_flows(N)
    actions=compressed_actions(N,pp,surv)
    max_diff=F(0);nonzero=[]
    for name,law,pr in (('P',p_cond,pp),('Q',q_cond_b,qq)):
        original=full_terminal(N,law,surv,pr)
        compressed=comp_terminal(N,law,actions)
        keys=set(original)|set(compressed)
        diffs=[(k,original.get(k,F(0))-compressed.get(k,F(0))) for k in keys]
        nonzero=[(k,d) for k,d in diffs if d]
        assert not nonzero,(name,N,nonzero[:4])
        assert sum(original.values())==sum(compressed.values())==1
        checks.append({'N':N,'law':name,'terminal_state_decision_keys':len(keys),
                       'terminal_total':'1/1','nonzero_discrepancies':0})

result={'schema':'EM_R1_N14_NONIID_TWO_LAW_CERTIFICATE_V1','date':'2026-10-26',
        'scope':'EXTERNAL_TWO_SYMBOL_FINITE_SEQUENTIAL_DECISION_MODEL',
        'model_A':{
          'P01':fstr(P01),'P10':fstr(P10),'Q01':fstr(Q01),'Q10':fstr(Q10),
          'P_cond_decide_P_given_count_11':fstr(qP),
          'Q_cond_decide_P_given_count_11':fstr(qQ),
          'result':'NO_COMMON_COUNT_ONLY_POLICY_FOR_ALL_STOP_AT_T2_AND_SELECT_01'},
        'model_B':{
          'P':'iid fair binary','Q':'first fair, subsequent switches with probability 3/4',
          'count':list(count('01')),'ratio_01':fstr(R('01')),'ratio_10':fstr(R('10')),
          'ratio_011':fstr(R('011')),'ratio_101':fstr(R('101')),
          'result':'RATIO_ONLY_NOT_DETERMINISTIC_RIGHT_CONGRUENCE',
          'repair':'state (t,count,number of switches,last symbol) with exact two-law lumpability'},
        'checks':checks,
        'method':'fractions.Fraction exact original ordered-prefix flows vs compressed Markov state flows'}
with open('/mnt/data/r1_n14_non_iid_two_law_certificate_20261026.json','w',encoding='utf8') as f:
    json.dump(result,f,ensure_ascii=False,sort_keys=True,indent=2)
print(json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2))
