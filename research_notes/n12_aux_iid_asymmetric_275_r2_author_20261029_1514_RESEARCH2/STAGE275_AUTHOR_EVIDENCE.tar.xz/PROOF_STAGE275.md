# Stage275 — Exact Bellman optimum and nested ordered-history quadrilateral

**Research date:** 2026-10-29 (Asia/Shanghai). **Status:** `PORTABLE_AUTHOR_EXACT / UNREVIEWED / NOT_ADMITTED`. **Scope:** finite *external* ternary-IID sequential discrimination with ordered-prefix randomized policies; no theorem about P000 native six-dimensional Cell space, native three-dimensional slices, BRC–Shor dynamics, physical time, or infinite horizons. Author role: this research turn's unauthenticated `LOCAL_RESEARCH_AUTHOR`, not a native Source Researcher/CLAIM/Driver.

**Immutable predecessor:** Enterprise Math Draft PR #1571, Stage274 commit `889678bf70eacaf8142da5d8c5f525a960fb40f6`; exact `NEXT_TASK_PACKET_275.md` in `research_notes/n12_aux_iid_asymmetric_274_r2_author_20261029_1406_RESEARCH2/`. **Read control pins:** GLOBAL_KNOWLEDGE_V1 `main@2cac8804687bc0fe9351f67edd20349f02b5cc3e`; Enterprise Math canonical `main@f8759137d869da71426061ab9e8ea7855712c833`. Global P000 V4 original at the global pin has blob `770e1b157fc10aab7b25d80c2cd52d6fcd07c9dc`, matching its same-pin P000 startup projection; separately, the current Enterprise Math source P000 V5 blob is `bcc2590d3168a28f72e8b9f0f9b1f76faadcd488`. We retain their distinct sources and the ACTIVE residual/worldview contract; neither is modified. The native service reported `research_authority_granted=false`, `CODE_REVIEW_REQUIRED`, and owner inventory query returned `CONTROL_QUOTA` (5/5 active jobs). Exact active native owner is therefore not authenticated by this research author.

## 1. Model and exact Bellman certificate

At each time there are three IID symbols {0,1,2}. Under source P they have probabilities `(1/8,1/24,5/6)`, under Q `(1/12,1/12,5/6)`. By time N=12 every policy must declare P or Q. Policies may randomize and condition on the **complete ordered word**, not merely its count vector. Let

- `eP = Pr_P(declare Q)`, `eQ = Pr_Q(declare P)`;
- `tP = E_P(number of observed symbols)`, `tQ = E_Q(number observed)`;
- `V12(a,b) = min_{eP<=a,eQ<=b} max(tP,tQ)` for real caps `(a,b)∈[0,1]^2`, assigning `+∞` if infeasible.

For `s=(i,j,k)` with `|s|≤12`, let `p_s=P0^i P1^j P2^k`, `q_s=Q0^i Q1^j Q2^k` (unnormalized mass of **one** ordered prefix, not the sum over permutations). For positive multipliers `lambdaP,lambdaQ` and time coefficients `(thetaP,thetaQ)=(0,1)`, define exactly

```
D_P(s) = lambdaQ*q_s              # declare P; Q-source error
D_Q(s) = lambdaP*p_s              # declare Q; P-source error
D_C(s) = q_s + sum_z B(s+e_z)    # continue, |s|<12
B(s) = min permitted D_a(s)
```

For any individual ordered prefix of counts s, the future IID conditional law and both raw prefix masses depend only on s. Consequently backward induction gives the minimum Lagrangian cost over **all** suffix histories, including full-order and randomized decisions. The count Bellman state space is a sufficient evaluator of the minimum, not a restriction of the policy class.

Solve the two candidate equality equations at `T=(0,0,5)` for P/C and `S4=(1,2,7)` for Q/C, using an affine action assignment with the intervening `S3=(1,2,6)` continuing. Each equality is `u*lambdaP+v*lambdaQ+w=0`, with the exact triples

```
T:  (-36393134375/3962711310336, 758515625/30958682112,
      -13070646875/23219011584)
S4: (1796875/247669456896, -859375/69657034752,
      -1015625/5804752896)
2x2 determinant = -17791129638671875/276030719456218208796672 != 0
```

The **unique rational candidate** obtained from these two linear equations is

```
lambdaP = 38096641024/218617401 > 0
lambdaQ = 6434343396/72872467 > 0
H = B(0,0,0) = 49314920902234732441/564008885142552576
```

Crucially, this candidate was not assumed valid: the actually run standard-library `Fraction` checker recomputes the exact **global** minimum over all 455 count states and 1,274 legal action costs, finding 817 strictly positive action gaps and exactly two equal-minimum action pairs:

```
T=(0,0,5): ('P','C')
S4=(1,2,7): ('Q','C')
S3=(1,2,6): unique 'C'
S5=(1,2,8): unique 'Q'
minimum strictly positive action gap = 153795655/288772549192986918912
```

All other minimizing actions are unique, as verified by a full state/action comparison with Stage274's predecessor. This makes the exact Bellman certificate valid globally, not simply a local derivative or approximate fit. For every cap-feasible ordered-history randomized policy,

```
max(tP,tQ) >= tQ >= H-lambdaP*eP-lambdaQ*eQ
                          >= H-lambdaP*a-lambdaQ*b.      (1)
```

## 2. Four exact zero-dual-gap corner strategies

At every non-tie state use the unique Bellman minimizer. Only the two tie decisions vary. Denote

```
M     = (T:P, S4:Q)
Jnew  = (T:C, S4:Q)
Jplus = (T:C, S4:C)
M2    = (T:P, S4:C)
```

Here a tie-state decision applies to **every reached ordered prefix** of its count state; unreachable histories can take arbitrary actions. Independent unmerged DFS, with separately multiplied P/Q masses on every ordered word, gives these exact vectors `(eP,eQ,tP,tQ)`:

```
M     = (183995918761/2641807540224, 13758880795/17414258688,
         13862981030731/2972033482752, 21429209015/3869835264)
Jnew  = (624774025033/7925422620672, 213315452095/278628139008,
         5105360174827/990677827584, 141645900965/23219011584)
Jplus = (206034675011/2641807540224, 23746022455/30958682112,
         5113190174827/990677827584, 47372383655/7739670528)
M2    = (545662756283/7925422620672, 9188342405/11609505792,
         13885256030731/2972033482752, 64511064545/11609505792)
```

For all four policies: both complete P and Q terminating masses equal **exactly 1**, independent backward count-observer values equal their complete ordered DFS values, and `tQ>tP`. Each vector satisfies `lambdaP*eP+lambdaQ*eQ+tQ=H`, exactly. The four DFS runs traverse respectively `(9913,6609)`, `(10039,6693)`, `(10735,7157)`, and `(10573,7049)` nodes/terminal words. Every ordered word is kept distinct; no multinomial merge happens in this independent audit.

## 3. Complete equality family and nested-prefix residual

All Bellman-equality strategies must use the prescribed unique actions off T and S4. There is exactly one reached ordered prefix at T, the word `22222`; let `r∈[0,1]` be its conditional continue probability. S4 has `110` reachable full ordered prefixes when T declares P and `116` when T continues, of which exactly `6` begin with `22222`. Thus **110 always-reached S4 words** plus **6 T-descendant words** contribute S4 exposure. These counts are checked in the full-word DFS for all four corners.

For each S4 word w, let `c_w∈[0,1]` be its conditional probability to continue once reached. The 110 always-reached words contribute `∑c_w`, while the six T-descendant words contribute `r∑c_w`. Define the *normalized aggregate continuation exposure* k as this sum of conditional continuation probabilities, weighted by their reach probability relative to each equally-massed S4 prefix. Because every S4 prefix has the **same** `p_S4` and `q_S4`, and the same IID suffix law, every unit of k produces the same increment in **all four** observers.

Therefore the complete attainable observer family is exactly

```
Obs(r,k) = M + r*(Jnew-M) + (k/110)*(M2-M)
0 <= r <= 1,
0 <= k <= 110+6*r.                                     (2)
```

The exact independent identity `110*(Jplus-Jnew) = 116*(M2-M)` holds in all four observer coordinates. Necessity of (2) is obtained by conditional expectation over distinct ordered prefixes, without losing ancestry, branch identity or positive mass. Conversely, for any `(r,k)` in (2), choose coin r at T and **conditional** continuation probability `k/(110+6*r)` at every reached S4 prefix; the denominator is at least 110. This realizes the exact observer vector. A merely independent rectangle `0≤r≤1`, `0≤k≤116` would contain unrealizable policies, so it is not a valid sufficient-state quotient.

This is a concrete BRC-compatible positive-rational provenance preservation: carrier = distinct ordered prefix identities together with separately labelled P/Q masses and conditional reach weights; observer = `(eP,eQ,tP,tQ)`; future operations = continued IID symbols and stopping decisions through horizon 12. The state quotient is exact only for the explicitly stated observer/future-operation family; no signed cancellation or native X6 correspondence is assumed.

## 4. The new full-real-cap optimality face

Let `R275 = conv(M_e,Jnew_e,Jplus_e,M2_e)` in the cyclic order shown, where `_e` denotes the **first two** observer coordinates. Its four exact consecutive oriented turns are

```
-515942759521484375/69007679864054552199168
-515942759521484375/69007679864054552199168
-978512130126953125/138015359728109104398336
-978512130126953125/138015359728109104398336.
```

All are strictly negative; hence R275 is a nondegenerate strictly convex rational **non-parallelogram trapezoid**. Its exact area is

```
area(R275) = 2010397649169921875/276030719456218208796672.
```

The entire edge M--Jnew is shared with Stage274's strictly convex R274. The exact signed orientations relative to the directed edge M→Jnew are

```
orient(M,Jnew,M2)    = -978512130126953125/138015359728109104398336
orient(M,Jnew,K_old) = +220235665771484375/34503839932027276099584.
```

Consequently the two convex regions occupy opposite closed half-planes of their common supporting line and their interiors do not meet.

**Theorem.** For **every real pair** `(a,b)∈[0,1]^2`, with infeasible caps assigned `+∞`,

```
V12(a,b) = H-lambdaP*a-lambdaQ*b   iff   (a,b) ∈ R275.    (3)
```

**Proof.** Sufficiency: (2) affinely maps onto R275; for any point in that polygon it constructs a legal full ordered-history randomized equality policy with `eP=a`, `eQ=b`. `tQ>tP` at each corner, hence throughout the convex equality family. Equation (1) is therefore attained, giving equality in (3). Necessity: the set of full ordered-prefix behavioral randomized policies is a finite product of compact action simplices; each of the four observers is a continuous polynomial in these conditional probabilities. Closed error-cap restrictions thus admit a minimizing policy whenever feasible. Equality in (1), since both multipliers are strictly positive and `tQ>=tP` is part of the equality chain, forces exact cap saturation and zero Bellman action gap at every reached prefix. The **complete** zero-gap family (2) then forces `(a,b)∈R275`. If infeasible, `+∞` cannot equal the finite right side. QED.

For the Stage275 requested caps

```
a275 = 1175053055941/15850845241344
b275 = 867218405255/1114512556032
```

the strictly positive rational mixture `49/100*M + 49/100*Jnew + 1/50*M2` realizes precisely

```
eP = a275,
eQ = b275,
tP = 1079662613531/220150628352,
tQ = 539955234235/92876046336,
tQ-tP = 5406244425703/5944066965504 > 0.
```

The exact identity `H-lambdaP*a275-lambdaQ*b275=tQ` matches the global lower bound (1). Thus

```
V12(a275,b275) = 539955234235/92876046336.            (4)
```

## 5. Executed verification, limitations and next discriminating unit

`REPRO_STAGE275.py` uses only standard-library `Fraction`, checks the rational affine tie-equation system and its nonzero determinant, all 455 state optima and 1,274 legal actions, 817 strictly positive gaps and the exact two-tie set, four corner observers by **two independent computational organizations** (reverse count recursion and unmerged forward ordered DFS), source P/Q mass conservation, nested path counts, convex turns, exact area, shared-edge half-plane separation, and the primal/dual equality at the prescribed caps. Five audited deterministic policies (including the next-stage test) traverse **52,268 full-word DFS nodes** and **34,847 terminal words**. The actually executed captured output contains `STAGE275_EXACT_ALL_REAL_FACE_PASS`. The program checks this *finite certificate*; the universal real-cap quantifier in (3) is justified by the above Bellman/compactness/equality-family argument.

**Stage276 sharp exterior witness (upper bound only):** the new unique optimal action at `S5=(1,2,8)` is Q. Starting from the M2 strategy, change only S5 from Q to C, obtaining M3. The independent full-word DFS visits 11,008 nodes and 7,339 terminal words and conserves both source masses exactly. Its Stage275 Lagrangian slack is strictly positive:

```
M3 = (59823639587/880602513408, 26974285/34012224,
      13907006030731/2972033482752, 21579209015/3869835264)
slack275(M3) = 130346447265625/35250555321409536 > 0.
```

The legal strict mixture `49/100*M2 + 49/100*Jplus + 1/50*M3` provides the exact feasible point

```
a276 = 1162027955941/15850845241344
b276 = 868777330255/1114512556032
tP276 = 9732203421779/1981355655168
tQ276 = 541791009235/92876046336 > tP276
```

Its oriented distance across the M2--Jplus supporting edge is negative, `-41296658447265625/276030719456218208796672`, while R275 is on the opposite side. Hence **the proved next bound** is `V12(a276,b276) <= 541791009235/92876046336`; optimality is Stage276's unresolved task. Try the next exact tie pair T and S5, checking every action again, then derive full ordered-history reach weights, real-cap optimality region and matching primal/dual or an exact obstruction.

**Evidence status:** These are portable author-side exact mathematical results with complete executable checks and an explicit proof argument. Canonical Source activity registration/CLAIM, Source Result, independent mathematical review, formal theorem checking, and any P000-native X6 transfer remain independently gated. This GitHub evidence is not formal scientific admission, and no protected P000/worldview file was edited.
