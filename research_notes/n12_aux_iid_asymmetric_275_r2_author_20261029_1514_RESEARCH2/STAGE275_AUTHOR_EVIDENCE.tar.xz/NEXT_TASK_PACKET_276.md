# Stage276 — Exact continuation beyond R275 M2--Jplus

Date: 2026-10-29. Predecessor: Stage275 external 12-step ternary IID theorem (`PROOF_STAGE275.md`), actual `REPRO_STAGE275.py` and `REPRO_STAGE275_EXECUTED_STDOUT.txt`. Preserve Stage275's immutable provenance and `PORTABLE_AUTHOR_EXACT / UNREVIEWED / NOT_ADMITTED` classification. This is an **external auxiliary model**, not an X6/heartbeat-native theorem. Do not silently equate author evidence with formal Source CLAIM/Result, Driver review or mathematical admission.

## Fixed exact model and proved frontier

`P=(1/8,1/24,5/6), Q=(1/12,1/12,5/6)`, IID alphabet 3, maximum N=12. Observer tuple `(eP,eQ,tP,tQ)` uses complete ordered-prefix randomized policy space, and `V12(a,b)=min max(tP,tQ)` for error caps `eP<=a,eQ<=b`.

Stage275 proved for **all real caps** `(a,b)∈[0,1]^2`:

```
lambdaP = 38096641024/218617401
lambdaQ = 6434343396/72872467
H = 49314920902234732441/564008885142552576
only exact Bellman ties: T=(0,0,5) P/C, S4=(1,2,7) Q/C
R275 = conv(M_e,Jnew_e,Jplus_e,M2_e)
area(R275) = 2010397649169921875/276030719456218208796672
V12(a,b) = H-lambdaP*a-lambdaQ*b iff (a,b) in R275
complete equality observer law:
  Obs(r,k) = M+r*(Jnew-M)+(k/110)*(M2-M)
  0<=r<=1, 0<=k<=110+6*r.
```

This is the precise **nested ordered-prefix** exposure constraint: S4 has 110 reached words when T stops and 116 when T continues (six descend from T). Do not substitute an independent rectangular two-coin model. Each reached S4 word carries the same separately labelled P/Q prefix masses, but branch reach/survival depends on T's action. Count DP is exact for the Bellman optimum at these observer laws; full ordered provenance is necessary to characterize the equality-policy family.

The Stage275 prescribed caps were solved exactly:

```
a275 = 1175053055941/15850845241344
b275 = 867218405255/1114512556032
V12(a275,b275) = 539955234235/92876046336
```

## Stage276 exact exterior feasible witness — not yet an optimum

S5=(1,2,8) is uniquely a Q declaration under the Stage275 optimal dual. Make M3 from the M2 zero-gap policy by changing only S5:Q to S5:C. An independent unmerged full ordered P/Q DFS verifies M3, 11,008 visited nodes, 7,339 terminal words, both source terminal masses 1:

```
M3 = (59823639587/880602513408, 26974285/34012224,
      13907006030731/2972033482752, 21579209015/3869835264)
Stage275 dual slack(M3) = 130346447265625/35250555321409536 > 0
```

The legal mixture (49/100)M2+(49/100)Jplus+(1/50)M3 yields:

```
a276 = 1162027955941/15850845241344
b276 = 868777330255/1114512556032
tP276 = 9732203421779/1981355655168
tQ276 = 541791009235/92876046336 > tP276
```

It lies strictly outside R275 across edge M2--Jplus: `orient(M2,Jplus,(a276,b276))=-41296658447265625/276030719456218208796672`, on the opposite side to M. **Current proved upper bound only:**

```
V12(a276,b276) <= 541791009235/92876046336.
```

## One next executable mathematical unit

First compute candidate positive exact Bellman multipliers by imposing ties at `T=(0,0,5)` and `S5=(1,2,8)`, with S4 continuing, then run an exhaustive **Fraction** Bellman induction on all 455 states and 1274 legal actions. Record every tie, all positive action gaps and the true root value. If the hypothesized tie set fails, report the exact contradiction instead of forcing it.

Independently evaluate complete ordered-prefix paths to S5 with T stopping/continuing, including any newly relevant ancestral tie S4. Preserve conditional survival weights and separately labelled P/Q probability masses, and derive the full attainable equality observer domain without assuming independent coins at nested tie states. Match an exact rational primal mixture saturating a276,b276 to the supporting dual, or provide the sharpest exact obstruction found. Prove the all-real-cap equality region (or appropriately scoped alternative), strict convexity/shared boundary, source-mass conservation and tQ vs tP dominance; cross-check count recursion against independent unmerged full-word DFS.

Publish the coherent proof, executable source, **actually executed** raw verification output, true verification scope and next Stage277 question to the existing authorized research PR with guarded no-force head-CAS and scoped readback. Do not change P000/ACTIVE worldview or broaden the external IID conclusion into native X6. Persist own role/authentication status truthfully; Source owner/CLAIM/Driver approval remains separate.
