#!/usr/bin/env python3
"""Stage275: exact Bellman supporting face and independent ordered-word audit.
External ternary-IID N=12 model, no P000-native X6 theorem or Source admission.
Only Python standard library; every mathematical predicate uses Fraction.
"""
from collections import Counter
from fractions import Fraction as F

N=12
P=(F(1,8),F(1,24),F(5,6))
Q=(F(1,12),F(1,12),F(5,6))
STATES=[(i,j,n-i-j) for n in range(N+1) for i in range(n+1) for j in range(n-i+1)]
assert len(STATES)==455 and len(set(STATES))==455
p={s:P[0]**s[0]*P[1]**s[1]*P[2]**s[2] for s in STATES}
q={s:Q[0]**s[0]*Q[1]**s[1]*Q[2]**s[2] for s in STATES}
T,S3,S4,S5=(0,0,5),(1,2,6),(1,2,7),(1,2,8)
root=(0,0,0)

def nxt(s,z):
    return tuple(s[i]+(i==z) for i in range(3))

def bellman(lambdaP,lambdaQ):
    B, actions, ties, costs={},{},{},{}
    for s in reversed(STATES):
        c={'P':lambdaQ*q[s],'Q':lambdaP*p[s]}
        if sum(s)<N:
            c['C']=q[s]+sum(B[nxt(s,z)] for z in range(3))
        B[s]=min(c.values());costs[s]=c
        ties[s]=tuple(a for a in 'PQC' if a in c and c[a]==B[s])
        actions[s]=ties[s][0]
    return B,actions,ties,costs

OLD_LP=F(445906494464,2706255861)
OLD_LQ=F(76440567684,902085287)
oldB, oldA, oldT, oldC = bellman(OLD_LP,OLD_LQ)
assert oldB[root]==F(1758667527952600918633,20945528728608964608)
assert {s:v for s,v in oldT.items() if len(v)>1}=={T:('P','C'),S3:('Q','C')}
assert oldT[S4]==('Q',)

# Exact affine coefficients (coefficient_of_lambdaP, coefficient_of_lambdaQ, constant)
# under a fixed Stage274 action assignment with S3 continuing, S4 declaring Q.
seed_policy=dict(oldA)
seed_policy[S3]='C'
seed_policy[S4]='Q'
linear, alternative={},{}
for s in reversed(STATES):
    cost={'P':(F(0),q[s],F(0)),'Q':(p[s],F(0),F(0))}
    if sum(s)<N:
        xs=[linear[nxt(s,z)] for z in range(3)]
        cost['C']=tuple(sum(x[i] for x in xs)+(q[s] if i==2 else F(0)) for i in range(3))
    linear[s]=cost[seed_policy[s]]
    alternative[s]=cost

def vminus(x,y):
    return tuple(x[i]-y[i] for i in range(len(x)))

tieT=vminus(alternative[T]['P'],alternative[T]['C'])
tieS4=vminus(alternative[S4]['Q'],alternative[S4]['C'])
assert tieT==(F(-36393134375,3962711310336),F(758515625,30958682112),F(-13070646875,23219011584))
assert tieS4==(F(1796875,247669456896),F(-859375,69657034752),F(-1015625,5804752896))
D=tieT[0]*tieS4[1]-tieS4[0]*tieT[1]
assert D!=0
LAMBDA_P=(tieS4[2]*tieT[1]-tieT[2]*tieS4[1])/D
LAMBDA_Q=(tieT[2]*tieS4[0]-tieS4[2]*tieT[0])/D
assert LAMBDA_P==F(38096641024,218617401)>0
assert LAMBDA_Q==F(6434343396,72872467)>0
assert sum(tieT[i]*(LAMBDA_P,LAMBDA_Q,F(1))[i] for i in range(3))==0
assert sum(tieS4[i]*(LAMBDA_P,LAMBDA_Q,F(1))[i] for i in range(3))==0

B, a, ties, costs=bellman(LAMBDA_P,LAMBDA_Q)
H=B[root]
assert H==F(49314920902234732441,564008885142552576)
assert {s:v for s,v in ties.items() if len(v)>1}=={T:('P','C'),S4:('Q','C')}
assert ties[S3]==('C',) and ties[S5]==('Q',)
assert all(ties[s]==oldT[s] for s in STATES if s not in (S3,S4))
assert sum(len(c) for c in costs.values())==1274
strict_gaps=[v-min(c.values()) for c in costs.values() for v in c.values() if v>min(c.values())]
assert len(strict_gaps)==817 and min(strict_gaps)==F(153795655,288772549192986918912)

# The four corners differ only at the two Bellman ties; all 455 states have a choice.
def policy(continueT,continueS4):
    c=dict(a)
    c[T]='C' if continueT else 'P'
    c[S4]='C' if continueS4 else 'Q'
    return c

choices={'M':policy(False,False),'Jnew':policy(True,False),
         'Jplus':policy(True,True),'M2':policy(False,True)}

def count_observers(c):
    """Independent backwards count-state propagation for the *four* observers."""
    out={}
    for s in reversed(STATES):
        ac=c[s]
        if ac=='P':out[s]=(F(0),q[s],F(0),F(0))
        elif ac=='Q':out[s]=(p[s],F(0),F(0),F(0))
        else:
            xx=[out[nxt(s,z)] for z in range(3)]
            out[s]=(sum(x[0] for x in xx),sum(x[1] for x in xx),
                    p[s]+sum(x[2] for x in xx),q[s]+sum(x[3] for x in xx))
    return out[root]

def ordered_history_audit(c):
    """Independent unmerged ordered-word DFS; separately carries P/Q path masses."""
    obs=[F(0)]*4
    terminal=[F(0),F(0)]
    count=Counter()
    def dfs(s,mp,mq,word):
        count['nodes']+=1
        if s==T:count['T']+=1
        if s==S4:
            count['S4']+=1
            if word[:5]==(2,)*5:count['S4_descends_from_T']+=1
        action=c[s]
        if action!='C':
            count['terminal']+=1
            terminal[0]+=mp
            terminal[1]+=mq
            if action=='P':obs[1]+=mq
            else:obs[0]+=mp
            obs[2]+=len(word)*mp
            obs[3]+=len(word)*mq
        else:
            for z in range(3):
                dfs(nxt(s,z),mp*P[z],mq*Q[z],word+(z,))
    dfs(root,F(1),F(1),())
    assert terminal==[F(1),F(1)]
    return tuple(obs),count

point={};counts={}
for name,c in choices.items():
    four,ct=ordered_history_audit(c)
    assert four==count_observers(c),name
    assert four[3]>four[2],name
    assert LAMBDA_P*four[0]+LAMBDA_Q*four[1]+four[3]==H,name
    point[name],counts[name]=four,ct
M,Jnew,Jplus,M2=(point[n] for n in ('M','Jnew','Jplus','M2'))
assert M==(F(183995918761,2641807540224),F(13758880795,17414258688),
           F(13862981030731,2972033482752),F(21429209015,3869835264))
assert Jnew==(F(624774025033,7925422620672),F(213315452095,278628139008),
              F(5105360174827,990677827584),F(141645900965,23219011584))
assert M2==(F(545662756283,7925422620672),F(9188342405,11609505792),
            F(13885256030731,2972033482752),F(64511064545,11609505792))

m0,m1=counts['M']['S4'],counts['Jnew']['S4']
assert m0==counts['M2']['S4']
assert m1==counts['Jplus']['S4']
assert m0>0 and m1>m0
assert counts['M']['S4_descends_from_T']==0
assert counts['Jnew']['S4_descends_from_T']==m1-m0
assert all(m0*(Jplus[i]-Jnew[i])==m1*(M2[i]-M[i]) for i in range(4))
# Consequently all equality policy four-observers are
# M+r*(Jnew-M)+(k/m0)*(M2-M),  0<=r<=1, 0<=k<=m0+(m1-m0)*r.
# At S4 the conditional probability of continuing can realize k/(m0+(m1-m0)r).

def orient(A,B,C):
    return (B[0]-A[0])*(C[1]-A[1])-(B[1]-A[1])*(C[0]-A[0])
poly=(M,Jnew,Jplus,M2)
turns=[orient(poly[i],poly[(i+1)%4],poly[(i+2)%4]) for i in range(4)]
assert all(t>0 for t in turns) or all(t<0 for t in turns)
area=abs(sum(poly[i][0]*poly[(i+1)%4][1]-poly[(i+1)%4][0]*poly[i][1] for i in range(4)))/2
assert area>0

weights=(F(49,100),F(49,100),F(1,50))
point275=tuple(weights[0]*M[i]+weights[1]*Jnew[i]+weights[2]*M2[i] for i in range(4))
assert point275==(F(1175053055941,15850845241344),
                  F(867218405255,1114512556032),
                  F(1079662613531,220150628352),
                  F(539955234235,92876046336))
assert point275[3]>point275[2]
assert H-LAMBDA_P*point275[0]-LAMBDA_Q*point275[1]==point275[3]
assert orient(M,Jnew,M2)*orient(M,Jnew,(F(557277756283,7925422620672),F(4579991515,5804752896)))<0

# Stage276 exterior test: flip S5 from Q to C only in Stage275 policy M2.
M3_choices=dict(choices['M2'])
assert M3_choices[S5]=='Q'
M3_choices[S5]='C'
M3,M3_counts=ordered_history_audit(M3_choices)
assert M3==count_observers(M3_choices)
assert M3[3]>M3[2]
M3_slack=LAMBDA_P*M3[0]+LAMBDA_Q*M3[1]+M3[3]-H
assert M3_slack>0
point276=tuple(weights[0]*M2[i]+weights[1]*Jplus[i]+weights[2]*M3[i] for i in range(4))
assert point276[3]>point276[2]
assert orient(M2,Jplus,point276)*orient(M2,Jplus,M)<0

print('STAGE275_EXACT_ALL_REAL_FACE_PASS')
print('model N=12 states',len(STATES),'legal_actions',sum(map(len,costs.values())),
      'positive_action_gaps',len(strict_gaps),'ties',len([s for s in ties if len(ties[s])>1]))
print('lambdaP',LAMBDA_P,'lambdaQ',LAMBDA_Q,'H',H)
print('exact_tie_pairs',[(str(s),str(ties[s])) for s in (T,S4)])
print('minimum_positive_gap',min(strict_gaps))
print('tie_equation_T',tuple(map(str,tieT)))
print('tie_equation_S4',tuple(map(str,tieS4)))
print('equations_determinant',D)
for name in ('M','Jnew','Jplus','M2'):
    print(name,'observers',*(str(x) for x in point[name]),
          'ordered_nodes',counts[name]['nodes'],
          'ordered_terminal',counts[name]['terminal'],
          'S4_history_count',counts[name]['S4'],
          'S4_descends_from_T',counts[name]['S4_descends_from_T'])
print('nested S4 history count Tstop',m0,'Tcontinue',m1,'additional',m1-m0)
print('equality_parameter_domain 0<=r<=1, 0<=k<=m0+(m1-m0)*r')
print('R275_cyclic_vertices',('M','Jnew','Jplus','M2'),
      'strict_orientation_turns',*(str(t) for t in turns),'area',area)
print('R274_shared_edge_separation',orient(M,Jnew,M2),
      'old_R274_K_side',orient(M,Jnew,(F(557277756283,7925422620672),F(4579991515,5804752896))))
print('target_point275',*(str(x) for x in point275),
      'tQ_minus_tP',point275[3]-point275[2])
print('new_dual_lower_bound_equals_primal',H-LAMBDA_P*point275[0]-LAMBDA_Q*point275[1])
print('Stage276_S5_flip',*(str(x) for x in M3),'old_dual_slack',M3_slack,
      'ordered_nodes',M3_counts['nodes'],'ordered_terminal',M3_counts['terminal'])
print('Stage276_exterior_feasible',*(str(x) for x in point276),
      'orientation',orient(M2,Jplus,point276),
      'upper_bound',point276[3])
print('audit_5_policies_ordered_nodes',sum(c['nodes'] for c in counts.values())+M3_counts['nodes'],
      'audit_5_policies_terminal',sum(c['terminal'] for c in counts.values())+M3_counts['terminal'])
