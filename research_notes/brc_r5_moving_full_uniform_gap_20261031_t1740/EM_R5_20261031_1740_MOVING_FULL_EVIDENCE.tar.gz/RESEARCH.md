# R5 — Moving-FULL minimax closes the entire shared L-terminal-error compensation family

**Date:** 2026-10-31 (Asia/Shanghai). **Scientific classification:** AUTHOR_PROVED / EXACT_FRACTION_CHECKED / UNREVIEWED / NOT_ADMITTED / PORTABLE_ONLY / REGISTER_PENDING. This is a theorem about an explicitly specified finite two-measure stopping process, not an approved canonical Result, a native X6 theorem, or a physical calibration.

## Frozen authoritative and scientific inputs

- Account `GLOBAL_KNOWLEDGE_V1` canonical main at `a8ac2ca67df02b5e1050370145c00ea19607b4d4`: `00_BOOTSTRAP.md`, `OPERATING_MANUAL.md`, project bootstrap, P000 startup projection, original P000 and ACTIVE `我眼中的世界.md`. Projection `canonical_blob_sha1=770e1b157fc10aab7b25d80c2cd52d6fcd07c9dc` matched original P000 Git blob in the same immutable snapshot.
- Enterprise Math canonical main at `cd0d692a5510dddcc42991b056ed032933e0b164`: `AGENTS.md`, `docs/AUTONOMOUS_RESEARCH_OPERATIONS.zh-CN.md`, `docs/PORTABLE_RESEARCH_PROTOCOL.md`, and task-specific control constraints.
- Original positive two-merger natural-flow construction: immutable `e7916482f44a925e11ece98e406309f4655fb1f1`, under `research_notes/brc_r5_positive_two_merger_rigidity_20261031_t1340/`.
- Exact eight-label model and fixed-witness threshold: immutable `573749528f4723f1c689bfea6a61a3e580f0d845`, `research_notes/brc_r5_true_merger_coupled_threshold_20261031_t1636/{RESEARCH.md,VERIFY.py,EXACT_OUTPUT.txt,NEXT_TASK.md}`. That calculation is reused, not repeated as a new result.

This note solves the next unit proposed there: the **moving FULL optimum** against the **moving seedless LR optimum** under eight *common* terminal response labels, with all legal real values and zero-to-unit error radius. The BRC carrier retains source `i`, D/Y route, STOP/CONTINUE action, positive Q mass and P likelihood propagation; the observation is `(error_P,error_Q,T_P,T_Q)`. Terminal labels are COMMON to both strategy classes.

## Complete model and observer

Origins `i=0,1` each carry Q=P initial mass `1/2` at `A=(t=1, LR=1)`. A may STOP (`error=0, time=1`) or CONTINUE. At time 2, Q conditional transitions are `D:alpha_i`, `C:1-2alpha_i`, `Y:alpha_i`, with `alpha_0=1/4`, `alpha_1=1/8`; likelihood ratios are `1/2,1,3/2`. C stops with error 0 at time 2. D STOP has error 1 at time 2; D CONTINUE splits with Q probabilities `2/3` to a time-3 residual (LR=1/4, error 0), and `1/3` to a shared LR=1 L node. Y STOP has error 0 at time 2; Y CONTINUE splits with Q probabilities `1/2` to a time-3 residual (LR=2, error 1), and `1/2` to L. P child masses are Q child masses times child LR; each natural flow is strictly positive and each completed policy has total P=Q=1. At L, STOP terminates at time 3 and CONTINUE terminates at time 4.

For each `h=(i,j,a)` where `i∈{0,1}`, `j∈{D,Y}`, `a∈{0,1}`, assign the **same** terminal Q-error probability `r_h` for FULL and LR. Fix any real `0≤epsilon≤1`: for `a=0` STOP, `r_h∈[0,epsilon]`; for `a=1` CONTINUE, `r_h∈[1-epsilon,1]`. All other terminal errors are as above. FULL decisions see origin and full D/Y history, whereas seedless LR shares only four decision keys `(A,D,Y,L)` and uses independent behavioral probabilities at the keys, without a persistent seed. Every key is visited at most once on a realized trajectory; the support of its multilinear objective is attained by a deterministic strategy.

Fix the signed four-coordinate observer `J=41 error_Q - 12 T_Q`. It has `ℓ¹` coefficient norm `53`. For `i=0,1`, set

    R_i0 = 41*r_(i,Y,0) - 36     (L STOP payoff per unit Q mass)
    R_i1 = 41*r_(i,Y,1) - 48     (L CONTINUE payoff per unit Q mass)
    u_i = R_i0 + 7 = 41*r_(i,Y,0) - 29
    v_i = R_i1 + 7 = 41*(r_(i,Y,1)-1)

Thus `-29≤u_i≤U=41epsilon-29≤12`, and `-41epsilon≤v_i≤0`. The four D-route error labels remain arbitrary: the proof below shows that these labels do not influence either support optimum.

## New theorem: exact all-real moving-support minimax

Define for a common legal response vector `r`:

    Gap_J(r) = max_(FULL real behavioral strategies) J(O_f(r))
               - max_(seedless LR real behavioral strategies) J(O_l(r)).

**Theorem.** For every real `0≤epsilon≤1`,

    min_(all eight common legal response labels r) Gap_J(r)
      = 2 - min(41epsilon,29)/16
      = { 2 - 41epsilon/16,   0≤epsilon≤29/41;
          3/16,              29/41≤epsilon≤1. }

The minimizers are legitimate common-label assignments, not independent errors selected separately for FULL and LR. Consequently **for every legal vector of eight terminal response labels in the entire probability cube**, the FULL and LR four-observer convex hulls are strictly different, with an explicit signed support gap at least `3/16`. For each such vector there exists a FULL deterministic observation whose `L∞` distance to the whole LR observation convex hull is at least `3/848`; at epsilon `1/16` the stronger support/distance bounds are `471/256` and `471/13568`. The `3/16` support floor is sharp for this family and this direction. This closes the *shared L-only terminal-error compensation* subfamily, not the full original stopping/continuation mother problem.

### Proof (including the real behavioral strategy domain)

The per-Q-mass stage-2 stopping rewards under `J` are D STOP `41-24=17`, Y STOP `-24`, and C STOP `-24`. At L, every legal STOP reward is in `[-36,5]` and every legal CONTINUE reward is in `[-48,-7]`. Even when the continuation branch uses the best L reward, D CONTINUE yields at most `-24+5/3<17`, so D STOP strictly dominates for all policies maximizing J. Even under the worst L reward `-48`, Y CONTINUE yields `(5-48)/2=-43/2>-24`, so Y CONTINUE strictly dominates. Therefore one only needs to optimize A and the L decision on Y histories; all D-history label choices are immaterial.

At origin i, conditional on A CONTINUE, the best expected J reward is

    C_i = alpha_i*17 + (1-2alpha_i)*(-24)
          + alpha_i*(5+max(R_i0,R_i1))/2
        = -24 + alpha_i*(135+max(R_i0,R_i1))/2.

A STOP gives `-12`. At origin 0, `C_0=(-57+max(R_00,R_01))/8≥-93/8>-12` because L STOP is always available with reward at least `-36`. At origin 1, `C_1=(-249+max(R_10,R_11))/16≤-244/16<-12` because all L rewards are at most `5`. Therefore every FULL support optimizer chooses A CONTINUE for origin 0 and A STOP for origin 1, chooses D STOP and Y CONTINUE, and maximizes the L action on origin-0 Y. Its exact support is

    S_FULL(r) = -10 + max(u_0,v_0)/16.

LR is restricted to a common A decision, common D and Y choices, and common L. As above D STOP and Y CONTINUE dominate whenever A CONTINUE. A STOP globally gives `-12`. With A CONTINUE and L STOP, the support is `-12+(2u_0+u_1)/32`; with L CONTINUE it is `-12+(2v_0+v_1)/32≤-12` since `v_i≤0`. Multi-affinity over the four behavioral decisions proves that these deterministic extrema also cover every real seedless LR behavioral strategy. Hence

    S_LR(r) = -12 + max(0,(2u_0+u_1)/32)
    Gap_J(r) = 2 + max(u_0,v_0)/16 - max(0,(2u_0+u_1)/32).    (★)

If `0≤epsilon≤29/41`, then `U≤0`; `u_0,u_1≤U` makes `2u_0+u_1≤0`, so the final max is zero. Since `v_0≥-41epsilon`, equation (★) gives `Gap_J≥2-41epsilon/16`. Equality is reached by setting `r_(0,Y,0)=0`, `r_(0,Y,1)=1-epsilon`, with all other labels at their baseline values. In this regime `u_0=-29≤-41epsilon=v_0` and `S_LR=-12`.

If `29/41≤epsilon≤1`, write `U=41epsilon-29≤12`. Since `u_1≤U` and `max(u_0,v_0)≥u_0`, (★) yields

    Gap_J ≥ 2 + max(u_0,v_0)/16 - max(0,(2u_0+U)/32).

When `2u_0+U≤0`, this is at least `2+u_0/16≥2-29/16=3/16`. When `2u_0+U≥0`, it is at least `2+u_0/16-(2u_0+U)/32=2-U/32≥13/8>3/16`. The same explicit construction `r_(0,Y,0)=0`, `r_(0,Y,1)=1-epsilon`, with all others at baseline gives `u_0=-29`, `v_0=-41epsilon≤-29`, and `2u_0+u_1=-87<0`, hence exact gap `3/16`. This proves the formula for the complete real continuum.

Finally the LR support over its convex hull equals `S_LR`; by Hölder's inequality a FULL maximizing witness has `d∞(w,conv(O_LR))≥Gap_J/||(0,41,0,-12)||_1=Gap_J/53`, establishing the distance claim. ∎

## Exact verification and scope

`VERIFY.py` executes Python standard-library `fractions.Fraction` only. It independently reconstructs all **1,024 FULL and 16 LR** deterministic source-labelled P/Q natural-flow policies and checks both measure normalizations. It checks their exact signed support against the derived Bellman formula for **30** distinct legal response configurations (including boundary and rational midpoint configurations), verifies the exact minimax at **all 256 box corners for each of six exact rational epsilon values** (1,536 corner cases), and checks explicit real-parametric sharpness constructions at six values. The program's saved standard output ends in `PASS_EXACT_R5_MOVING_FULL_UNIFORM_J_SEPARATION`. The all-real theorem follows from the symbolic inequalities above, **not** from treating the finite sample grid as a universal proof. No floating point solver, native X6 trajectory or physical residual has been executed.

## Authority, origin tracking, and scientific state

This research is performed in the exposed current conversation as **author-side portable research**. At the execution checkpoint, the native gateway reported `research_authority_granted=false` and `executor_binding_configured=false`; its bounded owner inventory call returned `CONTROL_QUOTA`. No canonical CLAIM, Source Result or independent Driver admission is inferred from the GitHub commit/PR. The actual author context is shared with previous R5 research; independent review must be separately conducted by an authorized reviewer. The BRC reuse classification is `REUSE_APPLIED` for the original source-labelled positive branch-flow carrier, likelihood transport and shared-response cylinders; native X6 attribution remains an open bridge. P000 and ACTIVE worldview were read and left unchanged.

## Next discriminating question

The L-only common error-response family is now analytically excluded at **every** legal amplitude for the fixed positive two-merger natural kernel. The next useful variation must alter the upstream information/decision coupling or an earlier terminal response (e.g. source-dependent `C`-branch response with explicit retained provenance), while preserving strict positivity and two-measure normalization. Derive an exact necessary criterion for **J-support equality** first; only then attempt every four-dimensional support direction via rational convex-combination or Farkas certificates and check actual seedless-LR image nonmembership. Preserve this theorem as a reusable no-go invariant rather than rescan the same eight-label cube.
