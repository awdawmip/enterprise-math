#!/usr/bin/env python3
"""Exact rational regression and finite support checks for R5 moving-FULL gap.

Finite tests are distinguished from the all-real proof in RESEARCH.md.
No approximation, floating point, or native X6 simulation is used.
"""
from fractions import Fraction as F
from itertools import product

ALPHA = (F(1, 4), F(1, 8))
R = {-1: F(1, 2), 1: F(3, 2)}
MERGE_Q = {-1: F(1, 3), 1: F(1, 2)}
RESIDUAL_LR = {-1: F(1, 4), 1: F(2)}
STOP_ERR = {-1: 1, 1: 0}
LEAF_ERR = {-1: 0, 1: 1}
HISTORIES = tuple((i, j, a) for i in (0, 1) for j in (-1, 1) for a in (0, 1))


def evaluate(bits, seedless):
    """Baseline error observation and each source/route/action Q occupancy."""
    assert len(bits) == (4 if seedless else 10)
    first = {i: bits[0] if seedless else bits[i] for i in (0, 1)}
    second = {(i, j): bits[1 + (j == 1)] if seedless
              else bits[2 + 2*i + (j == 1)]
              for i in (0, 1) for j in (-1, 1)}
    last = {(i, j): bits[3] if seedless
            else bits[6 + 2*i + (j == 1)]
            for i in (0, 1) for j in (-1, 1)}
    obs, masses = [F(0)] * 4, [F(0), F(0)]
    occupancy = {h: F(0) for h in HISTORIES}

    def finish(q, lr, time, error):
        p = q * lr
        masses[0] += p
        masses[1] += q
        obs[0] += p * error
        obs[1] += q * error
        obs[2] += p * time
        obs[3] += q * time

    for i, alpha in enumerate(ALPHA):
        if not first[i]:
            finish(F(1, 2), F(1), 1, 0)
            continue
        for j, qj in ((-1, alpha), (0, 1-2*alpha), (1, alpha)):
            q = qj / 2
            if j == 0:
                finish(q, F(1), 2, 0)
            elif not second[i, j]:
                finish(q, R[j], 2, STOP_ERR[j])
            else:
                finish(q * (1-MERGE_Q[j]), RESIDUAL_LR[j], 3, LEAF_ERR[j])
                q_l = q * MERGE_Q[j]
                a = last[i, j]
                occupancy[i, j, a] += q_l
                finish(q_l, F(1), 3+a, a)
    assert masses == [1, 1]
    return tuple(obs), occupancy


def J(obs):
    return 41*obs[1] - 12*obs[3]


def perturbed_J(policy_record, delta):
    obs, occupancy = policy_record
    return J(obs) + 41*sum(occupancy[h]*delta[h] for h in HISTORIES)


def new_error_labels(eps, bits):
    return {h: (eps if h[2] == 0 else -eps)*bit
            for h, bit in zip(HISTORIES, bits)}


def analytical_gap(delta):
    def response(i, a):
        return a + delta[i, 1, a]
    u0 = 41*response(0, 0)-29
    v0 = 41*(response(0, 1)-1)
    u1 = 41*response(1, 0)-29
    v1 = 41*(response(1, 1)-1)
    assert -29 <= u0 <= 12 and -29 <= u1 <= 12
    assert -41 <= v0 <= 0 and -41 <= v1 <= 0
    full = -10 + max(u0, v0)/16
    lr = -12 + max(F(0), (2*u0+u1)/32, (2*v0+v1)/32)
    return full, lr


def predicted_min_gap(eps):
    assert 0 <= eps <= 1
    return 2 - min(41*eps, F(29))/16


def main():
    full = [evaluate(bits, False) for bits in product((0, 1), repeat=10)]
    lr = [evaluate(bits, True) for bits in product((0, 1), repeat=4)]
    assert len(full) == 1024 and len(lr) == 16
    assert max(J(r[0]) for r in full) == -10
    assert max(J(r[0]) for r in lr) == -12
    # General exact sanity check for the formula and the moving FULL optimizer.
    # Exhaust eight response-box endpoints for six exact parameter values.
    eps_values = (F(0), F(1, 16), F(29, 82), F(29, 41), F(151, 205), F(1))
    for eps in eps_values:
        worst = None
        worstbits = None
        for bits in product((0,1), repeat=8):
            delta = new_error_labels(eps,bits)
            f, r = analytical_gap(delta)
            margin = f-r
            if worst is None or margin < worst:
                worst, worstbits = margin, bits
        assert worst == predicted_min_gap(eps), (eps,worst,predicted_min_gap(eps))
        print('BOX',eps,'min_moving_gap',worst,'lower_distance',worst/F(53), 'corner', ''.join(map(str,worstbits)))
    # Independent full-policy enumeration at diverse interior and boundary labels.
    # These are exact rational arithmetic checks of the Bellman reduction.
    cases = []
    for eps in eps_values:
        for bits in ((0,)*8,(1,)*8,(0,1,1,0,1,0,0,1),(1,0,1,0,0,1,0,1)):
            cases.append(new_error_labels(eps,bits))
        half = {h: ((eps/F(2)) if h[2]==0 else -(eps/F(2))) for h in HISTORIES}
        cases.append(half)
    for idx, delta in enumerate(cases):
        full_exact = max(perturbed_J(item, delta) for item in full)
        lr_exact = max(perturbed_J(item, delta) for item in lr)
        f, r = analytical_gap(delta)
        assert (full_exact,lr_exact) == (f,r), (idx,full_exact,lr_exact,f,r)
    # Explicit sharp construction in the two parameter intervals.
    for eps in eps_values:
        delta = {h: F(0) for h in HISTORIES}
        delta[0,1,0] = F(0)
        delta[0,1,1] = -eps
        f,r = analytical_gap(delta)
        assert f-r == predicted_min_gap(eps), (eps,f-r)
        if eps >= F(29,41):
            assert f-r == F(3,16)
    assert predicted_min_gap(F(0)) == F(2)
    assert predicted_min_gap(F(1,16)) == F(471,256)
    assert predicted_min_gap(F(29,41)) == F(3,16)
    assert predicted_min_gap(F(151,205)) == F(3,16)
    assert predicted_min_gap(F(1)) == F(3,16)
    print('EXACT_MOVING_FULL_MINIMAX 2 - min(41*epsilon,29)/16')
    print('ALL_REAL_EPS_DOMAIN 0<=epsilon<=1')
    print('UNIFORM_FOUR_OBSERVER_SUPPORT_GAP_AT_LEAST', F(3,16))
    print('UNIFORM_LINF_FULL_TO_LR_HULL_GAP_AT_LEAST', F(3,848))
    print('FULL_POLICY_COUNT',len(full),'LR_POLICY_COUNT',len(lr))
    print('CHECKED_BOX_CORNERS',len(eps_values)*256,'INDEPENDENT_COMPLETE_ENUMERATION_CASES',len(cases))
    print('PASS_EXACT_R5_MOVING_FULL_UNIFORM_J_SEPARATION')


if __name__ == '__main__':
    main()
