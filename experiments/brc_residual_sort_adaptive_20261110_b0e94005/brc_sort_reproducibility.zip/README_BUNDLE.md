# Residual integer sorting reproduction bundle

The two measured phases and all required C++ source dependencies are included.
No prebuilt executables or credentials are included. The per-phase reports retain
successful and failed conditions and explain the scope of each comparison.

For phase two, from the extracted bundle:

```bash
cd brc_residual_sort_adaptive_20261110_b0e94005
python run_experiment.py --verify-only --cpu 0
python run_experiment.py --sanitize --verify-only --cpu 1
python run_experiment.py --skip-build --skip-verify --cpu 0 --subset all
python analyze_results.py results_all.csv
```

Choose available CPU identifiers on your machine. The measured environment used
Linux, GCC13.3.0 and C++20. Verification and benchmark orchestration use Python's
standard library; analysis plots additionally need NumPy and Matplotlib.
The runners check pinned dependency bytes and generate disposable include files.
All timings must be rerun locally; the supplied CSVs are the actual recorded run.

Phase-one report: brc_residual_sort_robust_20261110_b0e94005/README.md
Phase-two report: brc_residual_sort_adaptive_20261110_b0e94005/README.md
Mathematical conditions and counterexamples are in their THEORY.md files.

The manifest lists SHA256 for every packaged file except itself. Source licenses
are retained, including upstream pdqsort's Zlib license.
