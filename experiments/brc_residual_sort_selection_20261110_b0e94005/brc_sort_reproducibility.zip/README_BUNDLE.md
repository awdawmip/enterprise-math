# Residual integer sorting reproduction bundle

This bundle contains the three measured repair phases and every exact C++
dependency needed for the newest phase. Earlier reports retain their original
hardware/timing provenance. New phase-three comparisons rebuild all controls on
the same AMD EPYC9V74/GCC14.2.0 host; historical absolute timings are not pooled.
No prebuilt executables or credentials are included. pdqsort's license is retained.

From the extracted bundle:

```bash
cd brc_residual_sort_selection_20261110_b0e94005
python run_experiment.py --verify-only --cpu 0
python run_experiment.py --sanitize --verify-only --cpu 1
python run_experiment.py --skip-build --skip-verify --cpu 0 --subset all
python analyze_results.py results_all.csv
```

Use CPU identifiers allowed by your local affinity. Builds require Linux taskset,
GCC with C++20 and Python's standard library. Plotting additionally uses NumPy and
Matplotlib. The runners check frozen dependency hashes and make disposable include
adapters. Timings must be rerun on the target host; supplied data are actual run
records, not expected portable timings. Every accepted counting node of the fused
output candidates writes exactly n final values; this excludes recursive/fallback
internals and does not claim n total operations.

Read brc_residual_sort_selection_20261110_b0e94005/README.md for measured successes, failures and comparisons,
THEORY.md for definitions/proofs and REVIEW.md for author-side validation scope.
The manifest gives bytes and SHA256 for every file except itself.
