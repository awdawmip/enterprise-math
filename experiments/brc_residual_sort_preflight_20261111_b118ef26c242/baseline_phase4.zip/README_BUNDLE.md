# Residual integer sorting reproduction bundle

This bundle contains four measured repair phases and all exact source dependencies.
Historical reports retain their original host/compiler provenance. Phases three
and four rebuild every earlier control in the same current AMD EPYC9V74/GCC14.2.0
binary for each experiment; old Intel-host absolute times are not pooled.
No prebuilt executables or credentials are included; source licenses are retained.

From the extracted bundle:

```bash
cd brc_residual_sort_certified_20261110_b0e94005
python run_experiment.py --verify-only --cpu 0
python run_experiment.py --sanitize --verify-only --cpu 1
python run_experiment.py --skip-build --skip-verify --cpu 0 --subset all --output results_local.csv --receipt execution_local.json
python analyze_results.py results_local.csv --prefix local
```

Choose available CPU identifiers. Builds require Linux taskset, GCC/C++20 and
Python's standard library; plotting additionally uses NumPy and Matplotlib.
Runners verify frozen dependency bytes and generate disposable include adapters.
The supplied files retain the original observed run; the commands above write
fresh timing evidence under different names.

The newest phase adds best-singleton, exact fractional rejection and conditional
mass-index DP after a failed greedy sample-half proposal. Its completeness theorem
concerns only whole-bin half-sample feasibility on a fixed learned grid. It does
not guarantee maximum actual population coverage or minimum runtime; only the DP
branch guarantees maximum feasible sample mass. The actual residual half gate and
full ascending multiset output remain separately verified.

See brc_residual_sort_certified_20261110_b0e94005/README.md for all measured gains/losses and controls, THEORY.md
for proofs, and REVIEW.md for the author-side review. The prior density/gap/fused
phase is in brc_residual_sort_selection_20261110_b0e94005/README.md.
The manifest contains bytes/SHA256 for every packaged file except itself.
