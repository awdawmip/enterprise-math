#!/usr/bin/env python3
"""Exact, standard-library-only checks for the Fermat residual analysis.

Run: python verify.py --output results.json
These finite tests corroborate the algebra in README.md. They do not prove that
all later Fermat numbers are composite or that the model is native X6 dynamics.
No network, external package, floating point, or repository mutation is used.
"""
from __future__ import annotations
import argparse
import json
from math import isqrt
from pathlib import Path

GLOBAL_SHA = "365836e6fd407f80c2106c42710861d4420b8c91"
SOURCE_SHA = "937aea6bbb6a774d7165a9d8e782940f47248fc4"


def centered(x: int, q: int) -> int:
    if q < 3 or q % 2 == 0:
        raise ValueError("q must be an odd integer >= 3")
    r = x % q
    return r-q if r > q//2 else r


def prime_trial(n: int) -> bool:
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    return all(n % d != 0 for d in range(3, isqrt(n)+1, 2))


def valuation(x: int, p: int) -> int:
    if x == 0:
        raise ValueError("This finite valuation function excludes zero")
    x = abs(x)
    v = 0
    while x % p == 0:
        x //= p
        v += 1
    return v


def trace(base: int, q: int, steps: int) -> list[dict[str, int]]:
    if steps < 0:
        raise ValueError("steps must be nonnegative")
    x = base
    r = centered(x, q)
    a = (x-r)//q
    rows = []
    for j in range(steps+1):
        assert x == q*a+r
        # Independent direct modular-exponentiation comparison.
        direct = pow(base, 1 << j, q*q)
        assert (r+q*(a % q)) % (q*q) == direct
        row = {"j": j, "r": r, "u": a % q}
        rows.append(row)
        if j == steps:
            break
        rn = centered(r*r, q)
        c = (r*r-rn)//q
        row["carry_to_next"] = c
        an = q*a*a+2*r*a+c
        assert an % q == (2*r*(a % q)+c) % q
        x, r, a = x*x, rn, an
    return rows


def candidate_scan(n: int, cap: int | None = None) -> dict:
    if n < 2:
        raise ValueError("The Lucas progression here requires n >= 2")
    f = (1 << (1 << n))+1
    complete_bound = isqrt(f)
    bound = complete_bound if cap is None else min(cap, complete_bound)
    step = 1 << (n+2)
    candidates = list(range(step+1, bound+1, step))
    ps = [p for p in candidates if prime_trial(p)]
    hits = [p for p in ps if pow(2, 1 << n, p) == p-1]
    return {
        "n": n, "bound": bound, "all_progression_candidates": len(candidates),
        "prime_candidates": len(ps), "hits": hits,
        "complete_to_sqrt": bound == complete_bound,
    }


def main() -> dict:
    transitions = 0
    for q in range(3, 1000, 2):
        for base in range(-20, 21):
            trace(base, q, 6)
            transitions += 6
    assert transitions == 122754

    valuation_checks = 0
    for p in range(3, 100, 2):
        if not prime_trial(p):
            continue
        for s in range(1, 5):
            for h in (1, 2, 4, 7):
                if h % p == 0:
                    continue
                x, y = 2, 2+p**s*h
                initial = valuation(y-x, p)
                for j in range(7):
                    assert valuation(y-x, p) == initial
                    valuation_checks += 1
                    x, y = x*x, y*y
    assert valuation_checks == 2660

    scans = [candidate_scan(n) for n in (2, 3, 4, 5)]
    scans.append(candidate_scan(6, 1_000_000))
    assert scans[2]["hits"] == []
    assert scans[3]["hits"] == [641]
    assert scans[3]["prime_candidates"] == 99
    assert scans[4]["hits"] == [274177]
    assert scans[4]["prime_candidates"] == 605

    # These are supplied divisibility examples, NOT an independent discovery
    # experiment. Primality of the two largest q is not asserted by this script.
    factors = {0:3, 1:5, 2:17, 3:257, 4:65537, 5:641, 6:274177,
               7:59649589127497217, 8:1238926361552897, 9:2424833,
               10:45592577, 11:319489, 12:114689}
    factor_checks = []
    for n, q in factors.items():
        rows = trace(2, q, n)
        f = (1 << (1 << n))+1
        assert f % q == 0
        assert rows[-1]["r"] == -1
        assert rows[-1]["u"] == (f//q) % q
        prime_checked = q < 100_000_000
        if prime_checked:
            assert prime_trial(q)
        item = {"n":n, "divisor":q, "proper_divisor":q<f,
                "terminal_r":rows[-1]["r"], "terminal_u":rows[-1]["u"],
                "square_divides":f % (q*q) == 0,
                "primality_checked_by_trial_division":prime_checked}
        if prime_checked:
            assert (q-1) % (1 << (n+1)) == 0
            m = (q-1)//(1 << (n+1))
            qp = (pow(2, q-1, q*q)-1)//q
            assert qp == (-2*m*rows[-1]["u"]) % q
            assert (qp == 0) == (f % (q*q) == 0)
            item["fermat_quotient_mod_p"] = qp
        factor_checks.append(item)

    orbit_641 = trace(2, 641, 5)
    assert [r["r"] for r in orbit_641] == [2,4,16,256,154,-1]
    assert [r["u"] for r in orbit_641] == [0,0,0,0,102,44]
    assert 641*6700417 == (1 << 32)+1
    assert (308*102+37) % 641 == 44

    # Same mod-5 state, different mod-25 observation after square-and-add-one.
    assert 2 % 5 == 7 % 5
    assert (2*2+1) % 5 == (7*7+1) % 5 == 0
    assert (2*2+1) % 25 != 0 and (7*7+1) % 25 == 0

    # Exact product identity and pairwise-coprimality check for F0..F12.
    product = 1
    fermats = []
    for n in range(13):
        f = (1 << (1 << n))+1
        assert product+2 == f
        assert all(f % old == 2 for old in fermats)
        fermats.append(f)
        product *= f

    return {
        "status":"PASS", "date":"2026-10-04",
        "global_snapshot":GLOBAL_SHA, "source_snapshot":SOURCE_SHA,
        "scope":"Finite exact arithmetic; not formal project admission or native-world dynamics",
        "transition_check_scope":{"odd_moduli":"3..999", "integer_bases":"-20..20",
                                  "squarings_per_pair":6, "transitions":transitions},
        "valuation_check_scope":{"odd_primes":"3..97", "s":"1..4", "h":[1,2,4,7],
                                 "exclude":"p divides h", "j":"0..6",
                                 "states_checked":valuation_checks},
        "candidate_scans_without_supplied_factors":scans,
        "supplied_divisor_checks":factor_checks,
        "centered_orbit_mod_641":orbit_641,
        "progression_slot_counts_full_sqrt":{
            str(n):(isqrt((1 << (1 << n))+1)-1)//(1 << (n+2)) for n in (4,5,6)},
        "refined_observer_counterexample":{"q":5,"initial_values":[2,7],
                                           "square_plus_one":[5,50]},
        "claims_not_made":["All Fn for n>=5 are composite", "A universal residual-magnitude threshold",
                           "New classical number-theory theorem", "Algorithmic speedup",
                           "Native X6 physical realization", "Canonical project publication"]
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Optional path for JSON evidence")
    args = parser.parse_args()
    result = main()
    text = json.dumps(result, ensure_ascii=False, indent=2)+"\n"
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    print(text)
