#!/usr/bin/env python3
"""Independent standard-library certificate replay for C311.

Uses elementary truncated polynomial recurrences and direct shared-numerator
evaluation (without C311's termwise quotient circuit). Shares frozen C305 input.
"""
from __future__ import annotations
import json
from functools import reduce
from math import gcd
from pathlib import Path
import C310_JOINT_BRANCH_PRIME_CERT as c310

BASE=Path(__file__).resolve().parent

def eval_int(poly, x):
    a=0
    for z in reversed(poly):a=a*x+z
    return a

def term_parts(prepared, L):
    out=[]
    for coeff, nums, power in prepared:
        scal=coeff; factors=[]
        for raw in nums:
            d=reduce(gcd,raw,0)
            scal*=d
            factors.append(tuple(x//d for x in raw))
        assert scal%L==0
        out.append((scal//L,factors,power))
    return out

def poly_mul_trunc(a,b,mod,cap):
    if not a or not b:return []
    result=[0]*min(len(a)+len(b)-1,cap)
    for i,x in enumerate(a):
        if x%mod==0:continue
        for j,y in enumerate(b):
            if i+j>=len(result):break
            result[i+j]=(result[i+j]+x*y)%mod
    return result

def branch_poly(scal,nums,denpower,groups,mod,max_degree):
    if scal%mod==0:return []
    arr=[scal%mod]
    cap=max_degree+1
    for q,e in groups.items():
        for _ in range(e-denpower.get(q,0)):
            arr=poly_mul_trunc(arr,q,mod,cap)
    for n in nums:
        arr=poly_mul_trunc(arr,n,mod,cap)
    return arr

def coeff_R(k,mod,groups,prepared,L,cache):
    key=(mod,k)
    if key in cache:return cache[key]
    val=0
    for scal,nums,power in term_parts(prepared,L):
        if scal%mod:
            a=branch_poly(scal,nums,power,groups,mod,k)
            if k<len(a):val=(val+a[k])%mod
    cache[key]=val
    return val

def R_full_mod(p,groups,prepared,L):
    degree=sum((len(q)-1)*e for q,e in groups.items())
    out=[0]*(degree+1)
    for scal,nums,power in term_parts(prepared,L):
        if scal%p:
            a=branch_poly(scal,nums,power,groups,p,degree)
            for j,z in enumerate(a):out[j]=(out[j]+z)%p
    return out

def eval_shared_num_and_divide(prepared,groups,L,mod,T):
    # A different circuit: sum the original integer J_a values modulo L*mod
    # and divide only after accumulating all terms.
    big=L*mod
    vals={q:eval_int(q,T)%big for q in groups}
    total=0
    for coeff,nums,powers in prepared:
        t=coeff%big
        for q,e in groups.items():
            n=e-powers.get(q,0)
            if n>0:t=t*pow(vals[q],n,big)%big
        for z in nums:t=t*(eval_int(z,T)%big)%big
        total=(total+t)%big
    assert total%L==0
    return total//L

def is_small_prime(q):
    if q<2:return False
    d=2
    while d*d<=q:
        if q%d==0:return False
        d+=1
    return True

def main():
    d=json.loads((BASE/'C311_19_COMPOSITE_CONTENT_CERTIFICATE.json').read_text())
    records=json.loads((c310.c305.ROOT/'C293_125_REFINED_BRACKETS.json').read_text())
    paths,_=c310.c305.c288.build_paths()
    W,_=c310.c305.src.floor_fixed_masses()
    coeff_count=0
    total_pairs=0
    for row in d['rows']:
        i=row['path_index']
        s,groups,prepared,cancel,degree=c310.c305.prepare(i,paths[i],int(records['records'][i][1]),W)
        L=c310.term_content_lower(s,prepared)
        assert int(row['L_dec'])==L
        ss=int(row['s_over_L_dec'])
        assert s==ss*L
        z=int(row['remaining_composite_cofactor_dec'])
        o=z
        for a in row['small_prime_powers']:
            q=a['prime'];e=a['exp']
            assert is_small_prime(q)
            o*=q**e
        assert o==ss
        cache={}
        for w in row['excluded_prime_coefficient_witnesses']:
            assert 1<=w['residue']<w['prime']
            got=coeff_R(w['degree'],w['prime'],groups,prepared,L,cache)
            assert got==w['residue'],('non-p witness',i,w,got)
            coeff_count+=1
        p=row['candidate_prime']
        a=R_full_mod(p,groups,prepared,L)
        assert not any(a),('p does not divide content',i,p)
        w=row['candidate_first_nonzero_coefficient_mod_p2']
        got=coeff_R(w['degree'],p*p,groups,prepared,L,cache)
        assert got==w['residue'] and got%p==0 and got!=0,('p² witness',i,p,got)
        coeff_count+=1
        composite=row['cofactor_evaluation_bezout_witness']
        if composite is not None:
            T=composite['sample']
            value=eval_shared_num_and_divide(prepared,groups,L,z,T)
            assert value==int(composite['value_mod_cofactor'])
            assert gcd(z,value)==1
            assert (value*int(composite['inverse_mod_cofactor_dec']))%z==1
        assert L*p==int(row['determined_gcd_s_content_P_dec'])
        total_pairs+=1
        print('C311_INDEPENDENT_PASS',i,'fields',len(row['excluded_prime_coefficient_witnesses'])+1,flush=True)
    print('C311_INDEPENDENT_ALL_PASS',total_pairs,'coefficient_witnesses',coeff_count,'composite_evaluations',total_pairs)

if __name__=='__main__':main()
