#!/usr/bin/env python3
"""C311 exact composite-cofactor and small-prime polynomial-content certificate.

No C306/C309 full-content oracle is used for certificate generation. Requires
frozen C293 path input and author-level factorized C305 circuit/C300 identity.
The carrier is an auxiliary scalar polynomial; original 79 branch labels remain.
"""
from __future__ import annotations
import argparse
import json
import hashlib
import time
from collections import Counter
from functools import reduce
from math import gcd
from pathlib import Path
import C310_JOINT_BRANCH_PRIME_CERT as c310

HERE=Path(__file__).resolve().parent
FROZEN=c310.c305.ROOT / 'C293_125_REFINED_BRACKETS.json'
INDICES=tuple(c310.EXCEPTIONAL)
P3=set(c310.PRIME_THREE)

def primes_below(n=10000):
    mark=bytearray(b'\x01')*n
    mark[:2]=b'\x00\x00'
    for p in range(2,int(n**.5)+1):
        if mark[p]:
            for k in range(p*p,n,p):mark[k]=0
    return [i for i,z in enumerate(mark) if z]

SMALL_PRIMES=primes_below(10000)

def smooth_decompose(z):
    original=z
    items=[]
    for p in SMALL_PRIMES:
        e=0
        while z%p==0:
            z//=p;e+=1
        if e:items.append((p,e))
        if z==1:break
    assert z*reduce(lambda a,pe:a*pe[0]**pe[1],items,1)==original
    return items,z

def prepared_int_terms(prepared, L):
    out=[]
    for coeff, nums, powers in prepared:
        ct=[reduce(gcd,n,0) for n in nums]
        scalar=coeff
        for a in ct:scalar*=a
        assert scalar%L==0
        scal=scalar//L
        primitives=[tuple(z//a for z in n) for n,a in zip(nums,ct)]
        out.append((scal,primitives,powers))
    return out

def eval_R_mod(z,t,groups,terms):
    assert z>0
    if z==1:return 0
    vals={q:c310.c305.eval_p(q,t)%z for q in groups}
    acc=0
    for scal, nums, power in terms:
        term=scal%z
        if not term:continue
        for q,e in groups.items():
            remaining=e-power.get(q,0)
            assert remaining>=0
            if remaining:term=term*pow(vals[q],remaining,z)%z
            if not term:break
        if term:
            for n in nums:term=term*(c310.c305.eval_p(n,t)%z)%z
        acc=(acc+term)%z
    return acc

def certificate_row(i, path, k24, W, expected=None):
    t0=time.monotonic()
    s,groups,prepared,cancels,degree=c310.c305.prepare(i,path,k24,W)
    L=c310.term_content_lower(s,prepared)
    assert s%L==0
    S=s//L
    factors,cofactor=smooth_decompose(S)
    predicted=3 if i in P3 else 2
    assert any(q==predicted for q,e in factors), (i,predicted)
    witness=[]
    for q,e in factors:
        if q==predicted:continue
        coeffs,nz,z,maxdeg=c310.poly_branch_mod(q,groups,prepared,L)
        nonzero=next(((j,int(x)%q) for j,x in enumerate(coeffs) if x%q),None)
        if nonzero is None:
            raise AssertionError(f'Unexpected additional prime-content factor: path={i}, prime={q}')
        witness.append({'prime':q,'exponent_in_s_over_L':e,'degree':nonzero[0],'residue':nonzero[1]})
    # Re-prove candidate p exactly once: no C306 oracle.
    atp,nz,z,degp=c310.poly_branch_mod(predicted,groups,prepared,L)
    assert all(x%predicted==0 for x in atp)
    atp2,nz,z,degp2=c310.poly_branch_mod(predicted*predicted,groups,prepared,L)
    j=next((j for j,x in enumerate(atp2) if x%(predicted*predicted)),None)
    assert j is not None
    p2res=int(atp2[j])%(predicted*predicted)
    assert p2res%predicted==0
    # For the unknown composite cofactor, a single Bezout gcd against a
    # factorized circuit evaluation excludes all its prime divisors.
    iterms=prepared_int_terms(prepared,L)
    comp=None
    if cofactor>1:
        for T in (0,1,-1,2,-2,3,7,11,17,31,63,127):
            residue=eval_R_mod(cofactor,T,groups,iterms)
            g=gcd(cofactor,residue)
            if g==1:
                comp={'sample':T,'value_mod_cofactor':str(residue),'inverse_mod_cofactor_dec':str(pow(residue,-1,cofactor)),'gcd':str(g)}
                break
        if comp is None:
            raise AssertionError(f'Composite cofactor has no coprime eval on selected points: i={i}, cofactor_bits={cofactor.bit_length()}')
    result={
        'path_index':i,'degree_reduced':degree,'degree_R_upper':degree+2,
        's_over_L_bits':S.bit_length(),'L_dec':str(L),
        's_over_L_dec':str(S),
        'small_prime_powers':[{'prime':q,'exp':e} for q,e in factors],
        'remaining_composite_cofactor_dec':str(cofactor),
        'remaining_composite_cofactor_bits':cofactor.bit_length(),
        'excluded_prime_coefficient_witnesses':witness,
        'candidate_prime':predicted,
        'candidate_zero_polynomial_mod_p':True,
        'candidate_first_nonzero_coefficient_mod_p2':{'degree':j,'residue':p2res},
        'cofactor_evaluation_bezout_witness':comp,
        'determined_gcd_s_content_P_dec':str(L*predicted),
        'method':'Small-prime coefficient witnesses + composite-cofactor evaluation gcd + C310 p/p² exact coefficients',
        'elapsed_seconds':round(time.monotonic()-t0,3)
    }
    if expected is not None:
        assert int(expected)==L*predicted,'oracle mismatch, not used to generate proof'
        result['historical_C306_author_oracle_posthoc_match']=True
    return result

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--indices',default='all')
    ap.add_argument('--output',default='C311_19_COMPOSITE_CONTENT_CERTIFICATE.json')
    ap.add_argument('--posthoc-oracle',action='store_true')
    args=ap.parse_args()
    paths,_=c310.c305.c288.build_paths()
    rr=json.loads(FROZEN.read_text())
    assert rr['records_sha256']=='03083a77480e6be5615797c2f4ffc503eee6603e9e60cbad1f11fb3ea83b3c89'
    W,_=c310.c305.src.floor_fixed_masses()
    rows=[]
    ind=INDICES if args.indices=='all' else tuple(int(x) for x in args.indices.split(','))
    cmporacle=None
    if args.posthoc_oracle:
        obj=json.loads((HERE/'C309_BRANCH_CONTENT_PROBE_125.json').read_text())
        cmporacle={r['index']:r['oracle_dec'] for r in obj['rows']}
    for idx in ind:
        assert rr['records'][idx][0]==idx
        row=certificate_row(idx,paths[idx],int(rr['records'][idx][1]),W, None if cmporacle is None else cmporacle[idx])
        rows.append(row)
        print('C311_EXACT_PASS',idx,'p',row['candidate_prime'],'excluded',len(row['excluded_prime_coefficient_witnesses']),'cofactor_bits',row['remaining_composite_cofactor_bits'],'g',row['cofactor_evaluation_bezout_witness']['gcd'] if row['cofactor_evaluation_bezout_witness'] else '1','seconds',row['elapsed_seconds'],flush=True)
    result={
      'schema':'C311_COMPOSITE_GCD_CONTENT_CERTIFICATE_V1',
      'scope':'19 C310 exceptional C293 frozen paths in auxiliary C195/H168 scalar 79-branch model; conditional on C300/C305 factorized numerator identity',
      'upstream_C293_records_sha256':rr['records_sha256'],
      'prime_trial_bound_exclusive':10000,
      'not_assumed':'Unfactored residual is NOT claimed prime; its entire gcd obstruction is killed by one exact composite residue and Bezout gcd.',
      'verification':'Integer quotient L of all factorized term contents, polynomial coefficient reduction mod each small prime, exact p² coefficient, and modular circuit evaluation mod residual cofactor.',
      'C306_oracle_used_for_certificate':False,
      'posthoc_oracle_comparison_performed':bool(args.posthoc_oracle),
      'path_count':len(rows),'rows':rows}
    output=HERE/args.output
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('C311_ALL',len(rows),'PASS')
if __name__=='__main__':main()
