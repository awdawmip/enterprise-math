# C311 portable replay

This package extends the upstream frozen `EM_C310_PAIRWISE_PRIME_COLLISION_19_EXACT_PORTABLE.zip` (in this portable ZIP, the inherited files are included unchanged). Scientific input is the auxiliary scalar 79-branch C195/H168 factorized model with C293 paths; native Source review and C300 independent source audit are pending.

To replay from an extracted archive in an environment with Python 3 and NumPy:

```
python C311_COMPOSITE_CERTIFICATE.py --posthoc-oracle
python C311_INDEPENDENT_CERTIFICATE_CHECK.py
```

Expected final lines:

```
C311_ALL 19 PASS
C311_INDEPENDENT_ALL_PASS 19 coefficient_witnesses 173 composite_evaluations 19
```

The scripts share the C305 upstream frozen circuit, but use different modular coefficient and composite evaluation algorithms. `C311_19_COMPOSITE_CONTENT_CERTIFICATE.json` gives full certificate inputs and witnesses. The optional posthoc oracle comparator checks the historical C309/C306 author-level values only *after* independent certificate construction. Neither procedure is a formal external Source proof or original C300 factorization audit.

`C311_SHA256_MANIFEST.json` checks the exact preserved byte payload. Runtime `elapsed_seconds` fields in the generated JSON differ on replay and are not mathematical evidence. Results should be compared after excluding runtime timing fields; mathematical witness fields are deterministic.

GitHub source handoff contains this incremental capsule and the theorem at an immutable commit. Complete combined portable replay is also available as a ZIP conversation artifact. No credentials or private access grants are included.
