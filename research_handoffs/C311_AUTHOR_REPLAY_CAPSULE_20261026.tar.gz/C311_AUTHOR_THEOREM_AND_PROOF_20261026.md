# C311 — Composite-cofactor content certificate for the 19 exceptional paths

**Status:** author proof plus two executed exact local implementations; not a native Enterprise Math Source Result, independent Driver review, Working Truth, or Foundation admission. Date: 2026-10-26.

## 1. Frozen scope and provenance

- Canonical account-level source: `awdawmip/chatgpt-global-knowledge main@363cc21deb56c429a3d1304e62bde6fd4c35452e`, `GLOBAL_KNOWLEDGE_V1` (`00_BOOTSTRAP.md`, `OPERATING_MANUAL.md`, project entry, P000, mathematical and code policies, ACTIVE worldview).
- Enterprise Math canonical input: `awdawmip/enterprise-math main@5ccb75b5ef5d57dfa75f379ec6425e54948a1e34`, with `p000_reality_foundation.json`, `definitions/HEARTBEAT_WORLD_NATIVE_X6_TIME.json`, joint-relation preservation, `docs/PORTABLE_RESEARCH_PROTOCOL.md`, and `control_plane/research_delivery_policy.json`.
- Frozen numerical input: `C293_125_REFINED_BRACKETS.json`, recorded `records_sha256=03083a77480e6be5615797c2f4ffc503eee6603e9e60cbad1f11fb3ea83b3c89`, from the unchanged C310 portable source archive. Its interpreted C195/H168 79-branch auxiliary factorized circuit is built with C305 source. These are upstream **author-level** inputs; the full C300 cancellation identity is still not independently source-audited.
- Direct predecessor: C310 author-level exact prime-field pairwise-collision certificates at `research/c310-pairwise-prime-content-20261026-research2@0ea93a4cbd23994bc1f4323202922f54c8ab4785`. C309 listed 19 exceptional paths. Existing C306 content values were used only to choose the historical 19-path candidate set and primes; C311's mathematical certificate does **not** use the C306 oracle to establish the equalities.
- Real connected GitHub login: `awdawmip`; repository permission: `admin`/`push`. Native `em_control_tasks` returned `CONTROL_QUOTA`; `em_session_start` returned `STATIC_READONLY_SCOPE_DENIED` with `operation_sent=false`. Active native owner, CLAIM, Driver identity, and formal acceptance were not verified/granted. This artifact is branch-persisted author research only.

Research object: integer polynomial numerator content of 125 parameter paths in the auxiliary **positive-rational 79-branch scalar model**. The 19 paths below are a selected subset, not new native GF(2)-BRC/X6 experiments.

## 2. Theorem C311-A — Composite cofactor exclusion without factoring the cofactor

Let `s` be a positive integer; let `P,C,J_1,...,J_m in Z[t]` obey

`C(t)P(t) = J_1(t)+...+J_m(t)`, with `content(C)=1`.

Define

`L = gcd(s, content(J_1),...,content(J_m))`, `S=s/L`, and `R(t)=sum_a J_a(t)/L in Z[t]`, taking `content(0)=0`.

Then `L | content(P)`, and by Gauss's content lemma,

`gcd(s, content(P)) = L*gcd(S, content(R))`.                 **(1)**

Let `Q` be a finite set of *distinct proven prime integers*, with exact complete division

`S = H * product_{q in Q} q^(e_q)`, `H>=1`, `e_q>=1`,

where none of these primes divides `H`. Choose `p in Q` and suppose:

1. Every coefficient of `R` is divisible by `p`, and at least one is not divisible by `p²`.
2. For each `q in Q \ {p}` there is an explicitly identified degree `k_q` for which `[t^(k_q)]R` is nonzero modulo `q`.
3. There is an integer `T` and a reproducible residue `r ≡ R(T) (mod H)` with `gcd(H,r)=1` (equivalently, an integer inverse `u` such that `ru ≡ 1 (mod H)`). For `H=1`, this condition is automatic.

**Conclusion** (without primality testing or factoring `H`):

`gcd(s,content(P)) = L*p`.                                  **(2)**

**Proof.** Since every coefficient of every `J_a` is divisible by `L`, `R` is integral. Because `C` is primitive, Gauss's lemma gives `content(CP)=content(P)` and `L|content(P)`. Then `R=C(P/L)` and `content(R)=content(P)/L`, proving (1). The first condition gives `v_p(content(R))=1`; every other small prime `q` dividing `S` is excluded by its nonzero coefficient witness. If any prime divides both `H` and `content(R)`, it divides `R(T)` as well, contradicting `gcd(H,r)=1`. Thus no prime divisor from `H` divides `content(R)`, even when `H` is composite or has unknown factorization. All prime divisors of `S` are covered and the only remaining content contribution is precisely one factor `p`. Equations (1) and (2) follow. QED.

The same principle yields a **zero-extra-content corollary**: if every `q in Q` has a nonzero coefficient witness and `gcd(H,R(T))=1`, then `gcd(s,content(P))=L`. This is a candidate method for the remaining 106 paths, not something executed in C311.

A modular inverse `u` is a short verifiable Bézout witness: an ordinary checker computes `(r*u)%H` and obtains exactly one. This is a statement about divisibility of coefficients, not an assertion that an unknown large `H` is prime.

## 3. Application to all 19 C310 exceptional paths

Frozen zero-based indices:

`3, 6, 7, 8, 11, 12, 17, 26, 27, 29, 30, 33, 34, 38, 56, 75, 76, 97, 108`.

Candidate `p=3` occurs at `3,8,38,56` (4 paths); `p=2` at the other 15 paths. For each path we recomputed `L` directly from the 79 named prepared branches, formed `S=s/L`, divided `S` by every prime `<10000` with exact integer divisions, and retained the untouched integer cofactor `H`.

**Unexpected exact commonality:** All 19 paths have the *same* remaining 250-bit composite cofactor candidate

`H = 1354520142208056835914840923242211064045022575104362006332341353239007546777`.

We did **not** claim that `H` is prime. For every path a single integer sample `T=1` supplies `gcd(H,R(1))=1` and a complete modular inverse witness. Across all 19 records:

- 154 excluded-small-prime coefficient witnesses (`q<10000`, excluding `p`) were computed with exact polynomial convolution; every recorded residue is nonzero modulo its stated prime.
- 19 exact whole-polynomial reductions `R≡0 (mod p)` were checked.
- 19 exact nonzero `p²` coefficient witnesses were found, proving `v_p(content(R))=1`.
- 19 exact evaluations `R(1) mod H` and 19 modular inverse identities were verified, excluding **every** potential prime factor of `H` without factoring it.
- Every displayed equality `gcd(s,content(P))=L*p` now has a self-contained finite algebraic certificate **conditional on the frozen C305/C300 factorized source identity**, rather than depending on the C306 Newton content oracle.

The first `p²` nonzero coefficient witness appears at degree 15, 95, 100, 243 or 252, depending on the path. The certificate JSON records each path's full exact `S`, `L`, small-prime decomposition, 154 coefficient indices and residues, `H`, `R(1) mod H`, its inverse, and the resulting integer gcd.

## 4. Exact implementations and replay scope

**Author implementation A:** `C311_COMPOSITE_CERTIFICATE.py` uses the frozen C305 integer-factorized preparation; it executes small-prime reduction via the existing C310 NumPy integer coefficient kernel, independently recomputes `R mod p`, `R mod p²`, and evaluates the branch products `J_a/L` directly modulo `H`. It uses a deterministic list of prime candidates below 10000, not factoring `H`. Its 19 rows pass. The post-hoc `--posthoc-oracle` option only checks consistency *after* all certificate equations have been proved; it is neither a proof assumption nor a stopping test.

**Independent algorithm B:** `C311_INDEPENDENT_CERTIFICATE_CHECK.py` uses Python standard-library exact integers and a separately written truncated polynomial convolution, checking all 173 recorded coefficient witnesses and 19 whole-polynomial zero reductions `mod p`. It recomputes all 19 values `R(1) mod H` through a different circuit: first accumulate the **un-normalized** shared numerator modulo `L*H`, then divide once by `L` and compare with the stored residue. It also verifies every modular inverse and each exact decomposition `S=H*product q^e`. All 19 paths pass. These are **two algorithmically different implementations sharing the same frozen source factorization and path-builder**, not an independent C300 source/model review.

Decisive arithmetic: arbitrary-precision integers and finite field/composite-ring operations only, with no floating-point comparison. The NumPy `int64` convolution is used only at primes `<10000` and `p²<=9`, at polynomial degree at most 356; its intermediate bounds remain well below `2^63` in this scope. Full coefficient modular reductions can be recomputed by verifier B.

Observed local output:

`C311_ALL 19 PASS`

`C311_INDEPENDENT_ALL_PASS 19 coefficient_witnesses 173 composite_evaluations 19`

These results prove the stated polynomial content claims inside the **frozen author model**. They do not make assertions of novelty in the literature, native Source admission, or physical correspondence.

## 5. BRC carrier, observer and information losses

Input carrier: 79 individually labeled factorized auxiliary positive-rational branches, retaining exact coefficients, prime/composite denominator structures and source path indices. The selected observer is the **integer coefficient-content gcd of a scalar rational-numerator projection**. Output `L*p` is a quotient for this single observer only. The proof retains all branch labels in its input and does not claim their oppositely signed reductions imply cancellation of actual positive BRC masses, phases, provenance, ports or future joint operations. No native X6/three-dimensional slice map with observer/future-operation preservation has been supplied. P000's six spatial axes, separate time axis, triadic primitive balance and residual-fidelity constraints are unchanged.

## 6. Remaining obligations and C312

1. Independently audit C300's `C(t)P(t)=sum J_a(t)` and primitive-factor/source construction for the frozen C293 inputs. Present C311's model application retains this explicit antecedent.
2. Apply the zero-extra-content corollary to the other 106 paths: small-prime coefficient witnesses plus a composite-cofactor Bézout sample, **without** relying on their earlier C306 content-oracle values. Check for any failure of a one-sample composite gcd and adjust by justified additional samples or coefficient witnesses.
3. Formal activity/CLAIM/Result/Driver review remains pending real native role authorization and current owner observation. An inaccessible native control gateway is not a license to create a fabricated Source event, overwrite ownership or promote these facts to Foundation.

**Exact output classification:** `C311_AUTHOR_HAND_PROOF_AND_EXACT_COMPUTATION / 19_GCD_CERTIFIED_WITHIN_FROZEN_FACTOR_MODEL / 154_PRIME_COEFFICIENT_WITNESSES / 19_COMPOSITE_INVERSES / 19_INDEPENDENT_REPLAYS / NO_NATIVE_CLAIM / NO_DRIVER_ADMISSION`.
